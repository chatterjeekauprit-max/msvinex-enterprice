# Valrix: Parent Server ⇄ Pipeline ⇄ Child Server

> **Kaam (3 lines):**
> **Parent Server** code aur model files ko vaults (Parent IDs) mein rakhta hai, aur har file ka SHA-256 Algorand blockchain par register karta hai.
> **Pipeline** Parent ID ko Child ID se bind karta hai. Prompt ke basis par deployment banata hai, jo sirf us ek Child ki key se encrypted hota hai aur blockchain par anchor hota hai.
> **Child Server** (Raspberry Pi) 12 checks khud verify karta hai (jinme 2 blockchain checks hain). Uske baad hi code chalata hai aur ek signed receipt wapas bhejta hai, jo blockchain par bhi record hota hai.

Is file ko edit karke apne project ke hisaab se badal lo. Code isi spec ke according bana hua hai.

---

## 1. Kaun kya banayega

| Hissa | Owner | Folder | Kya karta hai | Default port |
|---|---|---|---|---|
| **Parent Server** (Vault Engine) | Friend 1 | `parent_server/` | Named folders, drag-drop file + dataset upload, capability catalog, on-chain registration, per-child encryption (seal), audit log, web UI | 8100 |
| **Child Server** (Edge device) | Friend 2 | `child_server/` | Enrollment, trust pinning, 12-step verification, safe install/run, signed receipt, systemd service | (sirf outbound) |
| **Pipeline** (Middle-Pipe) | Team | `pipeline/` | Registry, Connect & Continue, Prompt → Plan, manifest, delivery, dashboard | 8000 |
| **Blockchain** | Team | `blockchain/` | Algorand client (TestNet/MainNet) + offline DevNet | 8700 (DevNet) |
| Shared | Sab | `common/` | Crypto, identity, HTTP, DB helpers | – |

Teeno hisse alag machines par chal sakte hain aur sirf neeche diye **API contract** (section 6) se baat karte hain. Isliye koi bhi friend doosre ke internal code ko chhede bina apna hissa badal sakta hai.

---

## 2. Architecture

```
                         ┌───────────────────── ALGORAND BLOCKCHAIN ─────────────────────┐
                         │  reg (Parent likhta)     dep (Pipeline likhta)    rcpt (Pipeline) │
                         └──────▲───────────────────────▲───────────────────────▲──────────┘
                                │ ① register hash       │ ④ anchor manifest     │ ⑧ anchor receipt
                                │                       │                       │
┌───────────────────────┐   ③ seal request    ┌───────────────────────┐        │
│    PARENT SERVER      │◄────────────────────│       PIPELINE        │────────┘
│  (Friend 1)           │   ciphertext only   │  (Middle-Pipe)        │
│  vault PARENT_01…     │────────────────────►│  Connect & Continue   │
│  files + SHA-256      │                     │  Prompt → Plan        │
└───────────▲───────────┘                     │  Manifest + signature │
            │ trust pin (enrollment ke waqt)  └───────────▲───────────┘
            │                                     ⑤ poll  │  │ ⑥ manifest + payload
            │                                   ⑦ receipt │  ▼
            │                                 ┌───────────┴───────────┐
            └─────────────────────────────────│     CHILD SERVER      │── ⑥b verify on-chain (khud se)
                                              │  (Friend 2, Pi)       │
                                              │  12 checks → run      │
                                              └───────────────────────┘
```

Teen important design decisions:

1. **Plaintext kabhi Pipeline se hokar nahi guzarta.** Parent Server file ko seedha Child ki public key se encrypt karta hai. Pipeline ke paas sirf ciphertext hota hai.
2. **Child sirf pull karta hai.** Pi par koi inbound port ya SSH nahi khulta, isliye NAT aur 4G ke peeche bhi kaam karta hai.
3. **Child sab kuch khud check karta hai.** Pipeline ki kisi baat par bharosa nahi karta. Blockchain bhi seedha public node se padhta hai.

---

## 3. Blockchain kahan baithta hai

**Kaun sa:** Algorand (Pure Proof-of-Stake). Har record ek 0-ALGO self-payment transaction hota hai jiske `note` field (max 1024 bytes) mein chhota JSON hota hai. Fee sirf 0.001 ALGO (minimum fee) lagti hai, block ~3 second mein banta hai aur finality instant hoti hai. Offline development ke liye `DevNet` mode hai: ek local hash-chained ledger jo same interface follow karta hai (ye sirf dev ke liye hai, decentralised nahi hai).

| # | Record | Kaun likhta hai | Kab | Note (JSON) | Kaun check karta hai |
|---|---|---|---|---|---|
| ① | `reg` | Parent Server ka address | File upload hote hi | `{"k":"reg","p":PARENT_ID,"a":artifact_id,"h":sha256,"v":version}` | Pipeline (deploy se pehle) **aur** Child (run se pehle) |
| ④ | `dep` | Pipeline ka address | Har deployment par | `{"k":"dep","d":deployment_id,"m":manifest_sha256,"p":PARENT_ID,"c":CHILD_ID}` | Child (run se pehle) |
| ⑧ | `rcpt` | Pipeline ka address (Child ka signature andar hota hai) | Execution ke baad | `{"k":"rcpt","d":deployment_id,"r":receipt_sha256,"x":exit_code}` | Auditor / client / compliance |

**Blockchain asli mein kya deta hai:**

- Tamper-proofing ka kaam **signatures aur encryption** karte hain. Ye bina blockchain ke bhi ho sakta hai.
- Blockchain ek **independent, public, timestamped record** deta hai jise baad mein koi bhi (hum khud bhi) badal ya chhupa nahi sakta. Iske do fayde hain:
  - Agar Pipeline poori tarah hack ho jaye, tab bhi Child sirf wahi code chalayega jiska hash Parent ne on-chain register kiya tha. Ye tested hai: attack A3/A4 neeche section 7 mein.
  - Har deployment aur uske execution ka permanent proof banta hai (kis Parent ka code, kis device par, kab chala, kya result aaya). Isse compliance aur audit ke liye report bana sakte ho.

---

## 3b. Parent Server = named folder (no blocks)

Har Parent Server ek **naam** se banta hai (jaise "Drone Parent Server", "Computer Vision Parent
Server") aur uska ID naam se auto-derive hota hai (Drone Parent Server -> DRONE). Uske andar tum
**drag-and-drop** se files daalte ho — koi internal block structure nahi, bas ek flat folder (Drive
jaisa). Har file ka SHA-256 on-chain register hota hai. Datasets (CSV/JSON) bhi drop kar sakte ho.

## 3c. Capability catalog (prompt → sirf required algo)

Ek vault mein bahut saare algos ho sakte hain. **Capability** = ek naam (jaise `human_detection`)
jo kuch files (code + model + config) ko ek scoped bundle se jodta hai.

- Parent UI mein "Create capability": naam do, files chuno, entrypoint + default env set karo → ek
  bundle ban jaata hai jiska `meta.capability` = naam.
- Pipeline mein prompt `+ HUMAN_DETECTION -> CHILD_RPI_01` likhte hi wo capability **auto-resolve**
  hoti hai → **sirf us capability ka bundle** Child ko jaata hai, poora vault nahi.
- Capability ka default env (jaise `SOURCE=camera`) plan mein merge hota hai; prompt ka `KEY=VAL`
  usse override kar sakta hai.

Iska matlab: "ek parent server mein saare CV algos, aur prompt ke anusar sirf required algo Pi par
jaaye" — ye poori tarah kaam karta hai (`pipeline/prompt_algebra.py` + capability catalog). Sample: `examples/cv_algos/` mein motion/face/human detection (OpenCV, Pi-ready).

## 4. Deployment flow (step by step)

1. **Parent upload:** Friend 1 `PARENT_01` vault mein file upload karta hai. Parent Server SHA-256 nikalta hai aur on-chain `reg` likhta hai.
2. **Child enrollment:** Pipeline dashboard par Child ID banao, ek one-time token milega. Pi par `enroll` command chalao. Device apni keys (Ed25519 aur X25519) **Pi par hi** banata hai, aur Pipeline ka address aur trusted Parent address pin kar leta hai.
3. **Connect & Continue:** Parent ID aur Child ID select karo. Checks chalte hain: parent known hai, child enrolled hai, online hai, child is Parent ko trust karta hai. Sab pass hone par binding ban jaati hai.
4. **Prompt → Plan:** "Execute Valrix Metrology Engine with dynamic masking, timeout 2 min" jaisa prompt ek allow-listed plan ban jata hai: `{mode: run, timeout_s: 120, args: [], env: {}}`. Prompt kabhi shell mein nahi jata.
   - **Prompt algebra** (optional, user-friendly): `+feature` add, `-feature` remove, `->CHILD_ID` route, `*N` scale. Jaise `+ METROLOGY_ENGINE - DEBUG_LOGS -> CHILD_RPI_01`. Ye bhi sirf env/mode toggle karta hai (SERVICE, DEBUG, MASKING, FEATURES, SCALE) — shell mein kuch nahi jata. `pipeline/prompt_algebra.py` mein hai.
5. **Seal:** Pipeline Parent se kehta hai "ye file is Child ki key ke liye seal karo". Parent encrypt karke `seal_sig` ke saath ciphertext deta hai.
6. **Verify + manifest:** Pipeline on-chain `reg` check karta hai, phir manifest banakar sign karta hai aur on-chain `dep` anchor karta hai.
7. **Delivery:** Child poll karta hai, manifest aur payload leta hai, 12 checks karta hai (section 5), phir install/run karta hai.
8. **Receipt:** Child ek signed receipt bhejta hai (exit code, output hash, time). Pipeline use verify karke on-chain `rcpt` likhta hai.

---

## 5. Child Server ke 12 checks (sab pass hone par hi code chalega)

| # | Check | Kya rokta hai |
|---|---|---|
| 1 | Replay | Purana deployment dobara chalana |
| 2 | Pipeline signature (pinned address) | Nakli Pipeline, ya manifest mein badlav |
| 3 | Target device | Kisi aur device ka deployment |
| 4 | Expiry | Purane manifests |
| 5 | Parent trusted (device ki apni list) | Anjaan ya rogue Parent Server |
| 6 | Plan shape | Prompt ke zariye injection |
| 7 | **On-chain `dep`** by Pipeline, hash match | Manifest swap jiska on-chain record na ho |
| 8 | **On-chain `reg`** by Parent, hash match | Aisa code jo Parent ne register hi nahi kiya |
| 9 | Payload SHA-256 | Transit ya storage mein tampering |
| 10 | Parent seal signature | Pipeline ka apna encrypted code bhejna |
| 11 | AES-256-GCM decrypt (device key) | Galat recipient, ya bit-flip |
| 12 | Code SHA-256 == on-chain hash | Final guarantee |

---

## 6. API contract (dono friends isi ke hisaab se code karein)

**Identity:** har service ki ek Ed25519 key hoti hai. Uska address Algorand format (58 chars) mein hota hai, aur wahi signing identity bhi hai aur blockchain account bhi. Signatures domain-separated hote hain: `VALRIX|<domain>|<canonical JSON>`.

### Parent Server
| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | `/api/identity` | public | `{role:"parent_server", address, ledger}` |
| POST | `/api/vaults` | admin | `{parent_id, name}` |
| GET | `/api/vaults` | admin / pipeline | vaults aur unke artifacts (sha256, version, runtime, arch, reg_txid) |
| POST | `/api/vaults/{parent_id}/artifacts?filename=&runtime=&arch=&block=` | admin | raw file body → hash + on-chain `reg` (into a block) |
| POST | `/api/vaults/{parent_id}/datasets?filename=` | admin | raw CSV/JSON body → checksum + on-chain `reg` |
| POST | `/api/vaults/{parent_id}/packages` | admin | `{artifact_ids[], dataset_id?, entrypoint?, arch?, name?}` → real .tar.gz bundle artifact |
| POST | `/api/seal` | pipeline | `{artifact_id, deployment_id, child_id, child_address, child_enc_pub, child_enc_sig}` → `{payload_b64, payload_sha256, seal_sig, artifact, parent_address}` |
| GET | `/api/audit` | admin | seal log |

`seal_sig` = Parent sign(`parent-seal`, `{a, c, d, h, p, s}`), jahan a = artifact, c = child address, d = deployment, h = code sha, p = parent id, s = payload sha.

### Pipeline: Child-facing (har request device key se signed hoti hai: `X-Valrix-Address`, `X-Valrix-Ts`, `X-Valrix-Sig`)
| Method | Path | Purpose |
|---|---|---|
| POST | `/api/child/enroll` | `{token, child_id, address, enc_pub, enc_sig, info}` → `{pipeline_address, ledger}` |
| POST | `/api/child/poll` | `{info}` → `{deployment: {deployment_id, manifest, manifest_sig, dep_txid} \| null}` |
| GET | `/api/child/payload/{id}` | ciphertext bytes |
| POST | `/api/child/report/{id}` | `{stage: verified\|rejected\|running\|completed\|failed, detail, output_tail, receipt, receipt_sig}` |

### Pipeline: Dashboard (admin token)
`/api/overview`, `/api/parent-servers`, `/api/children`, `/api/children/{id}/revoke`, `/api/connect`, `/api/plan`, `/api/deploy`, `/api/deployments`, `/api/ledger`

### Manifest (Pipeline sign karta hai, domain `manifest`)
```json
{ "v":1, "deployment_id":"dep_…", "created_at":0, "expires_at":0, "pipeline_address":"…",
  "parent":  {"parent_id","address","artifact_id","filename","version","sha256","size","runtime","arch","reg_txid","seal_sig"},
  "child":   {"child_id","address"},
  "payload": {"sha256","size","enc":"x25519-hkdf-sha256-aes256gcm"},
  "plan":    {"mode":"install|run|service","timeout_s":1-3600,"args":[],"env":{}},
  "prompt":  "…" }
```

### Receipt (Child sign karta hai, domain `receipt`)
`{deployment_id, manifest_sha256, artifact_sha256, parent_id, child_id, child_address, mode, status, exit_code, started_at, finished_at, output_sha256}`

---

## 7. Security: kya tested hai (`python3 tests/e2e.py`, 41/41 pass)

| Attack | Kya hota hai |
|---|---|
| A1 Payload ko Pipeline storage mein badla | Child reject karta hai (payload hash) |
| A2 Signing ke baad manifest edit kiya | Reject (Pipeline signature) |
| A3 Pipeline key chori karke code badla | Reject (on-chain `dep` match nahi karta) |
| A4 Key chori + code badla + dobara on-chain anchor kiya | Reject (Parent seal signature) |
| A5 Purana signed manifest naye ID ke saath, ya exact replay | Reject |
| A6 Aisa Parent Server jise Child ne pin nahi kiya | Connect hi block ho jata hai |
| A7 Parent ki file disk par badal di gayi | Seal refuse (registered hash match nahi karta) |
| A8 Parent ke naam se nakli ledger entry | Ledger reject karta hai (signature) |
| A9 Ledger history rewrite ki | Hash chain toot jaati hai, detect ho jata hai |
| A10 Revoke kiya hua device | Kuch nahi milta, queued kaam cancel ho jata hai |
| Prompt injection (`$(…)`) | Execute nahi hota |

**Kya protect NAHI hota (sach bolo):**
- Jis device par code chalta hai, wahan code decrypt hona hi hai. Agar attacker ke haath mein Pi physically hai (root access ke saath), toh woh code padh sakta hai. Iska hal hai TPM, secure boot, ya secure enclave wala hardware.
- Agar Parent Server ki apni key chori ho gayi, toh attacker "legit" code register kar sakta hai. Iske liye Parent key ko HSM ya KMS mein rakhna chahiye.
- Hack hua Pipeline koi **purana lekin registered** version bhej sakta hai (downgrade). Iske liye roadmap mein "minimum version pinning" hai.
- Trust pinning ek baar ka bharosa (TOFU) hai: enrollment ke waqt Pi par jo Parent address print hota hai, use Friend 1 se kisi alag channel (call ya chat) par confirm karo.
- DevNet asli blockchain nahi hai. Pitch aur demo mein "on-chain" dikhana ho toh `--ledger algorand` use karo.

---

## 8. Pitch mein kya bolo

✅ Ye claims sahi hain:
- "Pipeline poori tarah hack ho jaye, tab bhi device sirf wahi code chalayega jiska hash Parent ne Algorand par register kiya hai."
- "Har file sirf ek device ke liye encrypt hoti hai (X25519 + AES-256-GCM). Beech ka server code nahi padh sakta."
- "Har deployment aur uska result Algorand par permanent audit trail hai. Har record ki fee 0.001 ALGO hai."

❌ Ye claims mat karo:
- "100% tamper-proof" ya "bina blockchain ke MITM se nahi bach sakte". Signatures aur TLS se bina blockchain ke bhi bach sakte hain; blockchain ki value audit aur non-repudiation hai.
- "Sub-second finality". Algorand block ~3s ka hai, bas finality instant hai.
- XOR "masking" ko security bolna. Ab hum asli encryption use kar rahe hain.

---

## 9. Industry-grade banne ke liye (roadmap)

| Area | Abhi (MVP) | Production |
|---|---|---|
| Transport | HTTP | HTTPS (TLS) + mTLS for devices |
| Keys | JSON files (0600) | Parent/Pipeline: HSM/KMS. Pi: TPM 2.0 HAT |
| Parent key vs chain key | Ek hi key | Signing key aur chain key alag |
| DB | SQLite | PostgreSQL + backups |
| Auth | Admin token | Users, RBAC, SSO, 2FA |
| Payload size | Memory mein (theek hai ~100 MB tak) | Streaming + chunked encryption |
| Device sandbox | Unprivileged user + systemd hardening | Containers / namespaces, seccomp |
| Delivery | HTTP poll | MQTT / websockets, OTA rollback |
| Blockchain | Algorand client + DevNet | MainNet, receipts batch mein (Merkle root) taaki fee kam lage |
| Ops | Logs | Metrics, alerting, pentest, SOC2-style controls |

---

## 10. C++ kahan fit hoga

Core mein C++ ki zaroorat nahi hai. Python ki `hashlib` aur `cryptography` libraries andar se already C/OpenSSL mein chalti hain. C++17 ka sahi use **ESP32 / microcontroller Child** mein hai, jahan Python nahi chalta. Wahan ek chhota C++ firmware yahi 12 checks mbedTLS/libsodium se karega. Protocol same rahega (section 6).

---

## 11. Build prompt (kisi AI coding assistant ko extend karne ke liye)

```
You are extending "Valrix", a Python 3.9+ system with three services: parent_server/ (vaults, on-chain
registration, per-child sealing), pipeline/ (registry, binding, prompt->plan, signed manifests,
delivery) and child_server/ (Raspberry Pi agent with 12 verification checks incl. Algorand lookups).
Shared code is in common/ (Ed25519 identity with Algorand addresses, X25519+AES-GCM seal, stdlib
HTTP router) and blockchain/ (Algorand + DevNet). Only dependency: cryptography.
Rules: never let plaintext pass through the pipeline; never execute prompt text; every new message
between services must be signed with a new domain string; keep the API contract in ARCHITECTURE.md
section 6 backward compatible; add an attack test to tests/e2e.py for every new security claim.
Task: <what you want to add>
```
