# Consolidation: what was merged and what was dropped

Aapne 5 files/projects diye the jinme same system ke **3 alag-alag adhoore versions** the.
Maine unhe ek hi plug-and-play Python codebase (Valrix) mein consolidate kiya, redundant
cheezein hata di, aur aapke architecture diagram wala **block-vault** structure Parent Server
mein add kar diya.

## Input files → decision

| Input | Kya tha | Faisla |
|---|---|---|
| **valrix.zip** (mera Python build) | Poora chalta system: real Ed25519 + X25519/AES-GCM, Algorand + DevNet ledger, Child agent jo 12 checks karke code chalata hai, 29/29 tests | **Base — isi par sab banaya** |
| **pipeline_bridge_1.py** | Chhota toy: PID/CID generator + prompt parser, `CHANGE_ME_SALT`, XOR flag | **Drop** — `common/crypto.py` (real IDs/addresses) + `pipeline/prompt_engine.py` (allow-listed plan) isse behtar aur poora cover karte hain |
| **Pipeline/** zip (middle_pipe.py, service.py, algorand_ledger.py) | Ek doosra Middle-Pipe: SQLite + HMAC shared-secret API, job lifecycle states, LocalLedger vs Algorand — par real encryption/child agent nahi | **Drop, 2 ideas absorb** — job lifecycle aur Dockerfile idea liya. HMAC ki jagah Valrix ka Ed25519 device-signature model zyada strong hai |
| **subtrack…/parent-server-studio** (Node.js + HTML) | Visual UI + block-vault concept (block_01…05), dataset upload, packager — par **simulation only** ("packaged_simulation", koi real crypto/device nahi) | **Node code drop, 2 real concepts liye** — block-vault structure + dataset upload. Ab ye simulation nahi, real deployable bundle banata hai |

## Kya duplicate tha (isliye hataya)

- **Teen prompt parsers** (pipeline_bridge, Pipeline/middle_pipe intent, Node prompt_parser) → ek `pipeline/prompt_engine.py`.
- **Teen ID/hash schemes** (djb2 → nahi, pipeline_bridge sha256[:8], Node sha256, Valrix full sha256 + Ed25519) → ek `common/crypto.py` (full SHA-256 + Ed25519 Algorand addresses).
- **Teen ledger adapters** (Pipeline/algorand_ledger, Node simulated anchor, Valrix) → ek `blockchain/ledger.py` (Algorand + DevNet, same interface).
- **Do parent servers** (Node server.js, Valrix parent_server) → ek Python `parent_server/server.py`.
- **Do middle-pipes** (Pipeline/service.py, Valrix pipeline) → ek `pipeline/server.py`.
- **XOR "masking"** har jagah tha → hata diya, real X25519 + AES-256-GCM.

## Naya kya juda (aapke diagram se)

Parent Server mein ab wahi block-vault structure hai jo aapke diagram mein tha:

```
<data>/parent_server_root/dataset_vault/
    block_01_kernel/      Core Kernel & Math
    block_02_security/    Security & Crypto
    block_03_models/      Metrology Models
    block_04_hw_profiles/ Hardware Profiles
    block_05_blockchain/  Algorand SDK Hooks
    uploads/              validated CSV/JSON datasets
<data>/parent_server_root/package_builder/build_output/
```

- Har file upload hote waqt ek block ko assign hoti hai (`common/blocks.py`).
- **Dataset upload**: CSV/JSON (≤5 MB), validate + SHA-256 + on-chain register, `uploads/` mein save.
- **Package builder**: chune hue block files (+ ek dataset) ko ek **real .tar.gz** mein bundle karta hai
  jisme auto-generated `valrix.json` entrypoint aur `bundle_manifest.json` hota hai. Ye bundle ek
  normal deployable artifact ban jaata hai — pipeline use seal karke, on-chain anchor karke Child
  tak bhejta hai, aur Child use **actually unpack karke chalata hai** (test se verified).

Node studio yahan "packaged_simulation" par ruk jaata tha — ab ye asli deployment hai.

## Ab kitne tests

`python3 tests/e2e.py` → **41/41 pass** (pehle 29 the; 5 naye block/dataset/package checks jude,
jisme "packaged bundle Child par unpack hokar chala" bhi shamil hai).

## Baad mein juda: Prompt algebra

User-friendly prompt syntax (`+feature`, `-feature`, `->CHILD`, `*N`) `pipeline/prompt_algebra.py` mein add hui, jo plain-language prompt engine ke upar kaam karti hai. Ye bhi allow-listed hai — sirf env/mode toggle karti hai, shell mein kuch nahi jata. Normal English/Hinglish prompts pehle jaise chalte hain.
