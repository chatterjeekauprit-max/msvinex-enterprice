# Manvinex / Valrix Production & Deployment Manual
*(Software Delivery + Edge Server Management + Hardware-Aware Security)*

**Manvinex / Valrix**: The Plug-and-Play Zero-Trust Hardware & Software Deployment Fabric.
Software respects the hardware: preserve what works, change only what is required.
Includes Silicon Fingerprinting (PUF), Dynamic Compartmentalization (Block-A / Block-B), Process & Health Monitoring, Hardware Engine, and Robotics & Automation Adapters.

---

## 1. Quickstart: 1-Click Execution

### Windows (Native 1-Click Desktop Application)
**Simply double-click `Manvinex.exe` (or `Valrix.exe`)!**
- Launches the native Windows Desktop Control Center app.
- Automatically spins up the backend services on `0.0.0.0` (all network interfaces).
- **Direct Tool Launch**: Automatically opens your browser directly to the dashboard with auto-login enabled!
- Shows a sleek desktop window with a **"📋 Copy Shareable Link"** button to share with others on your WiFi/hotspot immediately.

Alternatively, you can run in terminal or command prompt:
```cmd
.\manvinex.bat demo --fresh
```
*(Or `manvinex host` to host with shareable links).*

### Linux / macOS / Raspberry Pi
Make executable and run:
```bash
chmod +x *.sh valrix.sh manvinex.sh
./start_demo.sh
```

### Docker Compose (Production Multi-Container Stack)
```bash
docker compose up -d
```
All four services (`devnet`, `parent`, `pipeline`, `child`) will boot with volume persistence, automatic health checks, and network isolation.

---

## 2. System Architecture & Default Ports

| Service | Port | Endpoint / Health | Description |
|---|---|---|---|
| **Pipeline (Web UI)** | `8000` | `http://127.0.0.1:8000/health` | Central orchestrator, Prompt Engine, UI, MDU Ledger |
| **Parent Server** | `8100` | `http://127.0.0.1:8100/health` | Secure Vault, iLovePDF Drag-and-Drop, Universal Ingest |
| **Child Server** | `8200` | `http://127.0.0.1:8200/health` | Edge / Robot controller sandbox (12/12 checks) |
| **DevNet Ledger** | `8700` | `http://127.0.0.1:8700/health` | Private permissioned immutable blockchain ledger |

---

## 3. Universal Ingestion: Take Input from Anywhere

Manvinex accepts code and workloads from any source:
1. **iLovePDF-Style Drag-and-Drop**: Drop files or packages directly into the Parent Server web dashboard (`http://127.0.0.1:8100/`).
2. **Local Folder / File Path Ingestion**: Click **"📁 Import Local Folder/File"** in the web UI or run:
   ```bash
   manvinex ingest ./examples/drone_robotics_patrol/ --parent DRONE
   ```
3. **Remote Git / HTTP URL Ingestion**: Click **"🌐 Import from URL / Git"** to download raw code or archives straight into the vault.
4. **Direct Code Creation**: Click **"📝 Paste Code"** to write or paste code in the UI and anchor it directly on the blockchain.
5. **Turnkey 1-Command Quick-Deploy**:
   ```bash
   manvinex quick-deploy ./examples/drone_robotics_patrol/
   ```
   *(Ingests, registers on blockchain, binds to target child, runs 12-step verification, signs receipt, and prints live execution logs in one command!)*

---

## 4. Unified CLI Reference (`manvinex` / `valrix`)

Both commands work identically:

```bash
# 1. 1-Command Turnkey Deployment from any file/directory:
manvinex quick-deploy <path_to_code_or_folder> [--child <child_id>] [--prompt <prompt>]

# 2. Universal Ingestion into Parent Vault:
manvinex ingest <path_to_file_or_dir> [--parent <parent_id>]

# 3. Commercial MDU Accounting & Margin Inspection:
manvinex mdu

# 4. Check system readiness, dependencies, and network ports:
manvinex doctor

# 5. Check health and status of all services:
manvinex status

# 6. Launch full turnkey demo environment:
manvinex demo [--fresh] [--lan] [--base-port 8000]

# 7. Start / Stop individual services:
manvinex start [all | pipeline | parent | child | devnet] [--daemon]
manvinex stop [all | pipeline | parent | child | devnet]

# 8. Run 54+ automated verification tests:
manvinex test

# 9. Enroll remote child node:
manvinex enroll --pipeline http://<IP>:8000 --child-id CHILD_ROBOT_01 --token <TOKEN> --trust-parent http://<IP>:8100

# 10. Open Web Dashboard:
manvinex gui
```

---

## 5. Commercial Unit: MDU (Manvinex Deployment Unit)

* **Definition**: 1 MDU = One validated deployment workload (Payload + Dependencies + Hardware Profile + ALLOW Cycle).
* **Commercial Pricing**: **₹2.00 – ₹5.00** per MDU (baseline: **₹3.50**).
* **COGS Efficiency**: **₹0.60** / MDU.
* **Gross Profit Margin**: **~82.8%**.
* **Settlement**: Every MDU is cryptographically receipted and settled on the private blockchain ledger. View metrics live via `manvinex mdu` or the **MDU Metering** tab in the Pipeline UI.

---

## 4. Live Impressive Demo: Step-by-Step Guide

Here is the exact step-by-step workflow to showcase Valrix for a high-impact presentation or demo:

### Step 1: Start the System
```bash
valrix demo --fresh
```
*Note down the admin tokens printed in the terminal for Pipeline (`http://127.0.0.1:8000/`) and Parent (`http://127.0.0.1:8100/`).*

### Step 2: Open Parent Server (`http://127.0.0.1:8100/`)
1. Paste the Parent Admin Token.
2. Experience the **iLovePDF-style Drag-and-Drop Hero Interface**:
   - Click **"Select Code & Data Files"** or drag files directly from `examples/drone_robotics_patrol/`:
     - `drone_patrol.py` (Python Code)
     - `safety_verifier.py` (Supporting Module)
     - `flight_waypoints.json` (Dataset)
   - See file cards staged in real-time with icons (🐍 Python, 📊 Dataset, ⚡ Shell).
   - Click **"⚡ Register & Anchor File(s) on Blockchain"**.
   - Watch the animated progress bar calculate SHA-256 fingerprints and anchor transactions directly onto the immutable ledger.
3. Click **"Create Capability"**:
   - Capability Name: `autonomous_patrol`
   - Main file: `drone_patrol.py`
   - Entrypoint: `python3 drone_patrol.py`
   - Dataset: `flight_waypoints.json`

### Step 3: Open Pipeline Dashboard (`http://127.0.0.1:8000/`)
1. Paste the Pipeline Admin Token.
2. Go to **"Robotics & Automation"** tab:
   - Select machine class: **Autonomous Drone / UAV** or **Industrial Robot Arm**.
   - Review fault location hierarchy (`motor-fl`, `motor-fr`, `battery`, `gps`, `imu`, `lidar`).
   - Click **"Send Telemetry Report"** to simulate live health status in the Process Monitor.
3. Go to **"Secure Fabric"** tab:
   - Inspect **Silicon Fingerprinting (PUF)**: physical MAC address and Silicon PUF register.
   - Inspect **Dynamic Compartmentalization (Block-A / Block-B)**:
     - Active Container: `Block-A`
     - Shadow Container: `Block-B (Standby)`
   - Click **"Simulate Tamper Tripwire & Trigger CDRP Purge"**:
     - Watch sub-millisecond CDRP zero-downtime hot-swap failover to `Block-B`!
4. Go to **"Pipeline"** tab:
   - Select Parent Vault: `Robotics & Automation Parent Server`
   - Select Child Node: `CHILD_RPI_01` (or `CHILD_ROBOT_01`)
   - Click **"Connect & Continue"** (Passes all 4 compatibility checks).
   - Select capability: `autonomous_patrol (+ AUTONOMOUS_PATROL)`.
   - Prompt:
     ```
     + AUTONOMOUS_PATROL -> CHILD_RPI_01 MODE=patrol SPEED=high
     ```
   - Click **"Preview plan"** (Verify safe allow-listed plan without shell injection).
   - Click **"Deploy"**:
     - Live timeline displays:
       - 1) Parent seals ciphertext exclusively for Child's public key.
       - 2) Pipeline anchors deployment manifest on-chain.
       - 3) Child pulls payload and executes all 12 zero-trust verification steps.
       - 4) Code executes safely inside Block-A.
       - 5) Signed cryptographic receipt anchored on blockchain!

---

## 5. Multi-Node Production Setup (3 Distinct Machines)

To run across different physical machines on the same LAN/WiFi:

### Machine 1: Parent Server (Developer / Code Vault)
```bash
valrix start parent --host 0.0.0.0 --port 8100 --ledger devnet --devnet-url http://<PIPELINE_IP>:8700
```

### Machine 2: Pipeline Orchestrator + DevNet (Control Server)
```bash
valrix start devnet --host 0.0.0.0 --port 8700
valrix start pipeline --host 0.0.0.0 --port 8000 --public-url http://<PIPELINE_IP>:8000 --ledger devnet --devnet-url http://<PIPELINE_IP>:8700
```

### Machine 3: Child Server (Raspberry Pi / Edge Robot)
```bash
# 1. On Pi: install cryptography
sudo apt update && sudo apt install -y python3-cryptography

# 2. Enroll using token generated in Pipeline dashboard:
valrix enroll --pipeline http://<PIPELINE_IP>:8000 \
              --child-id CHILD_RPI_01 \
              --token <ENROLL_TOKEN> \
              --trust-parent http://<PARENT_IP>:8100

# 3. Start Child loop:
valrix start child --status-port 8200
```

---

## 6. Algorand TestNet / MainNet Mode (Real Blockchain)
To switch from local DevNet to real Algorand TestNet:
1. Replace `--ledger devnet` with `--ledger algorand --network testnet`.
2. Fund the generated Algorand addresses using the free TestNet Dispenser.
3. Every deployment and receipt will generate live exploreable transactions on `lora.algokit.io/testnet`.

---

## 7. Automated Production Installation (Debian / Ubuntu / Raspberry Pi OS)
To install Valrix as background production systemd services:
```bash
sudo bash deploy/install_systemd.sh
```
This automatically configures the unprivileged `valrix` user, hardened read-only paths, auto-restart policies, and systemd units for all components.
