# Valrix implementation status

This status describes the code in this archive, not the aspirational feature brief.

## Present in the project

- Parent artifact vault with hashes, sealed deployment packages, capabilities, and package upload.
- Pipeline prompt-to-plan parser with an allow-listed deployment plan; prompts do not become shell commands.
- Linux/Python Child enrollment, package verification, install/run modes, signed receipts, and local DevNet/Algorand ledger adapters.
- Process-monitor API and robotics metadata adapter.
- Hardware-family catalog, CLI availability reporting, PlatformIO project upload path, and limited UF2/picotool upload.

## Not implemented or not proven here

- Silicon PUF, MAC-plus-PUF challenge response, or hardware-rooted spoof-proof identity. Child identity currently uses cryptographic software keys.
- Block-A/Block-B isolation, kernel-level purge, hot failover, or zero-packet-loss guarantees.
- Burn-and-Bind hardware identity migration or biometric/liveness checks.
- Automatic MCU/USB discovery; remote USB flashing through a Child; Arduino IDE project import; arbitrary library inference, recommendation, or downloads from Parent artifacts.
- Generic flashing/build support for every listed MCU. PlatformIO source upload requires a valid, board-matched project. STM32, Nordic, GD32, CH32, and custom-board flows need their specific tested toolchains and hardware; WCH-Link is not implemented.
- Automatic health telemetry collection from motors, sensors, batteries, PLCs, or robots. The process-monitor API can record health reports when an integration sends them.
- Execution of unrestricted natural-language prompts. Plans are intentionally constrained for security.

## Verification performed

- `tests/e2e.py`: 41/41 checks passed on Windows after fixing service process termination portability.
- `tests/algorand_mock.py`: passed against its local mock node.
- Python syntax compilation passed for the changed Python modules.
- Physical MCU uploads and vendor library downloads were not tested; no supported flashing CLI or MCU was available on the test host.
