# Raspberry Pi ko asli Child Server banao (same WiFi)

Laptop aur Pi ek hi WiFi par hone chahiye. Ye guide DevNet (local blockchain) ke saath hai —
sabse aasaan. (Asli Algorand TestNet ke liye neeche "TestNet" section dekho.)

---

## Sabse aasaan: ek command se device add karo (naya)

`deploy/add_device.py` kisi bhi Linux device (Pi/SBC) ko SSH se **khud probe** karta hai,
capability/limitation ka report deta hai (camera hai kya, RAM, kya-kya chalega), aur exact
setup steps banata hai — ya `--setup` se khud install + copy + enroll kar deta hai. Ye REAL
Valrix ke upar baithta hai (crypto/blockchain ko haath nahi lagata).

```
# 1) Sirf report + guide (kuch badlega nahi — safe):
python deploy/add_device.py --host dronepi.local --user sutirtha_halder

# 2) Setup khud kar do (deps install + valrix copy):
python deploy/add_device.py --host dronepi.local --user sutirtha_halder --setup --valrix-dir .

# 3) Setup + enroll ek saath (token dashboard -> Child Servers se):
python deploy/add_device.py --host dronepi.local --user sutirtha_halder --setup --valrix-dir . \
       --enroll --child-id CHILD_RPI --token enr_xxxx \
       --pipeline http://<LAPTOP_IP>:8000 --trust-parent http://<LAPTOP_IP>:8100
```

Design: **hardware** issues (camera lagao/enable karo) ye **suggest** karta hai; **software**
(dependencies, valrix copy, enroll) ye **khud kar deta hai**. MCU (ESP32/Arduino) ka serial-flash
ismein shaamil nahi — wo alag adapter hai. Ye tool sirf network/SSH-reachable Linux devices ke liye.

Neeche wale manual steps bhi kaam karte hain (ya tab use karo jab ye tool na chalao):

---

## Step 1 — Laptop par: servers ko LAN par kholo

```
python run_demo.py --fresh --lan
```

- Windows **firewall popup** aaye to **Allow** karo (warna Pi connect nahi hoga).
- Terminal mein niche **"CONNECT A REAL RASPBERRY PI"** section aayega, jisme:
  - Laptop ka LAN IP (jaise `192.168.1.50`) already bhara hoga.
  - Do commands jo **Pi par paste** karni hain (enroll + run).
- Ye do command **copy** kar lo.

> Port 8000 Windows par busy ho to: `python run_demo.py --fresh --lan --base-port 9000`

---

## Step 2 — Pi par: folder + dependencies

1. Poori **`valrix` folder Pi par copy** karo (USB, `scp`, ya git — jo aasaan lage).
2. Pi ke terminal mein us folder ke andar:

```
cd valrix
pip install cryptography          # ya: sudo apt install python3-cryptography
bash deploy/setup_pi.sh           # OpenCV + camera (v2 cam ke liye)
```

(Camera enable hai na? `sudo raspi-config` → Interface Options → Camera → Enable, phir reboot.)

---

## Step 3 — Pi par: enroll + run

Laptop ne jo do commands di thi, wahi Pi par chalao (IP/token already sahi honge):

```
python3 -m child_server enroll --pipeline http://<LAPTOP_IP>:8000 --child-id CHILD_RPI --token enr_xxxxx --trust-parent http://<LAPTOP_IP>:8100
python3 -m child_server run
```

- `enroll` ek baar chalega (device ki keys Pi par banengi).
- `run` chalta rahega — Pi ab Pipeline se kaam poll karega.
- Enroll ke waqt jo **Parent address** print ho, wo laptop ke Parent UI wale address se match karna chahiye (security check).

Background mein hamesha chalane ke liye: `deploy/valrix-child.service` (systemd) use karo.

---

## Step 4 — Laptop se deploy karo (asli camera!)

Pipeline dashboard (`http://<LAPTOP_IP>:8000`) mein:
1. **Computer Vision Parent Server** + **CHILD_RPI** chuno → **Connect & Continue**.
2. Prompt:
   ```
   + HUMAN_DETECTION -> CHILD_RPI SOURCE=camera MAX_FRAMES=0
   ```
   (`SOURCE=camera` = asli v2 camera; `MAX_FRAMES=0` = tab tak chalta rahe jab tak stop na karo.)
3. **Deploy** → live timeline: seal → on-chain → 12 checks → Pi par human detection chalu.

`+ MOTION_DETECTION` / `+ FACE_DETECTION` bhi try karo. Har baar **sirf wahi ek algo** Pi par jaata hai.

Pi ka live status: `http://<PI_IP>:8200/status` (recent detections + history).

---

## Common dikkatein

| Problem | Fix |
|---|---|
| Pi "cannot reach" / timeout | Firewall (laptop) allow karo; dono same WiFi par ho; laptop IP sahi ho (`ipconfig` se check) |
| `cannot reach ...:8700` | DevNet bhi LAN par chahiye — `--lan` ise already 0.0.0.0 par kholta hai; firewall allow karo |
| Camera nahi khulti | `raspi-config` se camera enable; `bash deploy/setup_pi.sh`; reboot |
| `No module named cv2` | Pi par `bash deploy/setup_pi.sh` (ya `sudo apt install python3-opencv`) |
| Enroll "token expired" | Laptop dashboard → Child Servers → CHILD_RPI → "New token", nayi command use karo |

---

## Asli Algorand TestNet (optional, sabse strong proof)

DevNet ki jagah real blockchain: laptop par saare services `--ledger algorand --network testnet`
se chalao (README section 4), Parent+Pipeline accounts ko TestNet dispenser se fund karo. Pi ko
kuch nahi chahiye — wo seedha public Algorand indexer se hash verify karta hai, aur dashboard mein
har record ka **explorer link** (lora.algokit.io) khulta hai. Yahi "sach mein on-chain" wala proof hai.
