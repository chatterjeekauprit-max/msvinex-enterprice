# Valrix: Blockchain-verified Parent → Child deployment

**Parent Server** (code vault) → **Pipeline** (binding + prompt) → **Child Server** (Raspberry Pi), aur beech mein **Algorand blockchain** verification.
Poora design aur API contract: **[ARCHITECTURE.md](ARCHITECTURE.md)**. Kya-kya merge/drop hua: **[CONSOLIDATION.md](CONSOLIDATION.md)**. Asli Raspberry Pi jodna: **[PI_SETUP.md](PI_SETUP.md)** (`python run_demo.py --lan`).

Sirf ek dependency hai: `cryptography`. Baaki sab Python standard library hai (3.9+), isliye Raspberry Pi par bhi seedha chalta hai.

```
pip install cryptography        # Raspberry Pi OS:  sudo apt install python3-cryptography
```

---

## 1. Ek command mein demo (sab kuch ek hi machine par)

```bash
python3 run_demo.py --fresh
```

Ye DevNet ledger, Parent Server, Pipeline aur ek Child Server start karta hai. Saath mein 2 vaults aur sample code seed karta hai, aur child ko enroll kar deta hai. Terminal mein URLs aur admin tokens print honge.

1. `http://127.0.0.1:8000` kholo, Pipeline admin token paste karo.
2. **Pipeline** tab: `PARENT_01` aur `CHILD_RPI_01` chuno, phir **Connect & Continue**.
3. Prompt likho (jaise *"Execute Valrix Metrology Engine with dynamic masking, timeout 2 min"*), **Preview plan**, phir **Deploy**.
4. Live timeline mein dikhega: seal → on-chain registration check → anchor → 12/12 checks → run → receipt on-chain.

Parent Server ka UI `http://127.0.0.1:8100` par hai (file upload aur seal audit log ke liye).

## 1b. Computer-vision demo (prompt picks the algo)

`run_demo.py` ek `PARENT_CV` vault seed karta hai jisme 3 capabilities hain: `motion_detection`,
`face_detection`, `human_detection` (sab OpenCV, Pi-ready). Pipeline mein:

1. `PARENT_CV` + `CHILD_RPI_01` → Connect & Continue.
2. Prompt: `+ MOTION_DETECTION -> CHILD_RPI_01` → Deploy. Sirf wahi algo Child par jaata hai aur chalta hai.
3. `+ FACE_DETECTION` / `+ HUMAN_DETECTION` bhi try karo.

Asli Raspberry Pi + camera par: pehle `bash deploy/setup_pi.sh` chalao, phir capability ko
`SOURCE=camera` ke saath deploy karo (jaise `+ HUMAN_DETECTION -> CHILD_RPI_01 SOURCE=camera MAX_FRAMES=0`).

## 2. Tests

```bash
python3 tests/e2e.py            # 4 real services + full flow + 10 attack scenarios (41 checks)
python3 tests/algorand_mock.py  # Algorand client against a mock algod/indexer
```

---

## 3. Asli setup: teen alag machines

Neeche `<PIPELINE_IP>` aur `<PARENT_IP>` ki jagah apni LAN IPs daalo. Commands project folder ke andar se chalao.

### Friend 1: Parent Server
```bash
python3 -m parent_server.server --host 0.0.0.0 --port 8100 --data ./data/parent --ledger devnet --devnet-url http://<PIPELINE_IP>:8700
```
Terminal mein **admin token** (UI ke liye) aur **pipeline token** (Pipeline operator ko dene ke liye) print honge. UI kholo: `http://<PARENT_IP>:8100`. Ek Parent Server banao (naam do, jaise 'Drone Parent Server' — ID auto). Files **drag-and-drop** karo. CSV/JSON **dataset** bhi drop kar sakte ho. Phir **Capability** banao (naam + files) taaki prompt `+ NAME` se deploy ho, ya **Package builder** se manual bundle banao.

Bundle ke andar `valrix.json` → `{"entrypoint": ["python3", "main.py"]}` rakho, ya sirf `main.py` / `run.sh`.

### Pipeline (+ DevNet, agar offline chala rahe ho)
```bash
python3 -m blockchain.devnet --host 0.0.0.0 --port 8700 --data ./data/devnet
python3 -m pipeline.server --host 0.0.0.0 --port 8000 --data ./data/pipeline \
        --public-url http://<PIPELINE_IP>:8000 --ledger devnet --devnet-url http://<PIPELINE_IP>:8700
```
Dashboard ke **Parent Servers** tab mein Parent ka URL aur pipeline token daalo. **Child Servers** tab mein Child ID banao, enrollment commands copy karo.

### Friend 2: Child Server (Raspberry Pi)
```bash
python3 -m child_server --data ~/.valrix-child enroll --pipeline http://<PIPELINE_IP>:8000 \
        --child-id CHILD_RPI_01 --token enr_xxx --trust-parent http://<PARENT_IP>:8100
python3 -m child_server --data ~/.valrix-child run --status-port 8200
```
Enrollment ke time jo Parent address print hota hai, use Friend 1 se confirm kar lo. Hamesha chalane ke liye `deploy/valrix-child.service` (systemd, unprivileged user, read-only OS) use karo.

Aur Parent Servers trust karne ke liye: `python3 -m child_server trust-parent http://<OTHER_PARENT>:8100`

---

## 4. Algorand TestNet par chalana (asli blockchain)

Sab services mein `--ledger devnet …` hata kar `--ledger algorand --network testnet` lagao. Child ko Pipeline se ledger config apne aap mil jata hai (ya `enroll --ledger-override algorand` do). Child sirf public indexer se padhta hai, isliye use ALGO ki zaroorat nahi hai.

Parent Server aur Pipeline har record likhne par 0.001 ALGO fee dete hain, isliye unhe fund karna padega:

```bash
python3 -m blockchain.account show --data ./data/parent      # address + balance
python3 -m blockchain.account show --data ./data/pipeline
```
Dono addresses ko **Algorand TestNet dispenser** se fund karo (test ALGO free milte hain). Explorer links dashboard mein Lora (`lora.algokit.io/testnet/...`) par khulte hain.

Pehle se koi Algorand account hai? `python3 -m blockchain.account import --data ./data/parent --key <base64 key>` (key algosdk ke `mnemonic.to_private_key()` se nikalti hai).

> Note: Algorand client (msgpack transaction encoding aur signing) ek mock node ke against test hua hai. Jis sandbox mein ye bana, wahan se Algorand TestNet reachable nahi tha, isliye pehla live anchor khud chala ke confirm kar lena. Agar node transaction reject kare, toh error message dashboard ya terminal mein dikhega.

---

## 5. Folder structure

```
common/         crypto.py (identity, Algorand addresses, seal), web.py (HTTP + signed requests), db.py, plan.py, static/
blockchain/     ledger.py (Algorand + DevNet clients), algorand_codec.py, devnet.py (local ledger), account.py
parent_server/  server.py + static/index.html      ← Friend 1 (named folders, drag-drop, capabilities)
pipeline/       server.py, prompt_engine.py, prompt_algebra.py + static/index.html
child_server/   child.py (+ __main__.py)            ← Friend 2
deploy/         systemd units + setup_pi.sh (installs OpenCV/camera on the Pi)
examples/       sample Parent code + bundle; cv_algos/ (motion/face/human detection, OpenCV)
tests/          e2e.py, algorand_mock.py
run_demo.py     one-command local demo
```

## 6. Production se pehle (short list)

HTTPS/mTLS, keys ko HSM/KMS aur Pi par TPM mein rakhna, PostgreSQL, user accounts/RBAC, streaming for big payloads, container sandboxing, version pinning, aur ek external pentest. Poori list ARCHITECTURE.md section 9 mein hai.

---

## Hardware Engine (experimental)

The MCU tab reports common flash-tool availability. Its verified source path requires a local PlatformIO project with `platformio.ini`; PlatformIO performs the board-specific build and upload on the Pipeline host. Standalone firmware upload is limited to UF2 on picotool-compatible boards. The catalog includes MCU family metadata but does not provide universal drivers or guarantee that every listed board is supported. See `hardware_engine/README.md` for current limitations.

---

## Process Monitoring Block (new)

**Process Monitoring Block** tracks Active vs Passive processes on Child Servers.

- **Active** — installed via Pipeline and still linked (live monitoring possible)
- **Passive** — installed once, no remaining connection (history only)

User can set name, use-case text and custom options. No hard-coded example apps are included.

See `process_monitor/README.md`.

---

## Final Combined Version

This tree now includes:

- Original Parent → Pipeline → Child
- Hardware Engine
- Process + Health Monitoring
- **Robotics & Automation** adapter (`robotics/`)
- Full combined specification: **VALRIX_FINAL_COMBINED.md** (Secure Fabric + Pipeline + Robotics)

Works for robotics, manufacturing automation, software, and hybrid cloud/offline.
