@echo off
title Manvinex Enterprise Control Center (500 MB)
cd /d "%~dp0"
chcp 65001 >nul
set PYTHONUTF8=1

echo ================================================================
echo  ⚡ MANVINEX ENTERPRISE DEEP-TECH CONTROL CENTER (500 MB)
echo ================================================================
echo.
echo  Booting Private Blockchain, Parent Vault, and Pipeline...
echo  (Your browser will automatically open in a few seconds)
echo.

rem Try Python 3.13 first (has cryptography), then fallback to py or python
py -3.13 host_server.py
if %errorlevel% neq 0 (
    py -3 host_server.py
    if %errorlevel% neq 0 (
        python host_server.py
    )
)

echo.
echo Server stopped.
pause
