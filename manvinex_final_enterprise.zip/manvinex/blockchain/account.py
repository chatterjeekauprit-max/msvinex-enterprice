"""
Blockchain account helper. Each service's identity key IS its Algorand account.

  python3 -m blockchain.account show   --data ./data/parent       # address + balance
  python3 -m blockchain.account import --data ./data/parent --key <base64 64-byte key>
  python3 -m blockchain.account export --data ./data/parent       # base64 key for algosdk / wallets

Fund the shown address on TestNet with the Algorand TestNet dispenser before using --ledger algorand.
Each anchor costs the minimum fee (0.001 ALGO).
"""
from __future__ import annotations

import argparse
import os

from common.crypto import Identity, b64e

from .ledger import AlgorandLedger


def main():
    p = argparse.ArgumentParser(prog="blockchain.account")
    p.add_argument("cmd", choices=["show", "import", "export"])
    p.add_argument("--data", required=True, help="service data dir (contains identity.json)")
    p.add_argument("--key", help="base64 Algorand private key (import)")
    p.add_argument("--network", default="testnet")
    a = p.parse_args()
    path = os.path.join(a.data, "identity.json")
    if a.cmd == "import":
        if os.path.exists(path):
            raise SystemExit(f"{path} already exists - move it away first (this would change the service identity)")
        ident = Identity.from_algorand_private_key(a.key)
        ident.save(path)
        print(f"imported {ident.address}")
        return
    if not os.path.exists(path):
        raise SystemExit(f"no identity at {path} - start the service once to create it")
    ident = Identity.load_or_create(path)
    if a.cmd == "export":
        print(b64e(ident._seed + ident.pub))
        return
    print(f"address : {ident.address}")
    bal = AlgorandLedger(a.network).balance(ident.address)
    print(f"balance : {bal / 1e6:.6f} ALGO ({a.network})" if bal is not None else "balance : unavailable (offline?)")


if __name__ == "__main__":
    main()
