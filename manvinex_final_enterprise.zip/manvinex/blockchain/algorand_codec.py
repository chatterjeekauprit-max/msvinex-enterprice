"""
Minimal Algorand transaction codec (no algosdk needed).

Algorand transactions are canonical msgpack maps: keys sorted, zero/empty values omitted,
smallest integer encoding. We only need one transaction type: a 0-ALGO self-payment whose
`note` field (max 1024 bytes) carries the Valrix record.

  signature = Ed25519(b"TX" + msgpack(txn))
  txid      = base32(SHA-512/256(b"TX" + msgpack(txn)))   (no padding, 52 chars)
  wire      = msgpack({"sig": signature, "txn": txn})     -> POST /v2/transactions
"""
from __future__ import annotations

import base64
import struct

from common.crypto import address_to_pub, sha512_256


def _pack(obj) -> bytes:
    if isinstance(obj, bool):
        return b"\xc3" if obj else b"\xc2"
    if isinstance(obj, int):
        if obj < 0:
            raise ValueError("negative ints not needed for Algorand payment txns")
        if obj < 0x80:
            return bytes([obj])
        if obj <= 0xFF:
            return b"\xcc" + struct.pack(">B", obj)
        if obj <= 0xFFFF:
            return b"\xcd" + struct.pack(">H", obj)
        if obj <= 0xFFFFFFFF:
            return b"\xce" + struct.pack(">I", obj)
        return b"\xcf" + struct.pack(">Q", obj)
    if isinstance(obj, str):
        b = obj.encode()
        n = len(b)
        if n < 32:
            return bytes([0xA0 | n]) + b
        if n <= 0xFF:
            return b"\xd9" + struct.pack(">B", n) + b
        if n <= 0xFFFF:
            return b"\xda" + struct.pack(">H", n) + b
        return b"\xdb" + struct.pack(">I", n) + b
    if isinstance(obj, (bytes, bytearray)):
        n = len(obj)
        if n <= 0xFF:
            return b"\xc4" + struct.pack(">B", n) + bytes(obj)
        if n <= 0xFFFF:
            return b"\xc5" + struct.pack(">H", n) + bytes(obj)
        return b"\xc6" + struct.pack(">I", n) + bytes(obj)
    if isinstance(obj, dict):
        items = [(k, v) for k, v in sorted(obj.items()) if not _is_empty(v)]
        n = len(items)
        head = bytes([0x80 | n]) if n < 16 else b"\xde" + struct.pack(">H", n)
        return head + b"".join(_pack(k) + _pack(v) for k, v in items)
    raise TypeError(f"cannot msgpack {type(obj)}")


def _is_empty(v) -> bool:
    return v is None or v == 0 or v == b"" or v == "" or v == {} or v is False


def build_note_txn(sender: str, note: bytes, params: dict) -> dict:
    """0-ALGO payment from sender to itself carrying `note`. `params` = algod /v2/transactions/params JSON."""
    if len(note) > 1024:
        raise ValueError("Algorand note field is limited to 1024 bytes")
    first = int(params["last-round"])
    txn = {
        "fee": 0,
        "fv": first,
        "lv": first + 1000,
        "gen": params["genesis-id"],
        "gh": base64.b64decode(params["genesis-hash"]),
        "note": note,
        "rcv": address_to_pub(sender),
        "snd": address_to_pub(sender),
        "type": "pay",
    }
    # Suggested fee is per byte (usually 0 unless the network is congested); never below min-fee.
    est_size = len(_pack({"sig": b"\x00" * 64, "txn": {**txn, "fee": 0xFFFFFFFF}}))
    txn["fee"] = max(int(params.get("min-fee", 1000)), int(params.get("fee", 0)) * est_size, 1000)
    return txn


def txn_bytes_to_sign(txn: dict) -> bytes:
    return b"TX" + _pack(txn)


def txid(txn: dict) -> str:
    return base64.b32encode(sha512_256(txn_bytes_to_sign(txn))).decode().rstrip("=")


def sign_txn(identity, txn: dict) -> tuple[str, bytes]:
    """Returns (txid, wire bytes for POST /v2/transactions)."""
    sig = identity.sign_raw(txn_bytes_to_sign(txn))
    return txid(txn), _pack({"sig": sig, "txn": txn})
