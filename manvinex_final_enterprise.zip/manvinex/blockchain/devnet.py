"""
Valrix DevNet: a local, single-node, hash-chained ledger for offline development and demos.

It mirrors the parts of Algorand that Valrix relies on:
  - every record has an authenticated sender (Ed25519 signature, Algorand-format address)
  - records are append-only and each links to the previous one by hash
  - notes are limited to 1024 bytes

It is NOT a blockchain in the decentralised sense (one node, one operator). Use it to develop
offline; use `--ledger algorand` for anything you show as "on-chain".

Run:  python -m blockchain.devnet --port 8700 --data ./data/devnet
"""
from __future__ import annotations

import argparse
import base64
import json
import os
import threading
import time

from common.crypto import b64d, canonical, is_address, sha256_hex, sha512_256, verify_obj
from common.web import App, HTTPError

GENESIS = "0" * 64


class Chain:
    def __init__(self, data_dir: str):
        os.makedirs(data_dir, exist_ok=True)
        self.path = os.path.join(data_dir, "chain.jsonl")
        self.lock = threading.Lock()
        self.blocks: list[dict] = []
        self.by_txid: dict[str, dict] = {}
        if os.path.exists(self.path):
            with open(self.path) as f:
                for line in f:
                    if line.strip():
                        b = json.loads(line)
                        self.blocks.append(b)
                        self.by_txid[b["txid"]] = b

    @staticmethod
    def block_hash(b: dict) -> str:
        return sha256_hex(canonical({k: v for k, v in b.items() if k != "hash"}))

    def append(self, sender: str, note_b64: str, ts: int, sig: str) -> dict:
        txid = base64.b32encode(sha512_256(b"VTX" + canonical(
            {"note": note_b64, "sender": sender, "sig": sig, "ts": ts}))).decode().rstrip("=")
        with self.lock:
            if txid in self.by_txid:
                return self.by_txid[txid]
            prev = self.blocks[-1]["hash"] if self.blocks else GENESIS
            b = {"round": len(self.blocks) + 1, "txid": txid, "sender": sender, "note": note_b64,
                 "ts": ts, "sig": sig, "prev": prev}
            b["hash"] = self.block_hash(b)
            with open(self.path, "a") as f:
                f.write(json.dumps(b) + "\n")
                f.flush()
                os.fsync(f.fileno())
            self.blocks.append(b)
            self.by_txid[txid] = b
            return b

    def verify(self) -> dict:
        prev = GENESIS
        for b in self.blocks:
            if b["prev"] != prev or self.block_hash(b) != b["hash"]:
                return {"ok": False, "broken_at_round": b["round"]}
            if not verify_obj(b["sender"], "devnet-tx", {"note": b["note"], "sender": b["sender"], "ts": b["ts"]},
                              b["sig"]):
                return {"ok": False, "bad_signature_at_round": b["round"]}
            prev = b["hash"]
        return {"ok": True, "rounds": len(self.blocks), "head": prev}


def build_app(chain: Chain, quiet=False) -> App:
    app = App("devnet", quiet)

    @app.route("GET", "/health")
    def health(req):
        return {"network": "valrix-devnet", "dev_only": True, "round": len(chain.blocks)}

    @app.route("POST", "/v2/tx")
    def submit(req):
        d = req.json()
        sender, note, ts, sig = d.get("sender"), d.get("note", ""), d.get("ts"), d.get("sig", "")
        if not (isinstance(sender, str) and is_address(sender)):
            raise HTTPError(400, "invalid sender address")
        if not isinstance(ts, int) or abs(time.time() - ts) > 300:
            raise HTTPError(400, "timestamp missing or out of range")
        try:
            if len(b64d(note)) > 1024:
                raise HTTPError(400, "note exceeds 1024 bytes")
        except (ValueError, TypeError):
            raise HTTPError(400, "note must be base64") from None
        if not verify_obj(sender, "devnet-tx", {"note": note, "sender": sender, "ts": ts}, sig):
            raise HTTPError(401, "bad transaction signature")
        b = chain.append(sender, note, ts, sig)
        return {"txid": b["txid"], "round": b["round"]}

    @app.route("GET", "/v2/tx/{txid}")
    def get_tx(req):
        b = chain.by_txid.get(req.params["txid"])
        if not b:
            raise HTTPError(404, "transaction not found")
        return b

    @app.route("GET", "/v2/chain")
    def list_chain(req):
        limit = min(int(req.query.get("limit", 50)), 500)
        return {"round": len(chain.blocks), "blocks": list(reversed(chain.blocks[-limit:]))}

    @app.route("GET", "/v2/verify")
    def verify_chain(req):
        return chain.verify()

    return app


def main():
    p = argparse.ArgumentParser(description="Valrix DevNet local ledger (dev-only)")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8700)
    p.add_argument("--data", default="./data/devnet")
    p.add_argument("--quiet", action="store_true")
    a = p.parse_args()
    chain = Chain(a.data)
    print(f"[devnet] DEV-ONLY local ledger, {len(chain.blocks)} rounds loaded, integrity={chain.verify()['ok']}")
    build_app(chain, a.quiet).serve(a.host, a.port)


if __name__ == "__main__":
    main()
