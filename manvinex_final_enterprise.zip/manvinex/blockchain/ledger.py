"""
Valrix blockchain client.

Every on-chain record is a small JSON note written by a known sender address:

  reg   Parent Server registers an artifact   {"k":"reg","p":parent_id,"a":artifact_id,"h":sha256,"v":version}
  dep   Pipeline anchors a deployment         {"k":"dep","d":deployment_id,"m":manifest_sha256,"p":parent_id,"c":child_id}
  rcpt  Pipeline anchors a Child's receipt    {"k":"rcpt","d":deployment_id,"r":receipt_sha256,"x":exit_code}

Backends (same interface):
  AlgorandLedger  - real Algorand TestNet/MainNet (0-ALGO self-payment with a note)
  DevNetLedger    - local single-node hash-chained ledger for offline demos (NOT decentralised)
"""
from __future__ import annotations

import argparse
import json
import time
import urllib.parse

from common.crypto import b64d, b64e, canonical
from common.web import ClientError, http, http_json

from .algorand_codec import build_note_txn, sign_txn

NOTE_PREFIX = "valrix1:"


class LedgerError(Exception):
    pass


def encode_note(record: dict) -> bytes:
    note = (NOTE_PREFIX + canonical(record).decode()).encode()
    if len(note) > 1024:
        raise LedgerError("record too large for an Algorand note (1024 bytes)")
    return note


def decode_note(note: bytes) -> dict | None:
    try:
        s = note.decode()
    except UnicodeDecodeError:
        return None
    if not s.startswith(NOTE_PREFIX):
        return None
    try:
        return json.loads(s[len(NOTE_PREFIX):])
    except json.JSONDecodeError:
        return None


# ---------------------------------------------------------------- DevNet (local)

class DevNetLedger:
    mode = "devnet"

    def __init__(self, url: str):
        self.url = url.rstrip("/")

    def config(self) -> dict:
        return {"mode": "devnet", "url": self.url}

    def label(self) -> str:
        return f"Valrix DevNet (local, dev-only) @ {self.url}"

    def anchor(self, identity, record: dict) -> dict:
        note_b64 = b64e(encode_note(record))
        ts = int(time.time())
        body = {"sender": identity.address, "note": note_b64, "ts": ts}
        body["sig"] = identity.sign_obj("devnet-tx", {"note": note_b64, "sender": identity.address, "ts": ts})
        try:
            r = http_json("POST", f"{self.url}/v2/tx", json_body=body)
        except ClientError as e:
            raise LedgerError(f"DevNet anchor failed: {e}") from e
        return {"txid": r["txid"], "round": r["round"], "chain": "devnet", "explorer": self.explorer_url(r["txid"])}

    def lookup(self, txid: str) -> dict | None:
        try:
            r = http_json("GET", f"{self.url}/v2/tx/{urllib.parse.quote(txid)}")
        except ClientError as e:
            if e.status == 404:
                return None
            raise LedgerError(f"DevNet lookup failed: {e}") from e
        return {"txid": r["txid"], "sender": r["sender"], "round": r["round"],
                "record": decode_note(b64d(r["note"]))}

    def explorer_url(self, txid: str) -> str:
        return f"{self.url}/v2/tx/{txid}"

    def balance(self, address: str):
        return None  # no fees on DevNet


# ---------------------------------------------------------------- Algorand

class AlgorandLedger:
    mode = "algorand"
    NETWORKS = {
        "testnet": ("https://testnet-api.algonode.cloud", "https://testnet-idx.algonode.cloud"),
        "mainnet": ("https://mainnet-api.algonode.cloud", "https://mainnet-idx.algonode.cloud"),
    }

    def __init__(self, network: str = "testnet", algod_url: str | None = None,
                 indexer_url: str | None = None, token: str = ""):
        if network not in self.NETWORKS and not (algod_url and indexer_url):
            raise LedgerError(f"unknown network {network!r}; pass --algod-url and --indexer-url")
        d_algod, d_idx = self.NETWORKS.get(network, (None, None))
        self.network = network
        self.algod = (algod_url or d_algod).rstrip("/")
        self.indexer = (indexer_url or d_idx).rstrip("/")
        self.headers = {"X-Algo-API-Token": token} if token else {}

    def config(self) -> dict:
        # token deliberately not shared
        return {"mode": "algorand", "network": self.network, "algod_url": self.algod, "indexer_url": self.indexer}

    def label(self) -> str:
        return f"Algorand {self.network}"

    def anchor(self, identity, record: dict, timeout_s: float = 30) -> dict:
        try:
            params = http_json("GET", f"{self.algod}/v2/transactions/params", headers=self.headers)
            txn = build_note_txn(identity.address, encode_note(record), params)
            tid, wire = sign_txn(identity, txn)
            http("POST", f"{self.algod}/v2/transactions", data=wire,
                 headers={**self.headers, "Content-Type": "application/x-binary"})
        except ClientError as e:
            hint = ""
            if "overspend" in e.message or "below min" in e.message:
                hint = f" (fund {identity.address} with test ALGO from the TestNet dispenser)"
            raise LedgerError(f"Algorand anchor failed: {e}{hint}") from e
        deadline = time.time() + timeout_s
        while time.time() < deadline:
            info = http_json("GET", f"{self.algod}/v2/transactions/pending/{tid}", headers=self.headers)
            if info.get("pool-error"):
                raise LedgerError(f"Algorand rejected tx: {info['pool-error']}")
            if info.get("confirmed-round"):
                return {"txid": tid, "round": info["confirmed-round"], "chain": f"algorand-{self.network}",
                        "explorer": self.explorer_url(tid)}
            time.sleep(1)
        raise LedgerError(f"tx {tid} not confirmed within {timeout_s}s")

    def lookup(self, txid: str, retries: int = 12) -> dict | None:
        # Indexer can lag the chain by a few seconds, so retry on 404.
        for attempt in range(retries):
            try:
                r = http_json("GET", f"{self.indexer}/v2/transactions/{urllib.parse.quote(txid)}",
                              headers=self.headers)
                tx = r["transaction"]
                return {"txid": tx["id"], "sender": tx["sender"], "round": tx.get("confirmed-round"),
                        "record": decode_note(b64d(tx.get("note", "")))}
            except ClientError as e:
                if e.status != 404:
                    raise LedgerError(f"Algorand indexer lookup failed: {e}") from e
                if attempt < retries - 1:
                    time.sleep(1.5)
        return None

    def explorer_url(self, txid: str) -> str:
        return f"https://lora.algokit.io/{self.network}/transaction/{txid}"

    def balance(self, address: str):
        try:
            return http_json("GET", f"{self.algod}/v2/accounts/{address}", headers=self.headers).get("amount")
        except ClientError:
            return None


# ---------------------------------------------------------------- config helpers

def from_config(cfg: dict):
    if cfg.get("mode") == "algorand":
        return AlgorandLedger(cfg.get("network", "testnet"), cfg.get("algod_url"), cfg.get("indexer_url"),
                              cfg.get("token", ""))
    if cfg.get("mode") == "devnet":
        return DevNetLedger(cfg["url"])
    raise LedgerError(f"unknown ledger config: {cfg}")


def add_ledger_args(p: argparse.ArgumentParser):
    g = p.add_argument_group("blockchain")
    g.add_argument("--ledger", choices=["devnet", "algorand"], default="devnet")
    g.add_argument("--devnet-url", default="http://127.0.0.1:8700")
    g.add_argument("--network", default="testnet", help="algorand network: testnet | mainnet")
    g.add_argument("--algod-url")
    g.add_argument("--indexer-url")
    g.add_argument("--algod-token", default="")


def from_args(a) -> DevNetLedger | AlgorandLedger:
    if a.ledger == "algorand":
        return AlgorandLedger(a.network, a.algod_url, a.indexer_url, a.algod_token)
    return DevNetLedger(a.devnet_url)
