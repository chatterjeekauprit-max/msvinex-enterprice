from .child import main

main()
