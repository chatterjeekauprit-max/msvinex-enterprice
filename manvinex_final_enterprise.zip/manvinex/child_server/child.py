"""
CHILD SERVER (Edge device, e.g. Raspberry Pi)  -  owned by Friend 2

Zero-trust rule: the Child Server believes NOTHING it is told until it has checked it itself.
Before running any code it verifies, in order:

   1  replay        this deployment was never processed before
   2  pipeline sig  manifest signed by the Pipeline address pinned at enrollment
   3  target        manifest is addressed to THIS device (child ID + address)
   4  expiry        manifest is not expired
   5  parent trust  the Parent Server address is on this device's own trust list
   6  plan          plan shape is valid (mode/timeout/args/env allow-list)
   7  CHAIN: dep    deployment anchored on-chain by the Pipeline, hash == this manifest
   8  CHAIN: reg    artifact registered on-chain by the Parent, hash == manifest's artifact hash
   9  payload hash  downloaded ciphertext matches the manifest
  10  parent seal   Parent signed "this ciphertext is for this child in this deployment"
  11  decrypt       AES-GCM with this device's private key (fails if tampered / not for us)
  12  code hash     SHA-256 of decrypted code == the hash the Parent registered on-chain

Only then does it install/run, and it sends back a signed execution receipt.

CLI:
  python3 -m child_server enroll --pipeline URL --child-id ID --token TOKEN --trust-parent PARENT_URL
  python3 -m child_server trust-parent PARENT_URL
  python3 -m child_server run [--status-port 8200]
  python3 -m child_server status
"""
from __future__ import annotations

import argparse
import io
import json
import os
import platform
import re
import shutil
import signal
import subprocess
import sys
import tarfile
import threading
import time
import traceback
import zipfile

from blockchain import ledger as ledger_mod
from common.crypto import Identity, b64e, canonical, sha256_hex, verify, verify_obj
from common.plan import validate_plan
from common.web import App, ClientError, http, http_json, sign_request

VERSION = "1.0.0"
DEP_RE = re.compile(r"^dep_[a-f0-9]{12}$")
MAX_EXTRACT = 1024 * 1024 * 1024  # 1 GB
CLOCK_SKEW_S = 60


def normalize_arch(a: str) -> str:
    a = (a or "").lower()
    return {"aarch64": "arm64", "amd64": "x86_64", "armhf": "armv7l"}.get(a, a)


class Rejected(Exception):
    pass


class ChildServer:
    def __init__(self, data_dir: str):
        self.data = os.path.abspath(os.path.expanduser(data_dir))
        os.makedirs(self.data, exist_ok=True)
        self.identity = Identity.load_or_create(os.path.join(self.data, "identity.json"), with_encryption_key=True)
        self.cfg_path = os.path.join(self.data, "config.json")
        self.cfg = self._load(self.cfg_path, {"trusted_parents": {}})
        self.exec_path = os.path.join(self.data, "executed.json")
        self.executed = set(self._load(self.exec_path, []))
        self.history: list[dict] = self._load(os.path.join(self.data, "history.json"), [])
        self.services: dict[str, dict] = {}  # parent_id -> {proc, dep_id, log, manifest_sha, started}
        self.lock = threading.Lock()

    # ------------------------------------------------------------ persistence
    @staticmethod
    def _load(path, default):
        if os.path.exists(path):
            with open(path) as f:
                return json.load(f)
        return default

    def _save(self, path, obj):
        tmp = path + ".tmp"
        with open(tmp, "w") as f:
            json.dump(obj, f, indent=2)
        os.replace(tmp, path)

    def save_cfg(self):
        self._save(self.cfg_path, self.cfg)

    def log(self, msg: str):
        print(f"[child {self.cfg.get('child_id', '?')}] {msg}", flush=True)

    # ------------------------------------------------------------ info / trust
    def system_info(self) -> dict:
        return {"hostname": platform.node(), "arch": normalize_arch(platform.machine()),
                "os": f"{platform.system()} {platform.release()}", "python": platform.python_version(),
                "has_python3": True, "has_bash": shutil.which("bash") is not None, "agent_version": VERSION,
                "device_class": "ESP32 (virtual)" if self.cfg.get("virtual_esp32") else "Linux Child",
                "virtual_esp32": bool(self.cfg.get("virtual_esp32")),
                "trusted_parents": sorted(self.cfg.get("trusted_parents", {})),
                "services": {pid: s["dep_id"] for pid, s in self.services.items()}}

    def trust_parent(self, url: str, label: str | None = None) -> str:
        url = url.rstrip("/")
        ident = http_json("GET", url + "/api/identity")
        if ident.get("role") != "parent_server":
            raise SystemExit(f"{url} is not a Valrix Parent Server")
        addr = ident["address"]
        self.cfg.setdefault("trusted_parents", {})[addr] = {"url": url, "label": label or url, "pinned_at": int(time.time())}
        self.save_cfg()
        self.log(f"pinned Parent Server {url} -> {addr}")
        self.log("   (confirm this address with the Parent Server owner over a separate channel)")
        return addr

    # ------------------------------------------------------------ pipeline calls (signed)
    def _signed(self, method: str, path: str, body: dict | None = None, raw=False):
        data = json.dumps(body).encode() if body is not None else b""
        headers = sign_request(self.identity, method, path, data)
        if body is not None:
            headers["Content-Type"] = "application/json"
        out = http(method, self.cfg["pipeline_url"] + path, data=data if body is not None else None,
                   headers=headers, timeout=60)
        return out if raw else (json.loads(out) if out else None)

    def enroll(self, pipeline_url: str, child_id: str, token: str, ledger_override: dict | None):
        self.cfg["pipeline_url"] = pipeline_url.rstrip("/")
        enc_pub = b64e(self.identity.enc_pub)
        body = {"token": token, "child_id": child_id, "address": self.identity.address, "enc_pub": enc_pub,
                "enc_sig": self.identity.sign_obj("child-enc-key", {"child_id": child_id, "enc_pub": enc_pub}),
                "info": self.system_info()}
        r = self._signed("POST", "/api/child/enroll", body)
        self.cfg.update({"child_id": r["child_id"], "pipeline_address": r["pipeline_address"],
                         "ledger": ledger_override or r["ledger"], "poll_interval_s": r.get("poll_interval_s", 3)})
        self.save_cfg()
        self.log(f"enrolled. device address {self.identity.address}")
        self.log(f"pinned Pipeline address {r['pipeline_address']}")
        self.log(f"blockchain: {ledger_mod.from_config(self.cfg['ledger']).label()}")

    def report(self, dep_id: str, stage: str, detail: str, **extra):
        try:
            self._signed("POST", f"/api/child/report/{dep_id}", {"stage": stage, "detail": detail, **extra})
        except ClientError as e:
            self.log(f"report {stage} failed: {e}")

    def _remember(self, dep_id: str, status: str, detail: str, parent_id: str = ""):
        self.history.insert(0, {"deployment_id": dep_id, "status": status, "detail": detail[:300],
                                "parent_id": parent_id, "ts": int(time.time())})
        del self.history[50:]
        self._save(os.path.join(self.data, "history.json"), self.history)

    # ------------------------------------------------------------ verification
    def verify_deployment(self, dep: dict) -> tuple[dict, bytes, list[str]]:
        m, dep_id = dep["manifest"], dep["deployment_id"]
        passed = []
        ledger = ledger_mod.from_config(self.cfg["ledger"])

        def ok(name):
            passed.append(name)

        if m.get("deployment_id") != dep_id:
            raise Rejected("malformed deployment")
        if dep_id in self.executed:
            raise Rejected("replay: this deployment was already processed")
        self.executed.add(dep_id)                         # 1 record BEFORE doing anything else
        self._save(self.exec_path, sorted(self.executed))
        ok("replay")

        m_bytes = canonical(m)
        pipe_addr = self.cfg["pipeline_address"]
        if m.get("pipeline_address") != pipe_addr or not verify(pipe_addr, "manifest", m_bytes, dep.get("manifest_sig", "")):
            raise Rejected("manifest signature is not from the pinned Pipeline")
        ok("pipeline signature")                          # 2

        if m["child"]["address"] != self.identity.address or m["child"]["child_id"] != self.cfg["child_id"]:
            raise Rejected("manifest is addressed to a different device")
        ok("target device")                               # 3

        if m["expires_at"] + CLOCK_SKEW_S < time.time():
            raise Rejected("manifest expired")
        ok("expiry")                                      # 4

        parent = m["parent"]
        if parent["address"] not in self.cfg.get("trusted_parents", {}):
            raise Rejected(f"Parent Server {parent['address'][:8]}… is not on this device's trust list")
        ok("parent trusted")                              # 5

        try:
            validate_plan(m["plan"])
        except ValueError as e:
            raise Rejected(f"invalid plan: {e}") from e
        if parent["runtime"] not in ("python", "bash", "bundle", "binary"):
            raise Rejected("unknown runtime")
        ok("plan")                                        # 6

        m_sha = sha256_hex(m_bytes)
        young = time.time() - m["created_at"] < 300       # indexers can lag: retry later instead of rejecting

        tx = ledger.lookup(dep.get("dep_txid", ""))       # 7 blockchain: deployment anchor
        if tx is None and young:
            raise ledger_mod.LedgerError("deployment anchor not visible on-chain yet")
        rec = (tx or {}).get("record") or {}
        if not tx or tx["sender"] != pipe_addr or rec.get("k") != "dep" or rec.get("d") != dep_id or rec.get("m") != m_sha:
            raise Rejected("deployment is not anchored on-chain by the Pipeline (or manifest altered)")
        ok(f"on-chain deployment anchor (round {tx['round']})")

        tx = ledger.lookup(parent["reg_txid"])            # 8 blockchain: parent registration
        if tx is None and young:
            raise ledger_mod.LedgerError("parent registration not visible on-chain yet")
        rec = (tx or {}).get("record") or {}
        if not tx or tx["sender"] != parent["address"] or rec.get("k") != "reg" or rec.get("h") != parent["sha256"] \
                or rec.get("a") != parent["artifact_id"] or rec.get("p") != parent["parent_id"]:
            raise Rejected("artifact is not registered on-chain by the trusted Parent Server")
        ok(f"on-chain parent registration (round {tx['round']})")

        blob = self._signed("GET", f"/api/child/payload/{dep_id}", raw=True)
        if sha256_hex(blob) != m["payload"]["sha256"] or len(blob) != m["payload"]["size"]:
            raise Rejected("payload does not match manifest hash (tampered in transit/storage)")
        ok("payload hash")                                # 9

        statement = {"a": parent["artifact_id"], "c": self.identity.address, "d": dep_id, "h": parent["sha256"],
                     "p": parent["parent_id"], "s": m["payload"]["sha256"]}
        if not verify_obj(parent["address"], "parent-seal", statement, parent["seal_sig"]):
            raise Rejected("Parent seal signature invalid")
        ok("parent seal signature")                       # 10

        try:
            plaintext = self.identity.unseal(blob, dep_id.encode())
        except ValueError as e:
            raise Rejected(f"decryption failed: {e}") from e
        ok("decrypt (AES-256-GCM)")                       # 11

        if sha256_hex(plaintext) != parent["sha256"]:
            raise Rejected("decrypted code hash differs from on-chain registered hash")
        ok("code hash == on-chain hash")                  # 12
        return m, plaintext, passed

    # ------------------------------------------------------------ install / run
    def install(self, m: dict, plaintext: bytes) -> tuple[str, list[str]]:
        p = m["parent"]
        app_dir = os.path.join(self.data, "apps", p["parent_id"], m["deployment_id"])
        os.makedirs(app_dir, exist_ok=True)
        rt, fname = p["runtime"], p["filename"]
        if rt == "bundle":
            safe_extract(fname, plaintext, app_dir)
            return app_dir, bundle_entrypoint(app_dir)
        path = os.path.join(app_dir, os.path.basename(fname))
        with open(path, "wb") as f:
            f.write(plaintext)
        if rt == "python":
            return app_dir, [sys.executable, os.path.basename(fname)]
        if rt == "bash":
            return app_dir, ["bash", os.path.basename(fname)]
        os.chmod(path, 0o700)
        return app_dir, ["./" + os.path.basename(fname)]

    def _env(self, m: dict) -> dict:
        env = {
            "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
            "SYSTEMROOT": os.environ.get("SYSTEMROOT", "C:\\Windows"),
            "LANG": os.environ.get("LANG", "C.UTF-8"),
            "HOME": os.environ.get("USERPROFILE", os.environ.get("HOME", "/tmp")),
            "PYTHONUTF8": "1",
            "PYTHONIOENCODING": "utf-8",
        }
        env.update(m["plan"].get("env", {}))
        env.update({"VALRIX_DEPLOYMENT_ID": m["deployment_id"], "VALRIX_PARENT_ID": m["parent"]["parent_id"],
                    "VALRIX_CHILD_ID": self.cfg["child_id"], "VALRIX_ARTIFACT_SHA256": m["parent"]["sha256"],
                    "VALRIX_PROMPT": m.get("prompt", "")})
        return env

    def receipt(self, m: dict, status: str, exit_code, started: int, output: bytes) -> tuple[dict, str]:
        r = {"deployment_id": m["deployment_id"], "manifest_sha256": sha256_hex(canonical(m)),
             "artifact_sha256": m["parent"]["sha256"], "parent_id": m["parent"]["parent_id"],
             "child_id": self.cfg["child_id"], "child_address": self.identity.address, "mode": m["plan"]["mode"],
             "status": status, "exit_code": exit_code, "started_at": started, "finished_at": int(time.time()),
             "output_sha256": sha256_hex(output)}
        return r, self.identity.sign_obj("receipt", r)

    def stop_service(self, parent_id: str, reason: str):
        s = self.services.pop(parent_id, None)
        if not s:
            return
        if s["proc"].poll() is None:
            self.log(f"stopping service {s['dep_id']} for {parent_id}: {reason}")
            _stop_process_tree(s["proc"])
        s["logf"].close()
        with open(s["log"], "rb") as f:
            output = f.read()
        r, sig = self.receipt(s["m"], "stopped", s["proc"].returncode, s["started"], output)
        self.report(s["dep_id"], "completed", f"service stopped: {reason}", receipt=r, receipt_sig=sig,
                    output_tail=output[-3000:].decode(errors="replace"))

    def execute(self, m: dict, app_dir: str, cmd: list[str]):
        dep_id, plan = m["deployment_id"], m["plan"]
        cmd = cmd + plan.get("args", [])
        started = int(time.time())
        log_path = os.path.join(app_dir, "run.log")

        if self.cfg.get("virtual_esp32"):
            output = ("ESP32 virtual OTA received\n"
                      f"firmware: {m['parent']['filename']}\n"
                      f"sha256: {m['parent']['sha256']}\n")
            self.report(dep_id, "running", "virtual ESP32 accepted OTA update; LED blink started")
            for state in ("ON", "OFF", "ON", "OFF", "ON"):
                output += f"LED {state}\n"
                time.sleep(0.2)
            output += "ESP32 virtual OTA applied; device running\n"
            raw = output.encode()
            r, sig = self.receipt(m, "success", 0, started, raw)
            self.report(dep_id, "completed", "virtual ESP32 blink test completed", receipt=r,
                        receipt_sig=sig, output_tail=output)
            return "completed", "virtual ESP32 OTA complete"

        if plan["mode"] == "install":
            r, sig = self.receipt(m, "installed", None, started, b"")
            self.report(dep_id, "completed", f"installed to {app_dir} (not executed, install-only plan)",
                        receipt=r, receipt_sig=sig, output_tail="")
            return "completed", "installed"

        if plan["mode"] == "service":
            self.stop_service(m["parent"]["parent_id"], f"replaced by {dep_id}")
            logf = open(log_path, "ab")
            proc = subprocess.Popen(cmd, cwd=app_dir, env=self._env(m), stdout=logf, stderr=subprocess.STDOUT,
                                    stdin=subprocess.DEVNULL, start_new_session=True)
            self.services[m["parent"]["parent_id"]] = {"proc": proc, "dep_id": dep_id, "log": log_path, "m": m,
                                                       "started": started, "logf": logf}
            r, sig = self.receipt(m, "started", None, started, b"")
            self.report(dep_id, "running", f"service started (pid {proc.pid})", receipt=r, receipt_sig=sig)
            return "running", f"pid {proc.pid}"

        self.report(dep_id, "running", f"executing: {' '.join(os.path.basename(c) for c in cmd[:3])}")
        with open(log_path, "wb") as logf:
            proc = subprocess.Popen(cmd, cwd=app_dir, env=self._env(m), stdout=logf, stderr=subprocess.STDOUT,
                                    stdin=subprocess.DEVNULL, start_new_session=True)
            try:
                code = proc.wait(timeout=plan["timeout_s"])
                timed_out = False
            except subprocess.TimeoutExpired:
                _stop_process_tree(proc, graceful_timeout=1)
                code = proc.returncode
                timed_out = True
        with open(log_path, "rb") as f:
            output = f.read()
        tail = output[-3000:].decode(errors="replace")
        status = "timeout" if timed_out else ("success" if code == 0 else "error")
        r, sig = self.receipt(m, status, code, started, output)
        stage = "completed" if code == 0 and not timed_out else "failed"
        detail = f"timed out after {plan['timeout_s']}s" if timed_out else f"exit code {code}"
        self.report(dep_id, stage, detail, receipt=r, receipt_sig=sig, output_tail=tail)
        return stage, detail

    def check_services(self):
        for pid, s in list(self.services.items()):
            code = s["proc"].poll()
            if code is None:
                continue
            self.services.pop(pid)
            s["logf"].close()
            with open(s["log"], "rb") as f:
                output = f.read()
            r, sig = self.receipt(s["m"], "service-exited", code, s["started"], output)
            self.report(s["dep_id"], "completed" if code == 0 else "failed", f"service exited with code {code}",
                        receipt=r, receipt_sig=sig, output_tail=output[-3000:].decode(errors="replace"))

    def process(self, dep: dict):
        dep_id = dep.get("deployment_id", "")
        if not (isinstance(dep_id, str) and DEP_RE.match(dep_id)):
            self.log(f"ignoring malformed deployment id {dep_id!r}")
            return
        self.log(f"received {dep_id}")
        try:
            m, plaintext, passed = self.verify_deployment(dep)
        except Rejected as e:
            self.log(f"REJECTED {dep_id}: {e}")
            self.report(dep_id, "rejected", str(e))
            self._remember(dep_id, "rejected", str(e), dep.get("manifest", {}).get("parent", {}).get("parent_id", ""))
            return
        except (ClientError, ledger_mod.LedgerError) as e:
            # Network/ledger problem: do not execute. Allow a later retry by forgetting the replay mark.
            self.executed.discard(dep_id)
            self._save(self.exec_path, sorted(self.executed))
            self.log(f"could not verify {dep_id} right now: {e}")
            return
        self.log(f"verified {dep_id}: {len(passed)} checks passed")
        self.report(dep_id, "verified", f"{len(passed)}/12 checks passed: " + "; ".join(passed))
        try:
            app_dir, cmd = self.install(m, plaintext)
            stage, detail = self.execute(m, app_dir, cmd)
        except Exception as e:  # noqa: BLE001
            traceback.print_exc()
            stage, detail = "failed", f"install/run error: {e}"
            self.report(dep_id, "failed", detail)
        self.log(f"{dep_id}: {stage} ({detail})")
        self._remember(dep_id, stage, detail, m["parent"]["parent_id"])

    # ------------------------------------------------------------ main loop
    def run(self, once: bool = False):
        if "pipeline_url" not in self.cfg or "child_id" not in self.cfg:
            raise SystemExit("not enrolled yet - run: python3 -m child_server enroll ...")
        self.log(f"running. address {self.identity.address}  pipeline {self.cfg['pipeline_url']}")
        interval = self.cfg.get("poll_interval_s", 3)

        def _term(*_):
            raise SystemExit(0)
        signal.signal(signal.SIGTERM, _term)
        try:
            self._loop(once, interval)
        finally:
            for pid in list(self.services):
                self.stop_service(pid, "Child Server shutting down")

    def _loop(self, once: bool, interval: float):
        while True:
            try:
                self.check_services()
                r = self._signed("POST", "/api/child/poll", {"info": self.system_info()})
                if r and r.get("deployment"):
                    self.process(r["deployment"])
                    continue  # immediately look for more
            except ClientError as e:
                self.log(f"pipeline: {e}")
                if e.status == 403 and "revoked" in e.message:
                    self.log("this device was revoked - stopping all services and exiting")
                    for pid in list(self.services):
                        self.stop_service(pid, "device revoked")
                    return
            if once:
                return
            time.sleep(interval)


# ---------------------------------------------------------------- bundles

def _safe_name(name: str) -> str:
    """Reject absolute paths, '..' traversal and backslashes. Returns a normalized relative path."""
    if not name or os.path.isabs(name) or name.startswith("/") or "\\" in name:
        raise Rejected(f"unsafe path in bundle: {name!r}")
    norm = os.path.normpath(name)
    if norm == "." or norm == ".." or norm.startswith(".." + os.sep):
        raise Rejected(f"unsafe path in bundle: {name!r}")
    return norm


def _inside(dest: str, rel: str) -> str:
    target = os.path.realpath(os.path.join(dest, rel))
    if not target.startswith(os.path.realpath(dest) + os.sep):
        raise Rejected(f"path escapes install dir: {rel!r}")
    return target


def _stop_process_tree(proc: subprocess.Popen, graceful_timeout: int = 10):
    """Stop a deployed process portably; POSIX process groups do not exist on Windows."""
    if proc.poll() is not None:
        return
    if os.name == "nt":
        proc.terminate()
        try:
            proc.wait(timeout=graceful_timeout)
        except subprocess.TimeoutExpired:
            # taskkill /T also stops subprocesses launched by the deployed program.
            subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=5)
        return

    try:
        os.killpg(proc.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    try:
        proc.wait(timeout=graceful_timeout)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait(timeout=5)


def safe_extract(filename: str, data: bytes, dest: str):
    total = 0
    if filename.lower().endswith(".zip"):
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            for info in z.infolist():
                if info.filename in ("./", "."):
                    continue
                target = _inside(dest, _safe_name(info.filename))
                if info.is_dir():
                    os.makedirs(target, exist_ok=True)
                    continue
                total += info.file_size
                if total > MAX_EXTRACT:
                    raise Rejected("bundle too large when extracted")
                os.makedirs(os.path.dirname(target), exist_ok=True)
                with z.open(info) as src, open(target, "wb") as out:
                    shutil.copyfileobj(src, out)
        return
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:*") as t:
        for member in t.getmembers():
            if member.name in (".", "./"):
                continue
            target = _inside(dest, _safe_name(member.name))
            if member.isdir():
                os.makedirs(target, exist_ok=True)
                continue
            if not member.isfile():
                raise Rejected(f"bundle contains a link/device entry: {member.name!r}")
            total += member.size
            if total > MAX_EXTRACT:
                raise Rejected("bundle too large when extracted")
            os.makedirs(os.path.dirname(target), exist_ok=True)
            with t.extractfile(member) as src, open(target, "wb") as out:
                shutil.copyfileobj(src, out)
            if member.mode & 0o100:
                os.chmod(target, 0o700)


def bundle_entrypoint(app_dir: str) -> list[str]:
    for spec_name in ("valrix.json", "manvinex.json"):
        spec = os.path.join(app_dir, spec_name)
        if os.path.exists(spec):
            with open(spec) as f:
                ep = json.load(f).get("entrypoint")
            if not (isinstance(ep, list) and ep and all(isinstance(x, str) for x in ep)):
                raise Rejected(f"{spec_name} entrypoint must be a list of strings")
            if ep[0] in ("python", "python3"):
                ep = [sys.executable] + ep[1:]
            elif ep[0] not in ("bash", "cmd", "cmd.exe"):
                ep[0] = ("" if os.name == "nt" else "./") + _safe_name(ep[0])
            return ep
    if os.path.exists(os.path.join(app_dir, "main.py")):
        return [sys.executable, "main.py"]
    if os.path.exists(os.path.join(app_dir, "run.sh")):
        return ["bash", "run.sh"]
    if os.name == "nt" and os.path.exists(os.path.join(app_dir, "run.bat")):
        return ["cmd.exe", "/c", "run.bat"]
    raise Rejected("bundle has no valrix.json, manvinex.json, main.py or run.sh")


# ---------------------------------------------------------------- local status page

def status_app(cs: ChildServer) -> App:
    app = App("child-status", quiet=True)

    @app.route("GET", "/health")
    def health(req):
        return {"status": "healthy", "service": "child_server", "child_id": cs.cfg.get("child_id"),
                "address": cs.identity.address, "pipeline": cs.cfg.get("pipeline_url")}

    @app.route("GET", "/status")
    def status(req):
        return {"child_id": cs.cfg.get("child_id"), "address": cs.identity.address,
                "pipeline": cs.cfg.get("pipeline_url"), "pipeline_address": cs.cfg.get("pipeline_address"),
                "trusted_parents": cs.cfg.get("trusted_parents"), "ledger": cs.cfg.get("ledger"),
                "services": {k: {"deployment_id": v["dep_id"], "pid": v["proc"].pid} for k, v in cs.services.items()},
                "history": cs.history[:20]}
    return app


def main(argv=None):
    p = argparse.ArgumentParser(prog="child_server", description="Valrix Child Server (edge device)")
    p.add_argument("--data", default=os.environ.get("VALRIX_CHILD_DATA", "~/.valrix-child"))
    sub = p.add_subparsers(dest="cmd", required=True)
    e = sub.add_parser("enroll", help="enroll this device with a Pipeline")
    e.add_argument("--pipeline", required=True)
    e.add_argument("--child-id", required=True)
    e.add_argument("--token", required=True)
    e.add_argument("--trust-parent", action="append", default=[], help="Parent Server URL to pin (repeatable)")
    e.add_argument("--ledger-override", choices=["devnet", "algorand"],
                   help="use this blockchain config instead of the one the Pipeline suggests")
    e.add_argument("--devnet-url")
    e.add_argument("--network", default="testnet")
    t = sub.add_parser("trust-parent", help="pin a Parent Server's address")
    t.add_argument("url")
    t.add_argument("--label")
    r = sub.add_parser("run", help="run the Child Server loop")
    r.add_argument("--once", action="store_true")
    r.add_argument("--status-port", type=int, default=0, help="serve local /status on 127.0.0.1:<port>")
    r.add_argument("--virtual-esp32", action="store_true",
                   help="simulate an ESP32 OTA device with an LED blink after verification")
    sub.add_parser("status", help="show identity and config")
    a = p.parse_args(argv)
    cs = ChildServer(a.data)

    if a.cmd == "enroll":
        for url in a.trust_parent:
            cs.trust_parent(url)
        override = None
        if a.ledger_override == "algorand":
            override = {"mode": "algorand", "network": a.network}
        elif a.ledger_override == "devnet":
            override = {"mode": "devnet", "url": a.devnet_url or "http://127.0.0.1:8700"}
        try:
            cs.enroll(a.pipeline, a.child_id, a.token, override)
        except ClientError as err:
            raise SystemExit(f"enrollment failed: {err}")
    elif a.cmd == "trust-parent":
        cs.trust_parent(a.url, a.label)
    elif a.cmd == "status":
        print(json.dumps({"address": cs.identity.address, **cs.cfg, "executed": len(cs.executed)}, indent=2))
    elif a.cmd == "run":
        if a.virtual_esp32:
            cs.cfg["virtual_esp32"] = True
            cs.save_cfg()
        if a.status_port:
            threading.Thread(target=status_app(cs).serve, args=("127.0.0.1", a.status_port), daemon=True).start()
        cs.run(once=a.once)


if __name__ == "__main__":
    main()
