"""
Valrix Common Library: Cryptography, Identity, Plan Validation, Database, and Web Engine.
"""
from __future__ import annotations

import sys

# Ensure UTF-8 console output on Windows CP1252 / standard consoles
for _stream in (sys.stdout, sys.stderr):
    if _stream and hasattr(_stream, "reconfigure"):
        try:
            _stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
