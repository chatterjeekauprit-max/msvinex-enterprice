"""
Valrix shared crypto.

- Identity: one Ed25519 key per actor (Parent Server, Pipeline, Child Server).
  Its public key is shown as an Algorand-format address (58 chars), so the same
  identity is used for signatures AND as the blockchain sender address.
- Child Servers also hold an X25519 key used only for payload encryption.
- seal()/unseal(): X25519 ECDH -> HKDF-SHA256 -> AES-256-GCM (only the target
  child can decrypt; any tampering fails authentication).

Only dependency: `cryptography` (pip install cryptography / apt install python3-cryptography).
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import stat

from cryptography.exceptions import InvalidSignature, InvalidTag
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

_RAW = dict(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)

# ---------------------------------------------------------------- hashing / encoding

def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def sha512_256(data: bytes) -> bytes:
    return hashlib.new("sha512_256", data).digest()


def canonical(obj) -> bytes:
    """Deterministic JSON bytes: the exact bytes that get hashed/signed."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


def b64e(b: bytes) -> str:
    return base64.b64encode(b).decode()


def b64d(s: str) -> bytes:
    return base64.b64decode(s)


# ---------------------------------------------------------------- addresses (Algorand format)

def pub_to_address(pub: bytes) -> str:
    if len(pub) != 32:
        raise ValueError("public key must be 32 bytes")
    checksum = sha512_256(pub)[-4:]
    return base64.b32encode(pub + checksum).decode().rstrip("=")


def address_to_pub(address: str) -> bytes:
    try:
        raw = base64.b32decode(address + "=" * (-len(address) % 8))
    except Exception as e:  # noqa: BLE001
        raise ValueError("invalid address encoding") from e
    if len(raw) != 36:
        raise ValueError("invalid address length")
    pub, checksum = raw[:32], raw[32:]
    if sha512_256(pub)[-4:] != checksum:
        raise ValueError("invalid address checksum")
    return pub


def is_address(address: str) -> bool:
    try:
        address_to_pub(address)
        return True
    except (ValueError, TypeError):
        return False


# ---------------------------------------------------------------- signatures

def _signing_bytes(domain: str, payload: bytes) -> bytes:
    # Domain separation: a signature for one purpose can never be replayed as another.
    return b"VALRIX|" + domain.encode() + b"|" + payload


def verify(address: str, domain: str, payload: bytes, sig_b64: str) -> bool:
    try:
        Ed25519PublicKey.from_public_bytes(address_to_pub(address)).verify(
            b64d(sig_b64), _signing_bytes(domain, payload))
        return True
    except (InvalidSignature, ValueError, TypeError):
        return False


def verify_obj(address: str, domain: str, obj, sig_b64: str) -> bool:
    return verify(address, domain, canonical(obj), sig_b64)


class Identity:
    """Ed25519 identity (+ optional X25519 encryption key), persisted as a 0600 JSON file."""

    def __init__(self, seed: bytes, x_seed: bytes | None = None):
        self._sk = Ed25519PrivateKey.from_private_bytes(seed)
        self._seed = seed
        self.pub = self._sk.public_key().public_bytes(**_RAW)
        self.address = pub_to_address(self.pub)
        self._x = X25519PrivateKey.from_private_bytes(x_seed) if x_seed else None
        self._x_seed = x_seed

    # -- persistence
    @classmethod
    def load_or_create(cls, path: str, with_encryption_key: bool = False) -> "Identity":
        if os.path.exists(path):
            with open(path) as f:
                d = json.load(f)
            x = bytes.fromhex(d["x25519_seed"]) if d.get("x25519_seed") else None
            if with_encryption_key and x is None:
                x = os.urandom(32)
                ident = cls(bytes.fromhex(d["ed25519_seed"]), x)
                ident.save(path)
                return ident
            return cls(bytes.fromhex(d["ed25519_seed"]), x)
        ident = cls(os.urandom(32), os.urandom(32) if with_encryption_key else None)
        ident.save(path)
        return ident

    @classmethod
    def from_algorand_private_key(cls, key_b64: str) -> "Identity":
        """Import an Algorand account (base64 64-byte key from algosdk's mnemonic.to_private_key)."""
        raw = b64d(key_b64)
        if len(raw) != 64:
            raise ValueError("Algorand private key must decode to 64 bytes")
        ident = cls(raw[:32])
        if ident.pub != raw[32:]:
            raise ValueError("Algorand private key is inconsistent")
        return ident

    def save(self, path: str):
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        d = {"address": self.address, "ed25519_seed": self._seed.hex()}
        if self._x_seed:
            d["x25519_seed"] = self._x_seed.hex()
        tmp = path + ".tmp"
        with open(tmp, "w") as f:
            json.dump(d, f, indent=2)
        os.chmod(tmp, stat.S_IRUSR | stat.S_IWUSR)
        os.replace(tmp, path)

    # -- signing
    def sign(self, domain: str, payload: bytes) -> str:
        return b64e(self._sk.sign(_signing_bytes(domain, payload)))

    def sign_obj(self, domain: str, obj) -> str:
        return self.sign(domain, canonical(obj))

    def sign_raw(self, message: bytes) -> bytes:
        """Raw Ed25519 signature (used for Algorand transactions: message = b'TX' + msgpack)."""
        return self._sk.sign(message)

    # -- encryption key
    @property
    def enc_pub(self) -> bytes:
        if not self._x:
            raise RuntimeError("identity has no encryption key")
        return self._x.public_key().public_bytes(**_RAW)

    def unseal(self, blob: bytes, aad: bytes) -> bytes:
        return unseal(blob, self._x, aad)


# ---------------------------------------------------------------- payload sealing

SEAL_MAGIC = b"VXS1"
SEAL_ALG = "x25519-hkdf-sha256-aes256gcm"


def _derive(shared: bytes, eph_pub: bytes, recipient_pub: bytes) -> bytes:
    return HKDF(algorithm=hashes.SHA256(), length=32, salt=eph_pub + recipient_pub,
                info=b"valrix-seal-v1").derive(shared)


def seal(plaintext: bytes, recipient_enc_pub: bytes, aad: bytes) -> bytes:
    eph = X25519PrivateKey.generate()
    eph_pub = eph.public_key().public_bytes(**_RAW)
    key = _derive(eph.exchange(X25519PublicKey.from_public_bytes(recipient_enc_pub)), eph_pub, recipient_enc_pub)
    nonce = os.urandom(12)
    return SEAL_MAGIC + eph_pub + nonce + AESGCM(key).encrypt(nonce, plaintext, aad)


def unseal(blob: bytes, x_priv: X25519PrivateKey, aad: bytes) -> bytes:
    if not blob.startswith(SEAL_MAGIC) or len(blob) < 4 + 32 + 12 + 16:
        raise ValueError("not a Valrix sealed payload")
    eph_pub, nonce, ct = blob[4:36], blob[36:48], blob[48:]
    my_pub = x_priv.public_key().public_bytes(**_RAW)
    key = _derive(x_priv.exchange(X25519PublicKey.from_public_bytes(eph_pub)), eph_pub, my_pub)
    try:
        return AESGCM(key).decrypt(nonce, ct, aad)
    except InvalidTag as e:
        raise ValueError("payload authentication failed (tampered or wrong recipient)") from e
