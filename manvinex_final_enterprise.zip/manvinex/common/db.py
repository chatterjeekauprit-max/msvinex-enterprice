"""Thread-safe SQLite wrapper (stdlib only). Swap for PostgreSQL in production."""
from __future__ import annotations

import json
import os
import secrets
import sqlite3
import threading
import time


class DB:
    def __init__(self, path: str, schema: str):
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        self._conn = sqlite3.connect(path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._conn.execute("PRAGMA cache_size=-64000")
        self._conn.execute("PRAGMA temp_store=MEMORY")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._lock = threading.RLock()
        with self._lock:
            self._conn.executescript(schema)
            self._conn.commit()

    def execute(self, sql: str, args=()) -> int:
        with self._lock:
            cur = self._conn.execute(sql, args)
            self._conn.commit()
            return cur.lastrowid

    def one(self, sql: str, args=()) -> dict | None:
        with self._lock:
            row = self._conn.execute(sql, args).fetchone()
        return dict(row) if row else None

    def all(self, sql: str, args=()) -> list[dict]:
        with self._lock:
            return [dict(r) for r in self._conn.execute(sql, args).fetchall()]

    def transaction(self):
        return _Tx(self)


class _Tx:
    def __init__(self, db: DB):
        self.db = db

    def __enter__(self):
        self.db._lock.acquire()
        return self.db._conn

    def __exit__(self, exc_type, *_):
        try:
            if exc_type:
                self.db._conn.rollback()
            else:
                self.db._conn.commit()
        finally:
            self.db._lock.release()


def now() -> int:
    return int(time.time())


def new_id(prefix: str) -> str:
    return f"{prefix}_{secrets.token_hex(6)}"


def load_or_create_secret(path: str, nbytes: int = 24) -> str:
    """Persistent random token (admin/API tokens). Stored with 0600 permissions."""
    if os.path.exists(path):
        with open(path) as f:
            return f.read().strip()
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    tok = secrets.token_urlsafe(nbytes)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        f.write(tok)
    return tok


def dumps(obj) -> str:
    return json.dumps(obj, separators=(",", ":"), default=str)


def loads(s: str | None, default=None):
    return json.loads(s) if s else default
