"""Deployment plan shape, validated by both the Pipeline and the Child Server."""
from __future__ import annotations

import re

BLOCKED_ENV = re.compile(r"^(PATH|HOME|USER|SHELL|IFS|LD_.*|PYTHON.*|BASH_.*|ENV|VALRIX_.*)$")


def validate_plan(plan: dict) -> dict:
    """Shape check shared with the Child Server (never trust a plan blindly)."""
    if not isinstance(plan, dict) or plan.get("mode") not in ("install", "run", "service"):
        raise ValueError("invalid plan mode")
    t = plan.get("timeout_s")
    if not isinstance(t, int) or not 1 <= t <= 3600:
        raise ValueError("invalid timeout")
    args, env = plan.get("args", []), plan.get("env", {})
    if not isinstance(args, list) or len(args) > 20 or not all(isinstance(a, str) and len(a) <= 200 for a in args):
        raise ValueError("invalid args")
    if not isinstance(env, dict) or len(env) > 20:
        raise ValueError("invalid env")
    for k, v in env.items():
        if not (isinstance(k, str) and isinstance(v, str) and re.fullmatch(r"[A-Z][A-Z0-9_]{1,40}", k)) \
                or BLOCKED_ENV.match(k):
            raise ValueError(f"invalid env var {k!r}")
    return plan
