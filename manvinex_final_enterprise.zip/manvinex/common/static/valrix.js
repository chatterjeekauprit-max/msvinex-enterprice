// Shared UI helpers for Valrix dashboards (no framework, no external requests).
const V = {
  key: (document.body.dataset.app || "valrix") + ".token",
  token() {
    try {
      const qToken = new URLSearchParams(window.location.search).get("token")
        || (window.location.hash.startsWith("#token=") ? window.location.hash.slice(7) : "");
      if (qToken) {
        this.setToken(qToken);
        return qToken;
      }
    } catch (e) {}
    try { return localStorage.getItem(this.key) || ""; } catch (e) { return this._t || ""; }
  },
  setToken(t) { this._t = t; try { localStorage.setItem(this.key, t); } catch (e) {} },
  async ensureToken() {
    let t = this.token();
    if (!t) {
      try {
        const res = await fetch("/api/session-token");
        if (res.ok) {
          const d = await res.json();
          if (d && d.token) {
            this.setToken(d.token);
            return d.token;
          }
        }
      } catch (e) {}
    }
    return t;
  },
  async api(method, path, body, opts = {}) {
    const headers = { Authorization: "Bearer " + this.token() };
    let payload;
    if (opts.raw) { payload = body; headers["Content-Type"] = "application/octet-stream"; }
    else if (body !== undefined) { payload = JSON.stringify(body); headers["Content-Type"] = "application/json"; }
    const r = await fetch(path, { method, headers, body: payload });
    let data = null;
    try { data = await r.json(); } catch (e) {}
    if (!r.ok) throw new Error((data && data.error) || ("HTTP " + r.status));
    return data;
  },
};

function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === null || v === undefined || v === false) continue;
    if (k === "class") el.className = v;
    else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else el.setAttribute(k, v === true ? "" : v);
  }
  for (const k of kids.flat()) {
    if (k === null || k === undefined || k === false) continue;
    el.append(k instanceof Node ? k : document.createTextNode(String(k)));
  }
  return el;
}
const $ = (s) => document.querySelector(s);
const short = (s, n = 10) => (s && s.length > n * 2 + 1 ? s.slice(0, n) + "…" + s.slice(-4) : s || "");
function ago(ts) {
  if (!ts) return "never";
  const s = Math.max(0, Math.floor(Date.now() / 1000 - ts));
  if (s < 60) return s + "s ago";
  if (s < 3600) return Math.floor(s / 60) + "m ago";
  if (s < 86400) return Math.floor(s / 3600) + "h ago";
  return new Date(ts * 1000).toLocaleString();
}
const fmtTime = (ts) => (ts ? new Date(ts * 1000).toLocaleTimeString() : "");
function txLink(txid, url) {
  if (!txid) return h("span", { class: "empty" }, "—");
  const safe = /^https?:\/\//i.test(url || "") ? url : "#";  // never render javascript:/data: links from remote data
  return h("a", { class: "tx", href: safe, target: "_blank", rel: "noopener noreferrer", title: txid }, "⛓ " + short(txid, 8));
}
function pill(text, kind) { return h("span", { class: "pill " + (kind || "") }, text); }
function toast(msg, bad) {
  let box = $("#toast");
  if (!box) { box = h("div", { id: "toast" }); document.body.append(box); }
  const d = h("div", { class: bad ? "bad" : "" }, msg);
  box.append(d);
  setTimeout(() => d.remove(), bad ? 7000 : 3500);
}
function mount(sel, ...kids) { const el = typeof sel === "string" ? $(sel) : sel; el.replaceChildren(...kids.flat().filter((k) => k !== null && k !== undefined && k !== false)); return el; }
async function guard(fn, btn) {
  if (btn) btn.disabled = true;
  try { return await fn(); } catch (e) { toast(e.message, true); } finally { if (btn) btn.disabled = false; }
}
function tokenBox(onSave) {
  const app = document.body.dataset.app || "valrix";
  const role = app === "valrix-parent" ? "Parent Server" : app === "valrix-pipeline" ? "Pipeline" : "this server";
  const inp = h("input", { type: "password", placeholder: `${role} admin token (printed in its terminal)`, value: V.token() });
  return h("div", { class: "row", style: "max-width:520px" },
    inp, h("button", { class: "btn ghost", style: "flex:0 0 auto", onclick: () => {
      V.setToken(inp.value.trim());
      const oldToast = $("#toast");
      if (oldToast) oldToast.remove();
      onSave();
    } }, "Save token"));
}
