"""
Tiny stdlib-only HTTP toolkit (router, JSON client, signed requests).
No FastAPI/Flask needed, so the same code runs on a Raspberry Pi with only `cryptography`.
"""
from __future__ import annotations

import json
import os
import re
import sys
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from .crypto import sha256_hex, verify

for _stream in (sys.stdout, sys.stderr):
    if _stream and hasattr(_stream, "reconfigure"):
        try:
            _stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

MAX_BODY = 256 * 1024 * 1024  # 256 MB upload cap


class HTTPError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status
        self.message = message


class Request:
    def __init__(self, method, raw_path, headers, body):
        self.method = method
        self.raw_path = raw_path
        parsed = urllib.parse.urlsplit(raw_path)
        self.path = parsed.path
        self.query = {k: v[0] for k, v in urllib.parse.parse_qs(parsed.query).items()}
        self.headers = headers
        self.body = body
        self.params: dict = {}
        self.ctx: dict = {}

    def json(self) -> dict:
        if not self.body:
            return {}
        try:
            data = json.loads(self.body)
        except json.JSONDecodeError as e:
            raise HTTPError(400, f"invalid JSON: {e}") from e
        if not isinstance(data, dict):
            raise HTTPError(400, "JSON body must be an object")
        return data

    def bearer(self) -> str:
        h = self.headers.get("Authorization", "")
        return h[7:].strip() if h.startswith("Bearer ") else ""


class Response:
    def __init__(self, body: bytes = b"", status: int = 200, content_type: str = "application/json",
                 headers: dict | None = None):
        self.body, self.status, self.content_type, self.headers = body, status, content_type, headers or {}


def json_response(obj, status: int = 200) -> Response:
    return Response(json.dumps(obj, indent=None, default=str).encode(), status)


class App:
    def __init__(self, name: str, quiet: bool = False):
        self.name = name
        self.quiet = quiet
        self.routes = []

    def route(self, method: str, pattern: str):
        regex = re.compile("^" + re.sub(r"\{(\w+)\}", r"(?P<\1>[^/]+)", pattern) + "$")

        def deco(fn):
            self.routes.append((method, regex, fn))
            return fn
        return deco

    def handle(self, req: Request) -> Response:
        path_matched = False
        for method, regex, fn in self.routes:
            m = regex.match(req.path)
            if not m:
                continue
            path_matched = True
            if method != req.method:
                continue
            req.params = {k: urllib.parse.unquote(v) for k, v in m.groupdict().items()}
            try:
                out = fn(req)
            except HTTPError as e:
                return json_response({"error": e.message}, e.status)
            except Exception as e:  # noqa: BLE001
                traceback.print_exc()
                return json_response({"error": f"internal error: {type(e).__name__}: {e}"}, 500)
            if isinstance(out, Response):
                return out
            return json_response(out)
        return json_response({"error": "method not allowed" if path_matched else "not found"},
                             405 if path_matched else 404)

    def add_shared_static(self):
        """Serve common/static/valrix.css + valrix.js at /static/..."""
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
        types = {"valrix.css": "text/css; charset=utf-8", "valrix.js": "application/javascript; charset=utf-8"}

        @self.route("GET", "/static/{name}")
        def _static(req):
            name = req.params["name"]
            if name not in types:
                raise HTTPError(404, "not found")
            return static_file(os.path.join(base, name), types[name])

    def serve(self, host: str, port: int):
        app = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"
            server_version = f"Valrix-{app.name}"

            def _dispatch(self):
                length = int(self.headers.get("Content-Length") or 0)
                if length > MAX_BODY:
                    self._send(json_response({"error": "payload too large"}, 413))
                    return
                body = self.rfile.read(length) if length else b""
                self._send(app.handle(Request(self.command, self.path, self.headers, body)))

            def _send(self, resp: Response):
                self.send_response(resp.status)
                self.send_header("Content-Type", resp.content_type)
                self.send_header("Content-Length", str(len(resp.body)))
                self.send_header("X-Content-Type-Options", "nosniff")
                self.send_header("Cache-Control", "no-store")
                for k, v in resp.headers.items():
                    self.send_header(k, v)
                self.end_headers()
                self.wfile.write(resp.body)

            do_GET = do_POST = do_DELETE = do_PUT = _dispatch

            def log_message(self, fmt, *args):
                if not app.quiet:
                    sys.stderr.write(f"[{app.name}] {self.address_string()} {fmt % args}\n")

        srv = ThreadingHTTPServer((host, port), Handler)
        srv.daemon_threads = True
        print(f"[{self.name}] listening on http://{host}:{port}", flush=True)
        try:
            srv.serve_forever()
        except KeyboardInterrupt:
            pass


def static_file(path: str, content_type: str = "text/html; charset=utf-8") -> Response:
    with open(path, "rb") as f:
        return Response(f.read(), 200, content_type,
                        {"Content-Security-Policy": "default-src 'self'; style-src 'self' 'unsafe-inline'; "
                                                    "script-src 'self' 'unsafe-inline'; img-src 'self' data:"})


# ---------------------------------------------------------------- client

class ClientError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(f"HTTP {status}: {message}")
        self.status = status
        self.message = message


def http(method: str, url: str, json_body=None, data: bytes | None = None, headers: dict | None = None,
         timeout: float = 20.0) -> bytes:
    hdrs = dict(headers or {})
    if json_body is not None:
        data = json.dumps(json_body).encode()
        hdrs.setdefault("Content-Type", "application/json")
    req = urllib.request.Request(url, data=data, method=method, headers=hdrs)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.read()
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            msg = json.loads(raw).get("error") or json.loads(raw).get("message") or raw.decode()
        except Exception:  # noqa: BLE001
            msg = raw.decode(errors="replace")[:300]
        raise ClientError(e.code, msg) from None
    except urllib.error.URLError as e:
        raise ClientError(0, f"cannot reach {url}: {e.reason}") from None


def http_json(method: str, url: str, **kw):
    raw = http(method, url, **kw)
    return json.loads(raw) if raw else None


# ---------------------------------------------------------------- signed device requests

SIG_WINDOW_S = 120


def _req_string(method: str, path: str, ts: str, body: bytes) -> bytes:
    return f"{method}\n{path}\n{ts}\n{sha256_hex(body or b'')}".encode()


def sign_request(identity, method: str, path: str, body: bytes = b"") -> dict:
    ts = str(int(time.time()))
    return {"X-Valrix-Address": identity.address, "X-Valrix-Ts": ts,
            "X-Valrix-Sig": identity.sign("http-request", _req_string(method, path, ts, body))}


def verify_request(req: Request) -> str:
    """Returns the verified signer address, or raises 401."""
    addr = req.headers.get("X-Valrix-Address", "")
    ts = req.headers.get("X-Valrix-Ts", "")
    sig = req.headers.get("X-Valrix-Sig", "")
    if not (addr and ts and sig):
        raise HTTPError(401, "missing request signature")
    try:
        if abs(time.time() - int(ts)) > SIG_WINDOW_S:
            raise HTTPError(401, "request timestamp outside allowed window")
    except ValueError:
        raise HTTPError(401, "bad timestamp") from None
    if not verify(addr, "http-request", _req_string(req.method, req.raw_path, ts, req.body), sig):
        raise HTTPError(401, "bad request signature")
    return addr
