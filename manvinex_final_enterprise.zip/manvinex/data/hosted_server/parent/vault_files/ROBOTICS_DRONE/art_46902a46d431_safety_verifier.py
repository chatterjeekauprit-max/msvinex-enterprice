"""
Safety verifier for Autonomous Drone Patrol.
Checks collision buffer and GPS signal lock.
"""

def verify_safety_envelope(alt: float, battery: float) -> bool:
    if battery < 20.0:
        return False
    if alt > 120.0 or alt < 5.0:
        return False
    return True
