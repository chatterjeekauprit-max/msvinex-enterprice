import json, os, sys
from calib import calibrate
cfg = json.load(open("config.json"))
print("bundle ok:", calibrate(cfg["raw"], cfg["offset"]), "args:", sys.argv[1:], "MODE:", os.environ.get("MODE"))
