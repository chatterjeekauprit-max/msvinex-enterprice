def calibrate(values, offset):
    return [round(v - offset, 3) for v in values]
