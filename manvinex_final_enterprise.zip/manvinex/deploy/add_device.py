"""
Valrix — guided "Add a Child Device" helper.

Ye tool kisi bhi network-reachable Linux device (Raspberry Pi ya koi SBC) ko
ek command se probe karta hai, uski capability/limitation ka report deta hai,
aur exact step-by-step setup guide banata hai. --setup lagao to wahi steps
khud chala bhi deta hai (deps install + valrix copy + enroll).

Ye REAL Valrix ke upar baithta hai — crypto/blockchain ko haath nahi lagata.
Sirf wahi setup automate karta hai jo abhi haath se karte hain.

  # 1) Sirf dekho device kya kar sakta hai (kuch badlega nahi — safe):
  python deploy/add_device.py --host dronepi.local --user sutirtha_halder

  # 2) Setup khud kar do (deps + valrix copy):
  python deploy/add_device.py --host dronepi.local --user sutirtha_halder --setup

  # 3) Setup + enroll (pipeline se token dashboard se milega):
  python deploy/add_device.py --host dronepi.local --user sutirtha_halder --setup \
      --enroll --child-id CHILD_RPI --token enr_xxxx \
      --pipeline http://192.168.1.50:8000 --trust-parent http://192.168.1.50:8100

Requirements: laptop par system `ssh`/`scp` (Windows 10+, mac, Linux — sab mein hote hain).
Koi extra python package nahi. Device ka OS/firmware NAHI badalta (sirf packages install).

Note: ye Linux/SSH devices ke liye hai (Pi, SBC, laptop). MCU (ESP32/Arduino) ka
serial-flash raasta alag hota hai — wo ek alag adapter hai, yaha shaamil nahi.
"""
from __future__ import annotations

import argparse
import os
import shlex
import subprocess
import sys

# ---- ek hi remote script se sara probe (ek hi password prompt) -----------------
PROBE = r"""
echo VALRIX_PROBE_START
echo "hostname=$(hostname 2>/dev/null)"
echo "arch=$(uname -m 2>/dev/null)"
echo "kernel=$(uname -r 2>/dev/null)"
if [ -r /etc/os-release ]; then . /etc/os-release; echo "os=$PRETTY_NAME"; else echo "os=unknown"; fi
echo "cores=$(nproc 2>/dev/null)"
if [ -r /proc/meminfo ]; then
  kb=$(awk '/MemTotal/{print $2}' /proc/meminfo); echo "mem_mb=$((kb/1024))"
else echo "mem_mb=0"; fi
# Raspberry Pi model (agar Pi hai)
if [ -r /proc/device-tree/model ]; then echo "model=$(tr -d '\0' </proc/device-tree/model)"; else echo "model="; fi
# Python + Valrix ki dependencies
echo "python=$(python3 --version 2>&1)"
python3 -c "import cryptography" 2>/dev/null && echo "has_cryptography=1" || echo "has_cryptography=0"
python3 -c "import cv2" 2>/dev/null && echo "has_opencv=1" || echo "has_opencv=0"
python3 -c "import picamera2" 2>/dev/null && echo "has_picamera2=1" || echo "has_picamera2=0"
# Camera detection (best-effort)
vid=$(ls /dev/video* 2>/dev/null | wc -l); echo "video_devices=$vid"
( command -v rpicam-hello >/dev/null 2>&1 || command -v libcamera-hello >/dev/null 2>&1 ) && echo "has_libcamera=1" || echo "has_libcamera=0"
# valrix folder already hai kya
[ -d "$HOME/valrix" ] && echo "valrix_dir=1" || echo "valrix_dir=0"
# apt available (dependencies install ho sakti hain kya)
command -v apt-get >/dev/null 2>&1 && echo "has_apt=1" || echo "has_apt=0"
echo VALRIX_PROBE_END
"""


def ssh_base(user: str, host: str, port: int) -> list[str]:
    return ["ssh", "-p", str(port),
            "-o", "StrictHostKeyChecking=accept-new",
            "-o", "ConnectTimeout=10",
            f"{user}@{host}"]


def run_capture(cmd: list[str]) -> tuple[int, str]:
    """Run a command, capture stdout, let stderr (incl. password prompt) reach the console."""
    p = subprocess.run(cmd, stdout=subprocess.PIPE, text=True)
    return p.returncode, p.stdout


def run_live(cmd: list[str]) -> int:
    """Run a command with output going straight to the console (for install/copy/enroll)."""
    return subprocess.run(cmd).returncode


def probe(user: str, host: str, port: int) -> dict[str, str]:
    print(f"→ {host} ko probe kar rahe hain (SSH)… password maange to daal do.\n")
    rc, out = run_capture(ssh_base(user, host, port) + [PROBE])
    if "VALRIX_PROBE_START" not in out:
        print("✗ Probe fail hua — SSH connect nahi hua ya device ne jawab nahi diya.")
        print("  Check: device on hai? same network? username/host sahi hai?")
        if rc != 0:
            print(f"  (ssh exit code {rc})")
        sys.exit(1)
    facts: dict[str, str] = {}
    inside = False
    for line in out.splitlines():
        if line.strip() == "VALRIX_PROBE_START":
            inside = True
            continue
        if line.strip() == "VALRIX_PROBE_END":
            break
        if inside and "=" in line:
            k, _, v = line.partition("=")
            facts[k.strip()] = v.strip()
    return facts


def yes(v: str | None) -> bool:
    return str(v) == "1"


def capability_report(f: dict[str, str]) -> tuple[list[str], list[str], list[str]]:
    """Return (can_run, limitations, missing_deps)."""
    can, limits, missing = [], [], []

    has_py = f.get("python", "").lower().startswith("python 3") or "python 3" in f.get("python", "").lower()
    if not has_py:
        limits.append("python3 nahi mila — Valrix agent ke liye python3 chahiye (apt install python3).")
    # cryptography = agent chalane ke liye zaroori
    if not yes(f.get("has_cryptography")):
        missing.append("python3-cryptography")
    # opencv = CV capabilities ke liye
    if not yes(f.get("has_opencv")):
        missing.append("python3-opencv")
    if not yes(f.get("has_picamera2")):
        missing.append("python3-picamera2")

    # Base: agent chal sakta hai (python + cryptography install ho jaaye)
    if has_py:
        can.append("Valrix Child agent (deploy + 12 verification checks + on-chain receipts)")
        can.append("General python capabilities (jaise semiconductor/drone telemetry samples)")

    # Camera / CV
    cam = int(f.get("video_devices", "0") or 0) > 0 or yes(f.get("has_libcamera"))
    opencv_ok = yes(f.get("has_opencv")) or "python3-opencv" in missing  # installable
    if opencv_ok:
        can.append("CV capabilities: motion_detection / face_detection / human_detection (OpenCV)")
        if cam:
            can.append("Real camera input (SOURCE=camera) — live detection")
        else:
            limits.append("Camera detect nahi hui — CV chalega par SOURCE=mock (synthetic). "
                          "Real camera ke liye: camera connect + enable karo.")
    else:
        limits.append("OpenCV install nahi ho sakta lagta — CV capabilities skip.")

    # Arch / RAM notes
    arch = f.get("arch", "")
    if arch in ("armv6l", "armv7l"):
        limits.append(f"Arch {arch} (32-bit ARM) — halka to chalega, bhaari ML models slow ho sakte hain.")
    mem = int(f.get("mem_mb", "0") or 0)
    if 0 < mem < 512:
        limits.append(f"RAM sirf {mem} MB — sirf halke kaam recommended.")

    if not yes(f.get("has_apt")):
        limits.append("apt-get nahi mila — dependencies khud (manually) install karni padengi.")
    return can, limits, missing


def print_report(f: dict[str, str], can, limits, missing):
    print("=" * 64)
    print(" DEVICE REPORT")
    print("=" * 64)
    model = f.get("model") or f.get("hostname", "?")
    print(f" Device   : {model}")
    print(f" OS       : {f.get('os','?')}   ({f.get('arch','?')}, kernel {f.get('kernel','?')})")
    print(f" CPU/RAM  : {f.get('cores','?')} cores / {f.get('mem_mb','?')} MB")
    print(f" Python   : {f.get('python','?')}")
    print("-" * 64)
    print(" ✅ Ye device ye kaam kar sakta hai:")
    for c in can:
        print(f"    • {c}")
    if limits:
        print("\n ⚠️  Limitations / dhyaan do:")
        for l in limits:
            print(f"    • {l}")
    if missing:
        print(f"\n 📦 Install karni padengi: {', '.join(missing)}")
    print("=" * 64)


def guide(user, host, port, f, missing, valrix_dir, child_id, pipeline, parents):
    """Print the exact step-by-step commands (personalised)."""
    print("\n GUIDED SETUP — ye steps chalane hain (ya --setup se main khud kar dun):\n")
    n = 1
    if missing and yes(f.get("has_apt")):
        pkgs = " ".join(missing)
        print(f" {n}) Device par dependencies:")
        print(f"      ssh {user}@{host} 'sudo apt update && sudo apt install -y {pkgs}'")
        n += 1
    if not yes(f.get("valrix_dir")):
        src = valrix_dir or "<valrix folder path>"
        print(f" {n}) valrix folder device par bhejo (laptop se):")
        print(f"      scp -r {src} {user}@{host}:~/valrix")
        n += 1
    tp = " ".join(f"--trust-parent {p}" for p in parents) if parents else "--trust-parent http://<PARENT_IP>:8100"
    pl = pipeline or "http://<PIPELINE_IP>:8000"
    cid = child_id or "CHILD_RPI"
    print(f" {n}) Device par enroll (token dashboard → Child Servers se):")
    print(f"      ssh {user}@{host} 'cd ~/valrix && python3 -m child_server enroll "
          f"--pipeline {pl} --child-id {cid} --token enr_xxxx {tp}'")
    n += 1
    print(f" {n}) Device par agent chalao (chalta rahega):")
    print(f"      ssh {user}@{host} 'cd ~/valrix && python3 -m child_server run'")
    print("\n Uske baad Pipeline dashboard se deploy karo — bas.\n")


def do_setup(user, host, port, f, missing, valrix_dir):
    base = ssh_base(user, host, port)
    if missing and yes(f.get("has_apt")):
        print(f"\n→ Dependencies install kar rahe hain: {', '.join(missing)} (sudo password maang sakta hai)…")
        rc = run_live(base + [f"sudo apt-get update && sudo apt-get install -y {' '.join(missing)}"])
        if rc != 0:
            print("✗ Dependency install fail. Ruk gaye — upar error dekho."); sys.exit(1)
    if not yes(f.get("valrix_dir")):
        if not valrix_dir:
            print("\n✗ --valrix-dir nahi diya, aur device par valrix folder nahi hai. "
                  "valrix folder ka path do (jaise --valrix-dir .)."); sys.exit(1)
        if not os.path.isdir(valrix_dir):
            print(f"\n✗ Local path nahi mila: {valrix_dir}"); sys.exit(1)
        print(f"\n→ valrix folder bhej rahe hain ({valrix_dir} → {host}:~/valrix)…")
        rc = run_live(["scp", "-P", str(port), "-r", valrix_dir, f"{user}@{host}:~/valrix"])
        if rc != 0:
            print("✗ Copy fail."); sys.exit(1)
    else:
        print("\n→ valrix folder device par pehle se hai — copy skip.")
    print("✓ Setup ho gaya.")


def do_enroll(user, host, port, child_id, token, pipeline, parents):
    tp = " ".join(f"--trust-parent {shlex.quote(p)}" for p in parents)
    cmd = (f"cd ~/valrix && python3 -m child_server enroll "
           f"--pipeline {shlex.quote(pipeline)} --child-id {shlex.quote(child_id)} "
           f"--token {shlex.quote(token)} {tp}")
    print(f"\n→ Device par enroll kar rahe hain ({child_id})…")
    rc = run_live(ssh_base(user, host, port) + [cmd])
    if rc != 0:
        print("✗ Enroll fail — token expired ho sakta hai (dashboard se naya lo)."); sys.exit(1)
    print("✓ Enroll ho gaya.")
    print(f"\n Ab agent chalao:  ssh {user}@{host} 'cd ~/valrix && python3 -m child_server run'")
    print(" (ya background/systemd ke liye deploy/valrix-child.service use karo)")


def main():
    ap = argparse.ArgumentParser(description="Valrix — guided Add-a-Child-Device helper")
    ap.add_argument("--host", required=True, help="device hostname ya IP (jaise dronepi.local)")
    ap.add_argument("--user", required=True, help="device ka SSH username")
    ap.add_argument("--port", type=int, default=22, help="SSH port (default 22)")
    ap.add_argument("--setup", action="store_true", help="deps install + valrix copy khud kar do")
    ap.add_argument("--valrix-dir", help="local valrix folder ka path (copy ke liye; jaise .)")
    ap.add_argument("--enroll", action="store_true", help="setup ke baad device ko enroll bhi karo")
    ap.add_argument("--child-id", help="enroll ke liye Child ID (jaise CHILD_RPI)")
    ap.add_argument("--token", help="enroll token (dashboard → Child Servers se)")
    ap.add_argument("--pipeline", help="Pipeline URL (jaise http://192.168.1.50:8000)")
    ap.add_argument("--trust-parent", action="append", default=[], help="Parent Server URL (repeatable)")
    a = ap.parse_args()

    f = probe(a.user, a.host, a.port)
    can, limits, missing = capability_report(f)
    print_report(f, can, limits, missing)

    if a.setup:
        do_setup(a.user, a.host, a.port, f, missing, a.valrix_dir)
        if a.enroll:
            if not (a.child_id and a.token and a.pipeline):
                print("\n⚠️ Enroll ke liye --child-id, --token aur --pipeline chahiye. Skip kar diya.")
                guide(a.user, a.host, a.port, f, missing, a.valrix_dir, a.child_id, a.pipeline, a.trust_parent)
            else:
                do_enroll(a.user, a.host, a.port, a.child_id, a.token, a.pipeline, a.trust_parent)
    else:
        guide(a.user, a.host, a.port, f, missing, a.valrix_dir, a.child_id, a.pipeline, a.trust_parent)
        print(" (Kuch badla nahi — ye sirf report + guide tha. Khud karwana ho to --setup lagao.)")


if __name__ == "__main__":
    main()
