#!/usr/bin/env bash
# Automated Production Systemd Installer for Valrix
# Supports Debian, Ubuntu, and Raspberry Pi OS.
set -e

if [ "$EUID" -ne 0 ]; then
    echo "[ERROR] Please run as root: sudo bash deploy/install_systemd.sh" >&2
    exit 1
fi

echo "================================================================"
echo " VALRIX: INSTALLING PRODUCTION SYSTEMD SERVICES"
echo "================================================================"

# 1. Create system user
if ! id -u valrix >/dev/null 2>&1; then
    echo "Creating system user 'valrix'..."
    useradd --system --create-home --home-dir /opt/valrix-data valrix
fi

# 2. Setup directories
echo "Configuring directories in /opt/valrix and /opt/valrix-data..."
mkdir -p /opt/valrix
mkdir -p /opt/valrix-data/{devnet,parent,pipeline,child}
cp -r ./* /opt/valrix/
chown -R valrix:valrix /opt/valrix /opt/valrix-data

# 3. Install Python dependencies
echo "Verifying Python dependencies..."
apt-get update -y
apt-get install -y python3 python3-pip python3-cryptography

# 4. Install systemd units
echo "Installing systemd service units..."
cp deploy/valrix-devnet.service /etc/systemd/system/
cp deploy/valrix-parent.service /etc/systemd/system/
cp deploy/valrix-pipeline.service /etc/systemd/system/
cp deploy/valrix-child.service /etc/systemd/system/

systemctl daemon-reload

echo "Enabling Valrix services on boot..."
systemctl enable valrix-devnet valrix-parent valrix-pipeline valrix-child

echo "Starting Valrix services..."
systemctl restart valrix-devnet
sleep 2
systemctl restart valrix-parent
systemctl restart valrix-pipeline
systemctl restart valrix-child

echo ""
echo "================================================================"
echo " VALRIX PRODUCTION SERVICES INSTALLED & RUNNING!"
echo " Check status with: systemctl status valrix-pipeline"
echo " Web UI: http://localhost:8000/"
echo "================================================================"
