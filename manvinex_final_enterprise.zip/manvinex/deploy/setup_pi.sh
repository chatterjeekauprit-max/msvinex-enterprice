#!/usr/bin/env bash
# One-time setup on a Raspberry Pi so the Valrix computer-vision capabilities can run.
# Installs OpenCV (+ numpy) and the Pi camera stack. Run once; deployments after that are fast.
#
#   bash deploy/setup_pi.sh
#
set -e
echo "[valrix] installing OpenCV + camera stack for the Child Server…"

sudo apt-get update
# picamera2 is the modern Pi camera library; python3-opencv pulls a prebuilt OpenCV (no long compile)
sudo apt-get install -y python3-pip python3-opencv python3-numpy python3-picamera2

# Fallback if the apt OpenCV is unavailable on your image:
python3 -c "import cv2" 2>/dev/null || pip3 install --break-system-packages opencv-python-headless numpy

echo "[valrix] verifying…"
python3 - <<'PY'
import cv2, numpy as np
hog = cv2.HOGDescriptor(); hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
print("OpenCV", cv2.__version__, "- HOG people detector OK, Haar cascades at", cv2.data.haarcascades)
try:
    from picamera2 import Picamera2  # noqa: F401
    print("picamera2 available - the Pi camera v2 will work with SOURCE=camera")
except Exception as e:
    print("picamera2 not available (", e, ") - OpenCV VideoCapture(0) will be used instead")
PY

echo "[valrix] done. Enroll this device, then deploy a capability with SOURCE=camera, e.g.:"
echo '   prompt: + HUMAN_DETECTION -> CHILD_RPI_01  SOURCE=camera MAX_FRAMES=0'
