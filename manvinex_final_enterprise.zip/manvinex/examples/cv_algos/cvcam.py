"""
Shared helpers for the Valrix computer-vision capabilities.

Frame source is chosen by the SOURCE env var (set from the deployment prompt/plan):
  mock          synthetic frames (a moving block) - always works, used for demos/tests
  camera        the Raspberry Pi camera: tries picamera2, then OpenCV VideoCapture(0)
  /path/img.jpg a single image file, processed once

Detection results are printed as one JSON line per frame, plus a final SUMMARY line, so the
Pipeline/Child receipt captures a clear, structured record.

These scripts run on the Pi (real camera) AND in the sandbox (mock) so the whole deployment
pipeline is demonstrable end-to-end without hardware.
"""
from __future__ import annotations

import json
import os
import sys
import time

try:
    import cv2
    import numpy as np
    HAVE_CV = True
except Exception:  # noqa: BLE001
    HAVE_CV = False


def env(name: str, default: str = "") -> str:
    return os.environ.get(name, default)


def env_float(name: str, default: float) -> float:
    try:
        return float(os.environ.get(name, default))
    except (TypeError, ValueError):
        return default


def env_int(name: str, default: int) -> int:
    try:
        return int(float(os.environ.get(name, default)))
    except (TypeError, ValueError):
        return default


def emit(obj: dict):
    print(json.dumps(obj), flush=True)


def banner(capability: str):
    emit({"valrix_cv": capability, "source": env("SOURCE", "mock"),
          "deployment": env("VALRIX_DEPLOYMENT_ID"), "parent": env("VALRIX_PARENT_ID"),
          "child": env("VALRIX_CHILD_ID"), "opencv": HAVE_CV})


def require_cv(capability: str) -> bool:
    """If OpenCV isn't installed (e.g. a bare sandbox), report readiness and exit cleanly."""
    if HAVE_CV:
        return True
    emit({"valrix_cv": capability, "status": "ready",
          "note": "OpenCV not installed here; install on the Pi (see deploy/setup_pi.sh). "
                  "Deployment verified end-to-end; detection runs on the device."})
    emit({"SUMMARY": {"capability": capability, "frames": 0, "detections": 0, "opencv": False}})
    sys.exit(0)


class FrameSource:
    """Yields (index, frame) tuples. Stops after max_frames unless it's a live camera in service mode."""

    def __init__(self, source: str, max_frames: int):
        self.source = source or "mock"
        self.max_frames = max_frames
        self.cap = None
        self.picam = None
        self._mock_i = 0
        if self.source == "camera":
            self._open_camera()

    def _open_camera(self):
        try:
            from picamera2 import Picamera2  # type: ignore
            self.picam = Picamera2()
            cfg = self.picam.create_preview_configuration(main={"size": (640, 480)})
            self.picam.configure(cfg)
            self.picam.start()
            time.sleep(0.5)
            return
        except Exception:  # noqa: BLE001
            self.picam = None
        self.cap = cv2.VideoCapture(0)
        if not self.cap or not self.cap.isOpened():
            emit({"error": "no camera available; falling back to mock frames"})
            self.source = "mock"

    def _mock_frame(self):
        f = np.zeros((480, 640, 3), dtype=np.uint8)
        # a block that moves across the frame -> motion detectors will fire
        x = (self._mock_i * 40) % 560
        cv2.rectangle(f, (x, 200), (x + 80, 300), (255, 255, 255), -1)
        self._mock_i += 1
        return f

    def frames(self):
        if self.source not in ("mock", "camera"):  # image file
            img = cv2.imread(self.source)
            if img is None:
                emit({"error": f"cannot read image {self.source}"})
                return
            yield 0, img
            return
        i = 0
        while self.max_frames <= 0 or i < self.max_frames:
            if self.picam is not None:
                frame = self.picam.capture_array()
                frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
            elif self.cap is not None:
                ok, frame = self.cap.read()
                if not ok:
                    break
            else:
                frame = self._mock_frame()
                time.sleep(0.02)
            yield i, frame
            i += 1

    def close(self):
        if self.cap is not None:
            self.cap.release()
        if self.picam is not None:
            try:
                self.picam.stop()
            except Exception:  # noqa: BLE001
                pass


def run_loop(capability: str, detect_fn):
    """Common driver: build the source, run detect_fn(frame)->list[boxes] per frame, print summary."""
    require_cv(capability)
    banner(capability)
    source = env("SOURCE", "mock")
    # service mode runs until stopped; run/once modes process a fixed number of frames
    default_frames = 30
    max_frames = env_int("MAX_FRAMES", default_frames)
    src = FrameSource(source, max_frames)
    frames = hits = total_dets = 0
    try:
        for i, frame in src.frames():
            frames += 1
            boxes = detect_fn(frame)
            if boxes:
                hits += 1
                total_dets += len(boxes)
                emit({"frame": i, "detections": len(boxes),
                      "boxes": [[int(x), int(y), int(w), int(h)] for (x, y, w, h) in boxes[:20]]})
    except KeyboardInterrupt:
        pass
    finally:
        src.close()
    emit({"SUMMARY": {"capability": capability, "frames": frames, "frames_with_detection": hits,
                      "total_detections": total_dets, "source": source}})
