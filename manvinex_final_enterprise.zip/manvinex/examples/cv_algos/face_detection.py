"""
Valrix capability: face_detection
OpenCV Haar cascade (ships with OpenCV - no download). Pi-friendly.

Prompt/env params:
  SOURCE      mock | camera | <image path>
  SCALE       cascade scaleFactor (default 1.1)
  MIN_NEIGH   minNeighbors (default 5)
  MAX_FRAMES  frames to process (0 = until stopped)
"""
from __future__ import annotations

import os

import cvcam

_cascade = {"c": None}


def _get_cascade():
    import cv2
    if _cascade["c"] is None:
        path = os.path.join(cv2.data.haarcascades, "haarcascade_frontalface_default.xml")
        _cascade["c"] = cv2.CascadeClassifier(path)
    return _cascade["c"]


def detect(frame):
    import cv2
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = _get_cascade().detectMultiScale(
        gray, scaleFactor=cvcam.env_float("SCALE", 1.1),
        minNeighbors=cvcam.env_int("MIN_NEIGH", 5), minSize=(30, 30))
    return [tuple(int(v) for v in f) for f in faces]


if __name__ == "__main__":
    cvcam.run_loop("face_detection", detect)
