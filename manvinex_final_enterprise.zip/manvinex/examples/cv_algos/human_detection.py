"""
Valrix capability: human_detection
OpenCV HOG + SVM people detector (built into OpenCV - no model download). Runs on a Pi.

If you later drop a real .tflite model (e.g. SSD MobileNet) into the vault and add a
model_registry.csv row, you can switch this capability to that model - the catalog makes the
swap without touching the pipeline. This built-in detector is the zero-dependency default.

Prompt/env params:
  SOURCE      mock | camera | <image path>
  CONF        min detection weight (default 0.5)
  MAX_FRAMES  frames to process (0 = until stopped)
"""
from __future__ import annotations

import cvcam

_hog = {"h": None}
CONF = cvcam.env_float("CONF", 0.5)


def _get_hog():
    import cv2
    if _hog["h"] is None:
        h = cv2.HOGDescriptor()
        h.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
        _hog["h"] = h
    return _hog["h"]


def detect(frame):
    import cv2
    frame = cv2.resize(frame, (640, 480))
    rects, weights = _get_hog().detectMultiScale(frame, winStride=(8, 8), padding=(8, 8), scale=1.05)
    return [tuple(int(v) for v in r) for r, w in zip(rects, weights) if w >= CONF]


if __name__ == "__main__":
    cvcam.run_loop("human_detection", detect)
