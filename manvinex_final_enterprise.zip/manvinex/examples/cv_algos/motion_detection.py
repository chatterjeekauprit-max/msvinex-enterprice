"""
Valrix capability: motion_detection
OpenCV frame-differencing. No model file, no download - the lightest Pi vision algo.

Prompt/env params:
  SOURCE     mock | camera | <image path>
  MIN_AREA   minimum contour area to count as motion (default 800)
  MAX_FRAMES how many frames to process (0 = until stopped; camera service mode)
"""
from __future__ import annotations

import cvcam

MIN_AREA = cvcam.env_float("MIN_AREA", 800)
_prev = {"gray": None}


def detect(frame):
    import cv2
    gray = cv2.GaussianBlur(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY), (21, 21), 0)
    if _prev["gray"] is None:
        _prev["gray"] = gray
        return []
    delta = cv2.absdiff(_prev["gray"], gray)
    _prev["gray"] = gray
    thresh = cv2.dilate(cv2.threshold(delta, 25, 255, cv2.THRESH_BINARY)[1], None, iterations=2)
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    return [cv2.boundingRect(c) for c in contours if cv2.contourArea(c) >= MIN_AREA]


if __name__ == "__main__":
    cvcam.run_loop("motion_detection", detect)
