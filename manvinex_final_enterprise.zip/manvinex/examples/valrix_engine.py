"""Sample Parent code: a tiny 'metrology engine' used in the demo."""
import os
import platform
import statistics

readings = [10.02, 9.98, 10.01, 10.00, 9.99, 10.03]
print("Valrix Core System Running")
print(f"device      : {platform.node()} ({platform.machine()})")
print(f"deployment  : {os.environ.get('VALRIX_DEPLOYMENT_ID')}")
print(f"parent      : {os.environ.get('VALRIX_PARENT_ID')}")
print(f"prompt      : {os.environ.get('VALRIX_PROMPT')}")
print(f"mean={statistics.mean(readings):.4f} stdev={statistics.stdev(readings):.4f}")
