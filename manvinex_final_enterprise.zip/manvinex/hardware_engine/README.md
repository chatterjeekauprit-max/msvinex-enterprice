# Hardware Engine: current support

This module is an early hardware-flashing integration, not a universal firmware or library manager. The board catalog describes MCU families and suggested toolchains; it does not mean each board has been tested or can be auto-detected.

## Supported paths

- **PlatformIO source project:** the Pipeline host must have `pio` or `platformio` installed, USB/serial permissions, and a project folder containing `platformio.ini`. That file must select the exact connected board, framework, upload protocol, and required libraries. Put PlatformIO library dependencies in `lib_deps`. Valrix runs `pio run -t upload`; PlatformIO handles dependency installation and the board-specific image layout. Network access may be required on the first build.
- **Standalone image:** only `.uf2` images for a `picotool` board are accepted. The UF2 contains its own address metadata. Raw `.bin`, `.hex`, and `.elf` images are rejected because their correct address and flashing layout depend on the board and build.
- **Linux Child:** Python/Linux packages can use Parent → Pipeline → Child deployment on a Raspberry Pi or Linux edge host. This is separate from MCU flashing; it does not turn a Linux Child into a remote USB flash host.

The Hardware tab reports whether common CLI tools are present on the Pipeline host. It does not scan USB devices or prove that a specific board is attached. Check that the selected board, PlatformIO environment, cable/boot mode, and port match before upload.

## Library / dependency checker (`libraries.py`)

Given a reviewed PlatformIO project directory or an Arduino sketch directory, the checker reports what's already installed on the host vs. what the project declares — read-only, no network calls, no guessing:

- `check_readiness(board_id, project_dir=None)` / API `GET /api/hardware/readiness` — board info, whether the board's flash tool, `pio`, and `arduino-cli` are present on the host, plus the project's dependency status if `project_dir` is given.
- `check_libraries(project_dir)` / API `GET /api/hardware/check-libraries` — for a PlatformIO project, parses `platformio.ini`'s `lib_deps` per environment and cross-checks them against `pio pkg list`. For an Arduino sketch, scans `#include` lines and matches known headers to their library name; anything not in the built-in header map is reported under `unrecognized_includes` rather than guessed at.
- `install_libraries(...)` / API `POST /api/hardware/install-libraries` — installs a project's **own already-declared** PlatformIO `lib_deps` (via `pio pkg install`), or **one explicitly named** Arduino library (via `arduino-cli lib install <name>`). Requires `confirm: true`; refuses otherwise. This never fetches a dependency the project didn't already name, and never runs against a project directory that hasn't been reviewed.

If `pio` or `arduino-cli` isn't installed on the host, the checker still returns a clean report (tool marked absent) instead of failing — install PlatformIO and/or arduino-cli on the Pipeline host to get live install status and one-call installs.

## Not implemented

Automatic USB board identification, inferring a library from source analysis when its header isn't in the known-header map, fetching a library from an arbitrary/unreviewed source, Arduino IDE sketch conversion, generic STM32/Nordic/GD32/CH32 flashing, and WCH-Link flashing are not implemented. This is a deliberate boundary, not an oversight: auto-detecting whatever hardware happens to be plugged in and silently pulling down "whatever library looks right" for it is a supply-chain risk on physical devices — the same risk Valrix's signed, on-chain deployment flow exists to prevent elsewhere in this project. Add dependencies to a reviewed PlatformIO project (or install a named Arduino library) and use that project's supported upload flow. Never treat a missing tool or an untested board as a successful deployment.

## Tool requirements

For PlatformIO source uploads, install PlatformIO on the Pipeline host and define `platformio.ini` with the exact environment and dependencies. For standalone UF2 upload, install `picotool`. No MCU flashing can be verified without the target board and its required USB/debug interface connected.

Custom board entries are metadata only; adding one does not add a compiler, framework, library, or flashing implementation.
