"""
Hardware Engine — Valrix
========================
Built-in + extensible MCU / board support for direct flash to Child hardware.

Supported (built-in):
  - Espressif ESP32 family (ESP32, S2, S3, C3, C6, H2, P4)
  - STMicroelectronics STM32
  - Nordic nRF52 / nRF53 / nRF54
  - Raspberry Pi Pico (RP2040, RP2350)
  - GigaDevice GD32 + WCH CH32

Extensible: user can add custom boards via Add Custom Hardware.

Flow:
  User selects board → clicks Allow → system auto-builds (if needed) and flashes
  directly to the target Child / hardware. No manual code paste required.
"""

from .boards import BUILTIN_BOARDS, get_board, list_boards
from .flash import flash_firmware, auto_deploy
from .manager import HardwareEngine
from .libraries import (
    check_platformio_project,
    install_platformio_deps,
    check_arduino_sketch,
    install_arduino_library,
    check_board_readiness,
)

__all__ = [
    "HardwareEngine",
    "BUILTIN_BOARDS",
    "get_board",
    "list_boards",
    "flash_firmware",
    "auto_deploy",
    "check_platformio_project",
    "install_platformio_deps",
    "check_arduino_sketch",
    "install_arduino_library",
    "check_board_readiness",
]
