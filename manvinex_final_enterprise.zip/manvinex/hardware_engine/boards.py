"""
Built-in board / MCU definitions for Hardware Engine.
"""

from __future__ import annotations
from typing import Any

# Each entry:
#   id            unique short id
#   name          display name
#   manufacturer  company
#   mcu           main chip family
#   frameworks    preferred toolchains
#   flash_tool    primary CLI tool for flashing
#   platformio    PlatformIO board / platform id (if any)
#   arduino_core  Boards Manager URL or package name
#   notes         short description

BUILTIN_BOARDS: list[dict[str, Any]] = [
    # ---- Espressif ----
    {
        "id": "esp32",
        "name": "ESP32",
        "manufacturer": "Espressif",
        "mcu": "ESP32",
        "frameworks": ["arduino", "esp-idf", "platformio"],
        "flash_tool": "esptool",
        "platformio": "espressif32",
        "arduino_core": "https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json",
        "notes": "Classic dual-core Wi-Fi + BLE",
    },
    {
        "id": "esp32-s3",
        "name": "ESP32-S3",
        "manufacturer": "Espressif",
        "mcu": "ESP32-S3",
        "frameworks": ["arduino", "esp-idf", "platformio"],
        "flash_tool": "esptool",
        "platformio": "espressif32",
        "arduino_core": "https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json",
        "notes": "AI vector, USB-OTG, high performance",
    },
    {
        "id": "esp32-c3",
        "name": "ESP32-C3",
        "manufacturer": "Espressif",
        "mcu": "ESP32-C3",
        "frameworks": ["arduino", "esp-idf", "platformio"],
        "flash_tool": "esptool",
        "platformio": "espressif32",
        "arduino_core": "https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json",
        "notes": "RISC-V, low-cost Wi-Fi + BLE",
    },
    {
        "id": "esp32-c6",
        "name": "ESP32-C6",
        "manufacturer": "Espressif",
        "mcu": "ESP32-C6",
        "frameworks": ["arduino", "esp-idf", "platformio"],
        "flash_tool": "esptool",
        "platformio": "espressif32",
        "arduino_core": "https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json",
        "notes": "Wi-Fi 6 + Thread / Matter",
    },
    {
        "id": "esp32-h2",
        "name": "ESP32-H2",
        "manufacturer": "Espressif",
        "mcu": "ESP32-H2",
        "frameworks": ["arduino", "esp-idf", "platformio"],
        "flash_tool": "esptool",
        "platformio": "espressif32",
        "arduino_core": "https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json",
        "notes": "Thread / Zigbee only (no Wi-Fi)",
    },
    {
        "id": "esp32-p4",
        "name": "ESP32-P4",
        "manufacturer": "Espressif",
        "mcu": "ESP32-P4",
        "frameworks": ["esp-idf", "platformio"],
        "flash_tool": "esptool",
        "platformio": "espressif32",
        "arduino_core": None,
        "notes": "High-performance RISC-V IoT",
    },
    # ---- STMicroelectronics ----
    {
        "id": "stm32",
        "name": "STM32 (generic)",
        "manufacturer": "STMicroelectronics",
        "mcu": "STM32",
        "frameworks": ["arduino", "stm32cube", "platformio"],
        "flash_tool": "openocd",
        "platformio": "ststm32",
        "arduino_core": "stm32duino",
        "notes": "Industrial / general purpose Cortex-M",
    },
    # ---- Nordic ----
    {
        "id": "nrf52",
        "name": "nRF52",
        "manufacturer": "Nordic Semiconductor",
        "mcu": "nRF52",
        "frameworks": ["nrf-connect-sdk", "zephyr", "platformio"],
        "flash_tool": "nrfutil",
        "platformio": "nordicnrf52",
        "arduino_core": None,
        "notes": "BLE / low-power flagship",
    },
    {
        "id": "nrf53",
        "name": "nRF53",
        "manufacturer": "Nordic Semiconductor",
        "mcu": "nRF53",
        "frameworks": ["nrf-connect-sdk", "zephyr"],
        "flash_tool": "nrfutil",
        "platformio": None,
        "arduino_core": None,
        "notes": "Multi-protocol, dual-core wireless SoC; use a board-specific Zephyr/PlatformIO project",
    },
    {
        "id": "nrf54",
        "name": "nRF54",
        "manufacturer": "Nordic Semiconductor",
        "mcu": "nRF54",
        "frameworks": ["nrf-connect-sdk", "zephyr"],
        "flash_tool": "nrfutil",
        "platformio": None,
        "arduino_core": None,
        "notes": "Next-gen ultra-low-power + AI",
    },
    # ---- Raspberry Pi ----
    {
        "id": "rp2040",
        "name": "Raspberry Pi Pico (RP2040)",
        "manufacturer": "Raspberry Pi",
        "mcu": "RP2040",
        "frameworks": ["arduino", "pico-sdk", "micropython", "platformio"],
        "flash_tool": "picotool",
        "platformio": "raspberrypi",
        "arduino_core": "https://github.com/earlephilhower/arduino-pico/releases/download/global/package_rp2040_index.json",
        "notes": "Dual Cortex-M0+, PIO",
    },
    {
        "id": "rp2350",
        "name": "Raspberry Pi Pico 2 (RP2350)",
        "manufacturer": "Raspberry Pi",
        "mcu": "RP2350",
        "frameworks": ["arduino", "pico-sdk", "micropython", "platformio"],
        "flash_tool": "picotool",
        "platformio": "raspberrypi",
        "arduino_core": "https://github.com/earlephilhower/arduino-pico/releases/download/global/package_rp2040_index.json",
        "notes": "Dual M33 / optional RISC-V",
    },
    # ---- Chinese alternatives ----
    {
        "id": "gd32",
        "name": "GD32",
        "manufacturer": "GigaDevice",
        "mcu": "GD32",
        "frameworks": ["arduino", "platformio"],
        "flash_tool": "openocd",
        "platformio": "gd32",
        "arduino_core": "community",
        "notes": "STM32 pin-compatible, high volume",
    },
    {
        "id": "ch32",
        "name": "CH32 (RISC-V)",
        "manufacturer": "WCH",
        "mcu": "CH32V / CH32F",
        "frameworks": ["arduino", "wch-sdk"],
        "flash_tool": "wch-link",
        "platformio": None,
        "arduino_core": "community",
        "notes": "Ultra low-cost RISC-V",
    },
]

# Runtime custom boards (added by user)
_CUSTOM_BOARDS: list[dict[str, Any]] = []


def list_boards(include_custom: bool = True) -> list[dict[str, Any]]:
    boards = list(BUILTIN_BOARDS)
    if include_custom:
        boards.extend(_CUSTOM_BOARDS)
    return boards


def get_board(board_id: str) -> dict[str, Any] | None:
    for b in list_boards():
        if b["id"] == board_id:
            return b
    return None


def add_custom_board(board: dict[str, Any]) -> dict[str, Any]:
    """Register a custom board at runtime. Required keys: id, name, manufacturer, mcu, flash_tool"""
    required = {"id", "name", "manufacturer", "mcu", "flash_tool"}
    missing = required - set(board.keys())
    if missing:
        raise ValueError(f"Missing required keys: {missing}")
    if get_board(board["id"]):
        raise ValueError(f"Board id already exists: {board['id']}")
    board = dict(board)
    board.setdefault("frameworks", [])
    board.setdefault("platformio", None)
    board.setdefault("arduino_core", None)
    board.setdefault("notes", "Custom board")
    _CUSTOM_BOARDS.append(board)
    return board
