"""
Flash / Auto-deploy helpers for Hardware Engine.

When the user clicks Allow:
  1. Resolve board
  2. (Optional) build firmware if source is present
  3. Flash directly to the connected hardware / Child
  4. Return status

This module provides the automation layer. Real tool binaries
(esptool, openocd, nrfutil, picotool …) must be installed on the host
or on the Child that performs the flash.
"""

from __future__ import annotations

import shutil
import subprocess
from pathlib import Path
from typing import Any

from .boards import get_board


class FlashError(Exception):
    pass


def _which(cmd: str) -> str | None:
    return shutil.which(cmd)


def flash_firmware(
    board_id: str,
    firmware_path: str | Path,
    port: str | None = None,
    extra_args: list[str] | None = None,
) -> dict[str, Any]:
    """
    Flash a pre-built firmware binary to the target board.

    Returns a status dict: {"ok": bool, "board": ..., "tool": ..., "output": ...}
    """
    board = get_board(board_id)
    if not board:
        raise FlashError(f"Unknown board: {board_id}")

    firmware_path = Path(firmware_path)
    if not firmware_path.is_file():
        raise FlashError(f"Firmware not found: {firmware_path}")

    tool = board.get("flash_tool") or "esptool"
    extra_args = extra_args or []
    cmd: list[str] = []

    # Raw .bin/.hex/.elf files do not carry a universal flash layout. In
    # particular, writing an ESP32 app image at 0x0 can overwrite its bootloader.
    # Source projects must use PlatformIO's configured upload task, which knows
    # the board, framework, libraries, upload protocol and image offsets.
    if firmware_path.suffix.lower() != ".uf2" or tool != "picotool":
        raise FlashError(
            f"Cannot safely flash {firmware_path.suffix or 'this'} as a standalone image for {board_id}. "
            "Use a PlatformIO source project with platformio.ini so its board-specific upload recipe is used."
        )

    if tool == "picotool":
        picotool = _which("picotool")
        if not picotool:
            raise FlashError("picotool not found in PATH")
        cmd = [picotool, "load", str(firmware_path), "-f"]
        if port:
            cmd += ["-d", port]
        cmd += extra_args

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=120,
        )
        ok = result.returncode == 0
        return {
            "ok": ok,
            "board": board_id,
            "tool": tool,
            "cmd": cmd,
            "returncode": result.returncode,
            "stdout": result.stdout[-4000:] if result.stdout else "",
            "stderr": result.stderr[-4000:] if result.stderr else "",
        }
    except subprocess.TimeoutExpired:
        raise FlashError("Flash timed out after 120s")
    except FileNotFoundError as e:
        raise FlashError(str(e))


def auto_deploy(
    board_id: str,
    source_or_firmware: str | Path,
    port: str | None = None,
    build: bool = True,
    work_dir: str | Path | None = None,
) -> dict[str, Any]:
    """
    High-level automation entry point used by the Allow button.

    - If source_or_firmware is a .bin / .hex / .uf2 → flash directly
    - If it is a source directory / sketch → (optional) build then flash
    - Returns full status for the UI / pipeline
    """
    board = get_board(board_id)
    if not board:
        return {"ok": False, "error": f"Unknown board: {board_id}"}

    path = Path(source_or_firmware)
    status: dict[str, Any] = {
        "ok": False,
        "board": board,
        "steps": [],
    }

    # Detect pre-built firmware
    if path.is_file() and path.suffix.lower() in {".bin", ".hex", ".uf2", ".elf"}:
        status["steps"].append({"step": "detect", "result": "prebuilt firmware"})
        try:
            flash_result = flash_firmware(board_id, path, port=port)
            status["steps"].append({"step": "flash", "result": flash_result})
            status["ok"] = flash_result.get("ok", False)
            status["flash"] = flash_result
        except FlashError as e:
            status["error"] = str(e)
        return status

    # Source path – let PlatformIO use the project's selected board, dependencies,
    # upload protocol and per-artifact flash offsets. A successful compile alone
    # is not a deploy.
    if build and path.is_dir():
        status["steps"].append({"step": "detect", "result": "source directory"})
        pio = _which("pio") or _which("platformio")
        if not (path / "platformio.ini").is_file():
            status["error"] = "PlatformIO source directory must contain platformio.ini with a board environment and required libraries"
            return status
        if pio:
            try:
                cmd = [pio, "run", "-d", str(path), "-t", "upload"]
                if port:
                    cmd += ["--upload-port", port]
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
                status["steps"].append({
                    "step": "build",
                    "returncode": result.returncode,
                    "stdout_tail": (result.stdout or "")[-2000:],
                    "stderr_tail": (result.stderr or "")[-2000:],
                })
                if result.returncode != 0:
                    status["error"] = "Build failed; see build output"
                    return status
                status["steps"].append({"step": "build_and_flash", "result": "success"})
                status["ok"] = True
            except Exception as e:
                status["error"] = str(e)
        else:
            status["error"] = "PlatformIO is required to build source; install it on the flash host or provide a prebuilt firmware file"
    else:
        status["error"] = "No valid firmware or source provided"
    return status


def list_available_tools() -> dict[str, bool]:
    """Quick health check of flash tools on the current machine."""
    tools = ["esptool", "esptool.py", "openocd", "nrfutil", "picotool", "pio", "platformio"]
    return {t: bool(_which(t)) for t in tools}
