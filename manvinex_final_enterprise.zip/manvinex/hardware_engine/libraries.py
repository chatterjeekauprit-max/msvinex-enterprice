"""
Library / dependency checker for Hardware Engine.

This module answers "what does this board/project need, what's already on the
host, and what's missing" for the two source-project flows Hardware Engine
supports (PlatformIO projects and Arduino sketches / arduino-cli). It never
guesses a library from arbitrary source analysis and never fetches or runs
unreviewed code on its own:

  - Reporting (check_*)  is always read-only and safe to call any time.
  - Installing (install_*) only ever shells out to the same trusted,
    already-installed toolchains (`pio`, `arduino-cli`) that a human chose to
    put on this host, and only runs when the caller passes confirm=True.
    There is no path in this module that downloads or executes a library
    that wasn't asked for by name, and no path that installs anything for a
    board whose project files the user hasn't already set up.

Why it stops there: auto-detecting whichever board happens to be plugged in
and silently pulling down "whatever library looks right" for it is a
supply-chain risk on physical hardware — exactly what Valrix's signed,
on-chain deployment flow exists to prevent elsewhere in this project. This
checker gives visibility and a one-call install for named dependencies
without reintroducing that risk.
"""

from __future__ import annotations

import configparser
import io
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any

from .boards import get_board

_INCLUDE_RE = re.compile(r'^\s*#include\s*[<"]([^">]+)[">]')

# Small, explicit header -> Arduino library-name map for common headers whose
# library name doesn't match the header (e.g. <Wire.h> is core, not a lib).
# This is a lookup table, not inference: unknown headers are reported as
# "unrecognized" rather than guessed at.
_KNOWN_HEADER_LIBS: dict[str, str] = {
    "WiFi.h": "WiFi (core)",
    "ArduinoJson.h": "ArduinoJson",
    "PubSubClient.h": "PubSubClient",
    "Adafruit_Sensor.h": "Adafruit Unified Sensor",
    "DHT.h": "DHT sensor library",
    "Servo.h": "Servo (core)",
    "SPI.h": "SPI (core)",
    "Wire.h": "Wire (core)",
    "FastLED.h": "FastLED",
    "ESPAsyncWebServer.h": "ESP Async WebServer",
    "AsyncTCP.h": "AsyncTCP",
    "NTPClient.h": "NTPClient",
    "TinyGPSPlus.h": "TinyGPSPlus",
}


def _which(cmd: str) -> str | None:
    return shutil.which(cmd)


def _run(cmd: list[str], timeout: int = 60) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)


# --------------------------------------------------------------------------- PlatformIO

def check_platformio_project(project_dir: str | Path) -> dict[str, Any]:
    """
    Read-only check of a PlatformIO project's lib_deps against what's already
    installed for it. Does not build or flash anything.
    """
    project_dir = Path(project_dir)
    ini_path = project_dir / "platformio.ini"
    result: dict[str, Any] = {
        "project_dir": str(project_dir),
        "pio_installed": bool(_which("pio") or _which("platformio")),
        "has_platformio_ini": ini_path.is_file(),
        "environments": {},
    }
    if not ini_path.is_file():
        result["error"] = "No platformio.ini in this project directory"
        return result

    cfg = configparser.ConfigParser()
    try:
        cfg.read_string(ini_path.read_text(encoding="utf-8"))
    except Exception as e:
        result["error"] = f"Could not parse platformio.ini: {e}"
        return result

    pio = _which("pio") or _which("platformio")
    installed_by_env: dict[str, set[str]] = {}
    if pio:
        try:
            listing = _run([pio, "pkg", "list", "-d", str(project_dir)], timeout=60)
            installed_by_env = _parse_pio_pkg_list(listing.stdout)
        except Exception:
            pass  # tool present but listing failed; fall back to "unknown" per lib

    for section in cfg.sections():
        if not section.startswith("env:"):
            continue
        env_name = section[len("env:"):]
        raw_deps = cfg.get(section, "lib_deps", fallback="")
        deps = [d.strip() for d in raw_deps.splitlines() if d.strip() and not d.strip().startswith(";")]
        board = cfg.get(section, "board", fallback=None)
        installed = installed_by_env.get(env_name, set())
        dep_status = []
        for dep in deps:
            name = _dep_display_name(dep)
            satisfied = any(name.lower() in i.lower() or i.lower() in name.lower() for i in installed)
            dep_status.append({"dep": dep, "name": name, "installed": satisfied if pio else None})
        result["environments"][env_name] = {
            "board": board,
            "lib_deps": dep_status,
            "missing": [d["dep"] for d in dep_status if d["installed"] is False],
        }

    return result


def _dep_display_name(dep: str) -> str:
    # lib_deps entries can be "Name", "Name@^1.2", "owner/Name@1.2", or a URL.
    dep = dep.split("@")[0].strip()
    if "/" in dep and not dep.startswith("http"):
        dep = dep.split("/")[-1]
    return dep


def _parse_pio_pkg_list(output: str) -> dict[str, set[str]]:
    """Best-effort parse of `pio pkg list` text output into {env: {lib names}}."""
    envs: dict[str, set[str]] = {}
    current_env = None
    for line in output.splitlines():
        env_match = re.match(r"^Environment\s+(\S+)", line.strip())
        if env_match:
            current_env = env_match.group(1)
            envs.setdefault(current_env, set())
            continue
        lib_match = re.match(r"^(?:-\s*)?([A-Za-z0-9_\-\.]+)\s*(?:@|$)", line.strip())
        if current_env and lib_match and "Library" not in line and "Package" not in line:
            envs[current_env].add(lib_match.group(1))
    return envs


def install_platformio_deps(project_dir: str | Path, confirm: bool = False) -> dict[str, Any]:
    """
    Install a reviewed project's own declared lib_deps via `pio pkg install`.
    Only installs what's already named in that project's platformio.ini —
    never adds or guesses a dependency. Requires confirm=True.
    """
    if not confirm:
        return {"ok": False, "error": "Refusing to install without confirm=True"}
    project_dir = Path(project_dir)
    if not (project_dir / "platformio.ini").is_file():
        return {"ok": False, "error": "No platformio.ini in this project directory"}
    pio = _which("pio") or _which("platformio")
    if not pio:
        return {"ok": False, "error": "PlatformIO is not installed on this host"}
    try:
        result = _run([pio, "pkg", "install", "-d", str(project_dir)], timeout=300)
        return {
            "ok": result.returncode == 0,
            "returncode": result.returncode,
            "stdout": (result.stdout or "")[-4000:],
            "stderr": (result.stderr or "")[-4000:],
        }
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "pio pkg install timed out after 300s"}


# --------------------------------------------------------------------------- Arduino / arduino-cli

def check_arduino_sketch(sketch_dir: str | Path) -> dict[str, Any]:
    """
    Read-only check: scan a sketch's #include lines, map recognized headers to
    library names, and (if arduino-cli is present) report which are already
    installed. Unrecognized headers are listed separately rather than guessed.
    """
    sketch_dir = Path(sketch_dir)
    result: dict[str, Any] = {
        "sketch_dir": str(sketch_dir),
        "arduino_cli_installed": bool(_which("arduino-cli")),
        "includes": [],
        "recognized_libraries": [],
        "unrecognized_includes": [],
    }
    if not sketch_dir.is_dir():
        result["error"] = f"Not a directory: {sketch_dir}"
        return result

    includes: set[str] = set()
    for ext in ("*.ino", "*.cpp", "*.h", "*.c"):
        for f in sketch_dir.rglob(ext):
            try:
                for line in f.read_text(encoding="utf-8", errors="ignore").splitlines():
                    m = _INCLUDE_RE.match(line)
                    if m:
                        includes.add(m.group(1))
            except Exception:
                continue
    result["includes"] = sorted(includes)

    installed_libs: set[str] = set()
    cli = _which("arduino-cli")
    if cli:
        try:
            listing = _run([cli, "lib", "list"], timeout=30)
            for line in listing.stdout.splitlines()[1:]:  # skip header row
                if line.strip():
                    installed_libs.add(line.split()[0].strip())
        except Exception:
            pass

    for header in sorted(includes):
        if header in _KNOWN_HEADER_LIBS:
            lib_name = _KNOWN_HEADER_LIBS[header]
            is_core = "(core)" in lib_name
            installed = None
            if cli and not is_core:
                bare = lib_name.split(" ")[0]
                installed = any(bare.lower() in i.lower() for i in installed_libs)
            result["recognized_libraries"].append({
                "header": header,
                "library": lib_name,
                "is_core": is_core,
                "installed": True if is_core else installed,
            })
        else:
            result["unrecognized_includes"].append(header)

    return result


def install_arduino_library(name: str, confirm: bool = False) -> dict[str, Any]:
    """
    Install exactly one named Arduino library via arduino-cli's own registry.
    The caller must supply the library name explicitly (e.g. from
    check_arduino_sketch's recognized_libraries) — this function does not
    search, infer, or fetch from arbitrary URLs. Requires confirm=True.
    """
    if not confirm:
        return {"ok": False, "error": "Refusing to install without confirm=True"}
    if not name or not name.strip():
        return {"ok": False, "error": "Library name required"}
    cli = _which("arduino-cli")
    if not cli:
        return {"ok": False, "error": "arduino-cli is not installed on this host"}
    try:
        result = _run([cli, "lib", "install", name.strip()], timeout=120)
        return {
            "ok": result.returncode == 0,
            "library": name.strip(),
            "returncode": result.returncode,
            "stdout": (result.stdout or "")[-4000:],
            "stderr": (result.stderr or "")[-4000:],
        }
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": f"arduino-cli lib install timed out for {name}"}


# --------------------------------------------------------------------------- combined report

def check_board_readiness(board_id: str, project_dir: str | Path | None = None) -> dict[str, Any]:
    """
    One-call summary for the Hardware tab: board info + host tool availability
    + (if a project_dir is given) its dependency status. Read-only.
    """
    board = get_board(board_id)
    if not board:
        return {"ok": False, "error": f"Unknown board: {board_id}"}

    report: dict[str, Any] = {
        "board": board,
        "flash_tool_installed": bool(_which(board.get("flash_tool", ""))),
        "pio_installed": bool(_which("pio") or _which("platformio")),
        "arduino_cli_installed": bool(_which("arduino-cli")),
    }
    if project_dir:
        p = Path(project_dir)
        if (p / "platformio.ini").is_file():
            report["platformio_project"] = check_platformio_project(p)
        elif any(p.glob("*.ino")):
            report["arduino_sketch"] = check_arduino_sketch(p)
        else:
            report["project_note"] = "project_dir has neither platformio.ini nor a .ino sketch"
    return report
