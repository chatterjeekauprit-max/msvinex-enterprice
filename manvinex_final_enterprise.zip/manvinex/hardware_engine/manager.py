"""
HardwareEngine – main facade used by Parent / Pipeline / Child.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from .boards import (
    BUILTIN_BOARDS,
    add_custom_board,
    get_board,
    list_boards,
)
from .flash import auto_deploy, flash_firmware, list_available_tools
from .libraries import (
    check_board_readiness,
    check_platformio_project,
    check_arduino_sketch,
    install_platformio_deps,
    install_arduino_library,
)


class HardwareEngine:
    """
    Central manager for Hardware Engine section.

    Typical usage from Pipeline / Parent UI:

        engine = HardwareEngine(data_dir="./data/hardware")
        boards = engine.list_boards()
        status = engine.allow(board_id="esp32-s3", firmware_or_source=path, port="/dev/ttyUSB0")
    """

    def __init__(self, data_dir: str | Path | None = None):
        self.data_dir = Path(data_dir or "./data/hardware")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.custom_path = self.data_dir / "custom_boards.json"
        self._load_custom()

    def _load_custom(self):
        if self.custom_path.is_file():
            try:
                data = json.loads(self.custom_path.read_text(encoding="utf-8"))
                for b in data:
                    try:
                        add_custom_board(b)
                    except ValueError:
                        pass  # already exists
            except Exception:
                pass

    def _save_custom(self):
        customs = [b for b in list_boards() if b not in BUILTIN_BOARDS]
        self.custom_path.write_text(json.dumps(customs, indent=2), encoding="utf-8")

    # ------------------------------------------------------------------ public API

    def list_boards(self) -> list[dict[str, Any]]:
        return list_boards(include_custom=True)

    def get_board(self, board_id: str) -> dict[str, Any] | None:
        return get_board(board_id)

    def add_board(self, board: dict[str, Any]) -> dict[str, Any]:
        """Add a custom board (persisted)."""
        b = add_custom_board(board)
        self._save_custom()
        return b

    def tools_status(self) -> dict[str, bool]:
        return list_available_tools()

    def allow(
        self,
        board_id: str,
        firmware_or_source: str | Path,
        port: str | None = None,
        build: bool = True,
    ) -> dict[str, Any]:
        """
        Main entry point for the Allow button.

        - Resolves the board
        - Optionally builds
        - Flashes directly to hardware
        - Returns full status so UI / pipeline can show progress
        """
        return auto_deploy(
            board_id=board_id,
            source_or_firmware=firmware_or_source,
            port=port,
            build=build,
            work_dir=self.data_dir / "build",
        )

    def flash(
        self,
        board_id: str,
        firmware_path: str | Path,
        port: str | None = None,
    ) -> dict[str, Any]:
        """Direct flash of a pre-built binary."""
        return flash_firmware(board_id, firmware_path, port=port)

    # ------------------------------------------------------------------ library / dependency checks

    def check_readiness(self, board_id: str, project_dir: str | Path | None = None) -> dict[str, Any]:
        """Read-only: board + toolchain + (optional) project dependency status."""
        return check_board_readiness(board_id, project_dir=project_dir)

    def check_libraries(self, project_dir: str | Path) -> dict[str, Any]:
        """Read-only: inspect a PlatformIO project or Arduino sketch directory."""
        p = Path(project_dir)
        if (p / "platformio.ini").is_file():
            return {"kind": "platformio", **check_platformio_project(p)}
        if any(p.glob("*.ino")):
            return {"kind": "arduino", **check_arduino_sketch(p)}
        return {"kind": "unknown", "error": "No platformio.ini or .ino sketch found in project_dir"}

    def install_libraries(
        self,
        project_dir: str | Path | None = None,
        arduino_library: str | None = None,
        confirm: bool = False,
    ) -> dict[str, Any]:
        """
        Install already-declared PlatformIO lib_deps for a reviewed project,
        or one explicitly named Arduino library. Never guesses a dependency;
        always requires confirm=True.
        """
        if arduino_library:
            return install_arduino_library(arduino_library, confirm=confirm)
        if project_dir:
            return install_platformio_deps(project_dir, confirm=confirm)
        return {"ok": False, "error": "Provide project_dir or arduino_library"}
