@echo off
setlocal
chcp 65001 >nul
set PYTHONUTF8=1

title Manvinex / Valrix Server Host

rem Find Python with cryptography
py -3.13 -c "import cryptography" >nul 2>nul
if %errorlevel% equ 0 (
    set PY_CMD=py -3.13
    goto :run
)

py -3 -c "import cryptography" >nul 2>nul
if %errorlevel% equ 0 (
    set PY_CMD=py -3
    goto :run
)

python -c "import cryptography" >nul 2>nul
if %errorlevel% equ 0 (
    set PY_CMD=python
    goto :run
)

where py >nul 2>nul
if %errorlevel% equ 0 (
    set PY_CMD=py -3.13
    goto :run
)
where python >nul 2>nul
if %errorlevel% equ 0 (
    set PY_CMD=python
    goto :run
)

echo [ERROR] Python was not found in PATH!
pause
exit /b 1

:run
%PY_CMD% "%~dp0host_server.py" %*
if %errorlevel% neq 0 (
    echo.
    echo Server stopped.
    pause
)
