"""
Manvinex / Valrix Server Host & Sharer.
Hosts the local repository as a live network server and generates direct 1-click shareable links
with embedded auto-login authentication tokens so anyone can access and use it immediately.
"""
from __future__ import annotations

import argparse
import os
import shutil
import socket
import subprocess
import sys
import time
import webbrowser

ROOT = os.path.dirname(os.path.abspath(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

# Ensure UTF-8 console output
for _stream in (sys.stdout, sys.stderr):
    if _stream and hasattr(_stream, "reconfigure"):
        try:
            _stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

from common.web import ClientError, http, http_json  # noqa: E402

DATA = os.path.join(ROOT, "data", "hosted_server")


def get_lan_ip() -> str:
    """Detect LAN / WiFi IP address of this machine."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def wait_service(url: str, timeout: int = 45):
    """Wait for service to answer HTTP requests."""
    start = time.time()
    while time.time() - start < timeout:
        try:
            http("GET", url, timeout=1.0)
            return
        except Exception:
            time.sleep(0.3)
    raise SystemExit(f"Timeout waiting for {url}. Check logs in {DATA}/")


def read_token(rel_path: str) -> str:
    p = os.path.join(DATA, rel_path)
    if os.path.exists(p):
        with open(p) as f:
            return f.read().strip()
    return ""


def main():
    p = argparse.ArgumentParser(description="Host Manvinex / Valrix Server and Share Links")
    p.add_argument("--base-port", type=int, default=8000, help="Pipeline Web UI port (default 8000)")
    p.add_argument("--fresh", action="store_true", help="Start fresh with clean database")
    p.add_argument("--no-browser", action="store_true", help="Do not open browser automatically")
    args = p.parse_args()

    base = args.base_port
    lan_ip = get_lan_ip()
    host = "0.0.0.0"

    pipe_url = f"http://{lan_ip}:{base}"
    parent_url = f"http://{lan_ip}:{base + 100}"
    status_url = f"http://{lan_ip}:{base + 200}"
    devnet_url = f"http://{lan_ip}:{base + 700}"

    local_pipe_url = f"http://127.0.0.1:{base}"
    local_parent_url = f"http://127.0.0.1:{base + 100}"
    local_status_url = f"http://127.0.0.1:{base + 200}"
    local_devnet_url = f"http://127.0.0.1:{base + 700}"

    if args.fresh and os.path.exists(DATA):
        try:
            shutil.rmtree(DATA)
        except Exception:
            pass
    os.makedirs(DATA, exist_ok=True)

    procs = []

    def spawn(name, *cmd_args):
        log_file = open(os.path.join(DATA, f"{name}.log"), "a", encoding="utf-8")
        proc = subprocess.Popen([sys.executable, "-m", *cmd_args], cwd=ROOT, stdout=log_file, stderr=subprocess.STDOUT)
        procs.append(proc)
        return proc

    ledger_args = ["--ledger", "devnet", "--devnet-url", local_devnet_url]

    print("================================================================")
    print(" MANVINEX / VALRIX SERVER HOSTING ENGINE")
    print("================================================================\n")
    print(" [1/4] Starting Private Blockchain DevNet Ledger on 0.0.0.0:8700...")
    spawn("devnet", "blockchain.devnet", "--host", host, "--port", str(base + 700), "--data", f"{DATA}/devnet")
    wait_service(local_devnet_url + "/health")

    print(" [2/4] Starting Parent Server Vault on 0.0.0.0:8100...")
    spawn("parent", "parent_server.server", "--host", host, "--port", str(base + 100),
          "--data", f"{DATA}/parent", *ledger_args)

    print(" [3/4] Starting Pipeline Orchestration Center on 0.0.0.0:8000...")
    spawn("pipeline", "pipeline.server", "--host", host, "--port", str(base), "--public-url", pipe_url,
          "--data", f"{DATA}/pipeline", *ledger_args)

    wait_service(local_parent_url + "/api/identity")
    wait_service(local_pipe_url + "/api/identity")

    parent_admin = read_token("parent/admin.token")
    pipeline_admin = read_token("pipeline/admin.token")

    H = lambda t: {"Authorization": f"Bearer {t}"}

    # Pre-seed sample projects & robotics adapters
    vaults = http_json("GET", local_parent_url + "/api/vaults", headers=H(parent_admin)).get("vaults", [])
    drone_pid = None
    if not vaults:
        print(" [4/4] Pre-seeding vaults with ready-to-deploy Drone & Robotics project...")
        # 1. Drone & Robotics Parent Server
        drone_pid = http_json("POST", local_parent_url + "/api/vaults",
                              json_body={"name": "Robotics & Drone Parent Server", "description": "Autonomous Edge Robotics"},
                              headers=H(parent_admin))["parent_id"]

        drone_dir = os.path.join(ROOT, "examples", "drone_robotics_patrol")
        if os.path.exists(drone_dir):
            http_json("POST", f"{local_parent_url}/api/vaults/{drone_pid}/import-path",
                      json_body={"path": drone_dir, "auto_bundle": True},
                      headers=H(parent_admin))
    else:
        drone_pid = vaults[0]["parent_id"]

    # Ensure parent server is connected to pipeline using local stable URL
    existing_parents = http_json("GET", f"{local_pipe_url}/api/parent-servers", headers=H(pipeline_admin)).get("parent_servers", [])
    has_active_parent = any(not p.get("error") for p in existing_parents)
    if not has_active_parent:
        http_json("POST", f"{local_pipe_url}/api/parent-servers",
                  json_body={"url": local_parent_url, "token": read_token("parent/pipeline.token"),
                             "label": "Robotics Parent Server"},
                  headers=H(pipeline_admin))

    # Pre-enroll child node
    child_info = http_json("GET", f"{local_pipe_url}/api/children", headers=H(pipeline_admin)).get("children", [])
    if not child_info:
        # Create enrollment
        enr = http_json("POST", f"{local_pipe_url}/api/children",
                        json_body={"child_id": "CHILD_ROBOT_01", "label": "Edge Autonomous Robot"},
                        headers=H(pipeline_admin))
        child_tok = enr["enroll_token"]
        subprocess.run([
            sys.executable, "-m", "child_server", "--data", f"{DATA}/child",
            "enroll", "--pipeline", local_pipe_url, "--child-id", "CHILD_ROBOT_01",
            "--token", child_tok, "--trust-parent", local_parent_url, "--ledger-override", "devnet",
            "--devnet-url", local_devnet_url
        ], cwd=ROOT, capture_output=True)
    else:
        # Ensure child config points to local pipeline and devnet URLs
        child_cfg_file = os.path.join(DATA, "child", "config.json")
        if os.path.exists(child_cfg_file):
            try:
                import json as _json
                with open(child_cfg_file, "r", encoding="utf-8") as f:
                    cfg = _json.load(f)
                cfg["pipeline_url"] = local_pipe_url
                if "ledger" in cfg and isinstance(cfg["ledger"], dict):
                    cfg["ledger"]["url"] = local_devnet_url
                with open(child_cfg_file, "w", encoding="utf-8") as f:
                    _json.dump(cfg, f, indent=2)
            except Exception:
                pass
        # Ensure child trusts local parent
        subprocess.run([
            sys.executable, "-m", "child_server", "--data", f"{DATA}/child",
            "trust-parent", local_parent_url, "--label", "Robotics Parent Server"
        ], cwd=ROOT, capture_output=True)

    # Start child background runner
    spawn("child", "child_server", "--data", f"{DATA}/child", "run", "--status-port", str(base + 200))
    time.sleep(1.0)

    # Direct 1-Click Login Links
    direct_pipe_lan = f"http://{lan_ip}:{base}/?token={pipeline_admin}"
    direct_parent_lan = f"http://{lan_ip}:{base + 100}/?token={parent_admin}"

    direct_pipe_local = f"http://127.0.0.1:{base}/?token={pipeline_admin}"
    direct_parent_local = f"http://127.0.0.1:{base + 100}/?token={parent_admin}"

    print("\n" + "=" * 64)
    print(" SERVER IS LIVE AND ACCESSIBLE FROM ANY DEVICE!")
    print("=" * 64)
    print("\n 1-CLICK SHAREABLE LINKS (Login Included — Send to anyone):")
    print(f"    * Pipeline Control Center : {direct_pipe_lan}")
    print(f"    * Parent Vault (iLovePDF) : {direct_parent_lan}\n")

    print(" LOCALHOST LINKS (On this computer):")
    print(f"    * Pipeline Dashboard      : {direct_pipe_local}")
    print(f"    * Parent Server Vault     : {direct_parent_local}\n")

    print(" INTERNET ACCESS (Optional / Outside your WiFi):")
    print("    To share with anyone anywhere in the world, run in another terminal:")
    print(f"    cloudflared tunnel --url http://127.0.0.1:{base}")
    print("    (Or use ngrok: ngrok http 8000)\n")

    print("-" * 64)
    print(" NOTE: Anyone connected to your WiFi or Hotspot can open the links")
    print("       from their mobile phone, tablet, or laptop immediately!")
    print(" Press Ctrl+C anytime to stop the server.")
    print("=" * 64 + "\n", flush=True)

    if not args.no_browser:
        try:
            webbrowser.open(direct_pipe_local)
        except Exception:
            pass

    try:
        while all(p.poll() is None for p in procs):
            time.sleep(1)
        print("A service stopped unexpectedly. Check logs in:", DATA)
    except KeyboardInterrupt:
        print("\nShutting down Manvinex server...")
    finally:
        for p in procs:
            try:
                p.terminate()
                p.wait(timeout=2)
            except Exception:
                try:
                    p.kill()
                except Exception:
                    pass
        print("All services stopped.")


if __name__ == "__main__":
    main()
