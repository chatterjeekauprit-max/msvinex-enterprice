#!/usr/bin/env bash
set -e
export PYTHONUTF8=1

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_CMD="python3"
if ! command -v "$PYTHON_CMD" &>/dev/null; then
    PYTHON_CMD="python"
fi

exec "$PYTHON_CMD" "$DIR/host_server.py" "$@"
