@echo off
rem Manvinex CLI Launcher (Alias for valrix.bat)
call "%~dp0valrix.bat" %*
exit /b %errorlevel%
