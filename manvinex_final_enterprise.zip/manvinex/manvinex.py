#!/usr/bin/env python3
"""
Manvinex Unified CLI Entry Point (Alias for valrix.py).
"""
import sys
from valrix.cli import main

if __name__ == "__main__":
    sys.exit(main())
