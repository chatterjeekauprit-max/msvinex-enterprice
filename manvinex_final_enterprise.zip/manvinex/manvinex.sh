#!/usr/bin/env bash
# Manvinex CLI Launcher (Alias for valrix.sh)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "$SCRIPT_DIR/valrix.sh" "$@"
