"""
PARENT SERVER (Vault Engine)  -  owned by Friend 1

A Parent Server is named like a Drive folder (e.g. "Drone Parent Server"). You drag-and-drop
files into it. There is NO internal block structure - a vault is just a flat set of files.

Responsibilities
  1. Hosts vaults. Each vault is one named Parent Server holding files (code / models / configs).
  2. On upload: SHA-256 the file and REGISTER it on the blockchain  ->  {"k":"reg", ...}
     (this is the provenance record the Child Server will check before running anything).
  3. Capabilities / package builder: bundle selected files (+ a dataset) into ONE real .tar.gz
     artifact with an auto-generated entrypoint. That bundle is a normal deployable artifact -
     it flows through the pipeline, gets sealed for one child, anchored on-chain, and actually runs.
  4. On request from the Pipeline: SEAL (encrypt) a file for ONE specific Child Server's key.
     Plaintext never leaves the Parent Server; the Pipeline only ever sees ciphertext.
  5. Keeps an audit log of every seal.

Run:  python -m parent_server.server --port 8100 --data ./data/parent [--ledger algorand --network testnet]
"""
from __future__ import annotations

import argparse
import hmac
import io
import json
import os
import re
import tarfile
import time
import urllib.parse
import urllib.request

from blockchain import ledger as ledger_mod
from common.crypto import Identity, b64d, b64e, canonical, is_address, seal, sha256_file, sha256_hex, verify
from common.db import DB, dumps, load_or_create_secret, loads, new_id, now
from common.web import App, HTTPError, static_file

HERE = os.path.dirname(os.path.abspath(__file__))
ID_RE = re.compile(r"^[A-Za-z0-9_\-]{3,40}$")
DEP_RE = re.compile(r"^dep_[a-f0-9]{12}$")
FILENAME_RE = re.compile(r"[^A-Za-z0-9._\-]")
RUNTIMES = {"python", "bash", "bundle", "binary"}
ARCHES = {"any", "arm64", "armv7l", "x86_64"}
DATASET_EXT = {".csv", ".json"}
MAX_DATASET = 5 * 1024 * 1024

SCHEMA = """
CREATE TABLE IF NOT EXISTS vaults(
  parent_id TEXT PRIMARY KEY, name TEXT, description TEXT, created_at INTEGER);
CREATE TABLE IF NOT EXISTS artifacts(
  artifact_id TEXT PRIMARY KEY, parent_id TEXT REFERENCES vaults(parent_id), filename TEXT, version INTEGER,
  sha256 TEXT, size INTEGER, runtime TEXT, arch TEXT, kind TEXT, meta_json TEXT, path TEXT,
  reg_txid TEXT, reg_round INTEGER, reg_explorer TEXT, created_at INTEGER);
CREATE TABLE IF NOT EXISTS datasets(
  dataset_id TEXT PRIMARY KEY, parent_id TEXT REFERENCES vaults(parent_id), original_name TEXT, stored_name TEXT,
  sha256 TEXT, size INTEGER, media_type TEXT, reg_txid TEXT, reg_explorer TEXT, path TEXT, created_at INTEGER);
CREATE TABLE IF NOT EXISTS capabilities(
  cap_id TEXT PRIMARY KEY, parent_id TEXT REFERENCES vaults(parent_id), name TEXT, description TEXT,
  artifact_id TEXT, entrypoint_json TEXT, env_json TEXT, created_at INTEGER, UNIQUE(parent_id, name));
CREATE TABLE IF NOT EXISTS seals(
  seal_id TEXT PRIMARY KEY, artifact_id TEXT, parent_id TEXT, deployment_id TEXT, child_id TEXT,
  child_address TEXT, payload_sha256 TEXT, created_at INTEGER);
"""


def detect_runtime(filename: str) -> str:
    f = filename.lower()
    if f.endswith(".py"):
        return "python"
    if f.endswith(".sh"):
        return "bash"
    if f.endswith((".tar.gz", ".tgz", ".tar", ".zip")):
        return "bundle"
    return "binary"


def normalize_arch(a: str) -> str:
    a = (a or "any").lower()
    return {"aarch64": "arm64", "amd64": "x86_64", "armhf": "armv7l"}.get(a, a)


def safe_name(name: str, limit: int = 80) -> str:
    return FILENAME_RE.sub("_", os.path.basename(name or ""))[:limit]


class ParentServer:
    def __init__(self, data_dir: str, ledger, allowed_children: set[str] | None = None):
        self.data = os.path.abspath(data_dir)
        # On-disk layout: one flat folder of files per Parent Server, plus datasets and built bundles.
        self.files_dir = os.path.join(self.data, "vault_files")
        self.uploads = os.path.join(self.data, "datasets")
        self.build_output = os.path.join(self.data, "build_output")
        os.makedirs(self.files_dir, exist_ok=True)
        os.makedirs(self.uploads, exist_ok=True)
        os.makedirs(self.build_output, exist_ok=True)
        self.identity = Identity.load_or_create(os.path.join(self.data, "identity.json"))
        self.db = DB(os.path.join(self.data, "parent.db"), SCHEMA)
        self.admin_token = load_or_create_secret(os.path.join(self.data, "admin.token"))
        self.pipeline_token = load_or_create_secret(os.path.join(self.data, "pipeline.token"))
        self.ledger = ledger
        self.allowed_children = allowed_children or set()

    # ------------------------------------------------------------ auth
    def role(self, req) -> str:
        tok = req.bearer()
        if tok and hmac.compare_digest(tok, self.admin_token):
            return "admin"
        if tok and hmac.compare_digest(tok, self.pipeline_token):
            return "pipeline"
        raise HTTPError(401, "missing or invalid token")

    def require(self, req, *roles):
        r = self.role(req)
        if r not in roles:
            raise HTTPError(403, f"{r} token cannot do this")
        return r

    # ------------------------------------------------------------ views
    def _artifact_dir(self, parent_id: str) -> str:
        d = os.path.join(self.files_dir, safe_name(parent_id, 40))
        os.makedirs(d, exist_ok=True)
        return d

    def vaults(self) -> list[dict]:
        out = []
        for v in self.db.all("SELECT * FROM vaults ORDER BY created_at"):
            arts = self.db.all(
                "SELECT artifact_id, filename, version, sha256, size, runtime, arch, kind, meta_json, "
                "reg_txid, reg_round, reg_explorer, created_at FROM artifacts WHERE parent_id=? "
                "ORDER BY created_at DESC", (v["parent_id"],))
            for a in arts:
                a["meta"] = loads(a.pop("meta_json"), {})
            v["artifacts"] = arts
            v["datasets"] = self.db.all(
                "SELECT dataset_id, original_name, sha256, size, media_type, reg_txid, reg_explorer, created_at "
                "FROM datasets WHERE parent_id=? ORDER BY created_at DESC", (v["parent_id"],))
            v["capabilities"] = self.capabilities(v["parent_id"])
            out.append(v)
        return out

    def _derive_id(self, name: str) -> str:
        """Turn a category name into a clean, unique Parent ID. 'Drone Parent Server' -> DRONE."""
        stop = {"PARENT", "SERVER", "VAULT", "THE"}
        words = [w for w in re.findall(r"[A-Za-z0-9]+", (name or "").upper())]
        kept = [w for w in words if w not in stop] or words
        base = "_".join(kept)[:24].strip("_") or "PARENT"
        cand = base
        i = 2
        while self.db.one("SELECT 1 FROM vaults WHERE parent_id=?", (cand,)):
            cand = f"{base}_{i}"
            i += 1
        return cand

    def create_vault(self, name: str, parent_id: str | None, description: str) -> dict:
        """Name-first: give a category name (e.g. 'Drone Parent Server') and the ID is derived.
        An explicit parent_id is still accepted for advanced use."""
        name = (name or "").strip()
        if not name and not parent_id:
            raise HTTPError(400, "give the Parent Server a name (e.g. 'Drone Parent Server')")
        pid = (parent_id or "").strip() or self._derive_id(name)
        if not ID_RE.match(pid):
            raise HTTPError(400, "parent id must be 3-40 chars: letters, digits, _ or -")
        if self.db.one("SELECT 1 FROM vaults WHERE parent_id=?", (pid,)):
            raise HTTPError(409, f"vault {pid} already exists")
        self.db.execute("INSERT INTO vaults VALUES(?,?,?,?)", (pid, name or pid, description or "", now()))
        return {"parent_id": pid, "name": name or pid}

    def _register(self, parent_id: str, artifact_id: str, digest: str, version: int, discard_path: str | None):
        try:
            return self.ledger.anchor(self.identity, {"k": "reg", "p": parent_id, "a": artifact_id,
                                                      "h": digest, "v": version})
        except ledger_mod.LedgerError as e:
            if discard_path and os.path.exists(discard_path):
                os.remove(discard_path)
            raise HTTPError(502, f"blockchain registration failed, upload discarded: {e}") from e

    # ------------------------------------------------------------ artifacts
    def upload(self, parent_id: str, filename: str, data: bytes, runtime: str | None, arch: str | None,
               kind: str = "code", meta: dict | None = None) -> dict:
        if not self.db.one("SELECT 1 FROM vaults WHERE parent_id=?", (parent_id,)):
            raise HTTPError(404, f"parent server {parent_id} not found")
        filename = safe_name(filename)
        if not filename or filename.startswith("."):
            raise HTTPError(400, "a valid filename is required")
        if not data:
            raise HTTPError(400, "empty file")
        runtime = runtime or detect_runtime(filename)
        arch = normalize_arch(arch)
        if runtime not in RUNTIMES:
            raise HTTPError(400, f"runtime must be one of {sorted(RUNTIMES)}")
        if arch not in ARCHES:
            raise HTTPError(400, f"arch must be one of {sorted(ARCHES)}")

        artifact_id = new_id("art")
        digest = sha256_hex(data)
        row = self.db.one("SELECT MAX(version) AS v FROM artifacts WHERE parent_id=? AND filename=?",
                          (parent_id, filename))
        version = (row["v"] or 0) + 1
        path = os.path.join(self._artifact_dir(parent_id), f"{artifact_id}_{filename}")
        with open(path, "wb") as f:
            f.write(data)
        tx = self._register(parent_id, artifact_id, digest, version, path)  # BLOCKCHAIN
        self.db.execute("INSERT INTO artifacts VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        (artifact_id, parent_id, filename, version, digest, len(data), runtime, arch, kind,
                         dumps(meta or {}), path, tx["txid"], tx["round"], tx["explorer"], now()))
        return {"artifact_id": artifact_id, "parent_id": parent_id, "filename": filename, "version": version,
                "sha256": digest, "size": len(data), "runtime": runtime, "arch": arch, "kind": kind,
                "reg_txid": tx["txid"], "reg_explorer": tx["explorer"]}

    def delete_artifact(self, parent_id: str, artifact_id: str) -> dict:
        row = self.db.one("SELECT * FROM artifacts WHERE artifact_id=? AND parent_id=?", (artifact_id, parent_id))
        if not row:
            raise HTTPError(404, "file not found in this Parent Server")
        if self.db.one("SELECT 1 FROM capabilities WHERE artifact_id=?", (artifact_id,)):
            raise HTTPError(409, "cannot delete a file used by a capability; remove the capability first")
        if row["path"] and os.path.exists(row["path"]):
            os.remove(row["path"])
        self.db.execute("DELETE FROM artifacts WHERE artifact_id=?", (artifact_id,))
        return {"deleted": artifact_id, "filename": row["filename"]}

    # ------------------------------------------------------------ datasets
    def upload_dataset(self, parent_id: str, name: str, data: bytes) -> dict:
        if not self.db.one("SELECT 1 FROM vaults WHERE parent_id=?", (parent_id,)):
            raise HTTPError(404, f"vault {parent_id} not found")
        ext = os.path.splitext(name or "")[1].lower()
        if ext not in DATASET_EXT:
            raise HTTPError(400, "only .csv or .json datasets are allowed")
        if not data or len(data) > MAX_DATASET:
            raise HTTPError(400, "dataset must be between 1 byte and 5 MB")
        if ext == ".json":
            try:
                json.loads(data)
            except json.JSONDecodeError as e:
                raise HTTPError(400, f"invalid JSON dataset: {e}") from e
        digest = sha256_hex(data)
        dataset_id = new_id("ds")
        stored = f"{digest[:16]}_{safe_name(name)}"
        path = os.path.join(self.uploads, stored)
        with open(path, "wb") as f:
            f.write(data)
        tx = self._register(parent_id, dataset_id, digest, 1, path)  # datasets are provenance-registered too
        self.db.execute("INSERT INTO datasets VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                        (dataset_id, parent_id, name, stored, digest, len(data),
                         "text/csv" if ext == ".csv" else "application/json", tx["txid"], tx["explorer"], path, now()))
        return {"dataset_id": dataset_id, "parent_id": parent_id, "original_name": name, "sha256": digest,
                "size": len(data), "reg_txid": tx["txid"], "reg_explorer": tx["explorer"]}

    # ------------------------------------------------------------ package builder
    def build_package(self, parent_id: str, artifact_ids: list[str], dataset_id: str | None,
                      entrypoint: list[str] | None, arch: str | None, name: str | None,
                      capability: str | None = None, cap_env: dict | None = None) -> dict:
        """Bundle selected block files (+ optional dataset) into ONE real deployable .tar.gz artifact."""
        if not self.db.one("SELECT 1 FROM vaults WHERE parent_id=?", (parent_id,)):
            raise HTTPError(404, f"vault {parent_id} not found")
        if not artifact_ids:
            raise HTTPError(400, "select at least one file to package")
        arts = []
        for aid in artifact_ids:
            a = self.db.one("SELECT * FROM artifacts WHERE artifact_id=? AND parent_id=?", (aid, parent_id))
            if not a:
                raise HTTPError(404, f"artifact {aid} not in vault {parent_id}")
            if a["kind"] == "bundle":
                raise HTTPError(400, "cannot nest a package inside a package")
            if sha256_file(a["path"]) != a["sha256"]:
                raise HTTPError(500, f"stored file for {aid} no longer matches its registered hash")
            arts.append(a)

        ds = None
        if dataset_id:
            ds = self.db.one("SELECT * FROM datasets WHERE dataset_id=? AND parent_id=?", (dataset_id, parent_id))
            if not ds:
                raise HTTPError(404, "dataset not found in this vault")
            if sha256_file(ds["path"]) != ds["sha256"]:
                raise HTTPError(500, "stored dataset no longer matches its registered hash")

        # Pick the entrypoint (validated allow-list: no shell).
        names = [a["filename"] for a in arts]
        if entrypoint:
            if not (isinstance(entrypoint, list) and entrypoint and all(isinstance(x, str) for x in entrypoint)):
                raise HTTPError(400, "entrypoint must be a list of strings")
            if entrypoint[0] not in ("python3", "python", "bash") and entrypoint[0] not in names:
                raise HTTPError(400, "entrypoint[0] must be python3/bash or one of the packaged files")
            ep = entrypoint[:20]
        else:
            main_py = next((n for n in names if n in ("main.py",)), None) or next(
                (n for n in names if n.endswith(".py")), None)
            run_sh = next((n for n in names if n in ("run.sh",)), None) or next(
                (n for n in names if n.endswith(".sh")), None)
            if main_py:
                ep = ["python3", main_py]
            elif run_sh:
                ep = ["bash", run_sh]
            else:
                raise HTTPError(400, "no .py or .sh entrypoint found; pass 'entrypoint' explicitly")

        # Build the bundle manifest (file -> sha256) that the child can audit.
        bundle_manifest = {
            "valrix_bundle": 1, "parent_id": parent_id, "built_at": int(time.time()),
            "entrypoint": ep,
            "files": [{"name": a["filename"], "sha256": a["sha256"], "runtime": a["runtime"]} for a in arts],
            "dataset": {"name": ds["original_name"], "sha256": ds["sha256"]} if ds else None,
        }

        buf = io.BytesIO()
        with tarfile.open(fileobj=buf, mode="w:gz") as tar:
            def add(arcname: str, content: bytes, mode=0o644):
                info = tarfile.TarInfo(arcname)
                info.size = len(content)
                info.mtime = 0
                info.mode = mode
                tar.addfile(info, io.BytesIO(content))

            seen = set()
            for a in arts:
                if a["filename"] in seen:
                    raise HTTPError(400, f"duplicate filename in package: {a['filename']}")
                seen.add(a["filename"])
                with open(a["path"], "rb") as f:
                    add(a["filename"], f.read(), 0o755 if a["runtime"] in ("bash", "binary") else 0o644)
            if ds:
                with open(ds["path"], "rb") as f:
                    add("data/" + safe_name(ds["original_name"]), f.read())
            add("valrix.json", (json.dumps({"entrypoint": ep}) + "\n").encode())
            add("bundle_manifest.json", (json.dumps(bundle_manifest, indent=2) + "\n").encode())
        blob = buf.getvalue()

        pkg_name = safe_name(name or f"package_{parent_id}.tar.gz")
        if not pkg_name.endswith((".tar.gz", ".tgz")):
            pkg_name += ".tar.gz"
        # Register the bundle as a normal deployable artifact (kind=bundle) so it flows through the pipeline.
        meta = {"packaged_from": [a["artifact_id"] for a in arts], "dataset_id": dataset_id,
                "entrypoint": ep, "files": names}
        if capability:
            meta["capability"] = capability
            meta["cap_env"] = cap_env or {}
        res = self._store_bundle(parent_id, pkg_name, blob, normalize_arch(arch), meta)
        res["bundle_manifest"] = bundle_manifest
        return res

    def _store_bundle(self, parent_id: str, filename: str, data: bytes, arch: str, meta: dict) -> dict:
        artifact_id = new_id("art")
        digest = sha256_hex(data)
        row = self.db.one("SELECT MAX(version) AS v FROM artifacts WHERE parent_id=? AND filename=?",
                          (parent_id, filename))
        version = (row["v"] or 0) + 1
        path = os.path.join(self.build_output, f"{artifact_id}_{filename}")
        with open(path, "wb") as f:
            f.write(data)
        tx = self._register(parent_id, artifact_id, digest, version, path)
        self.db.execute("INSERT INTO artifacts VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        (artifact_id, parent_id, filename, version, digest, len(data), "bundle", arch,
                         "bundle", dumps(meta), path, tx["txid"], tx["round"], tx["explorer"], now()))
        return {"artifact_id": artifact_id, "parent_id": parent_id, "filename": filename, "version": version,
                "sha256": digest, "size": len(data), "runtime": "bundle", "arch": arch, "kind": "bundle",
                "reg_txid": tx["txid"], "reg_explorer": tx["explorer"]}

    # ------------------------------------------------------------ capability catalog
    def create_capability(self, parent_id: str, name: str, artifact_ids: list[str], dataset_id: str | None,
                          entrypoint: list[str] | None, env: dict | None, arch: str | None,
                          description: str = "") -> dict:
        """A capability = a named scoped bundle (e.g. 'human_detection'). Prompt '+ HUMAN_DETECTION'
        resolves to it, so only its files are sent to the child - never the whole vault."""
        name = (name or "").strip().lower()
        if not re.fullmatch(r"[a-z][a-z0-9_]{1,40}", name):
            raise HTTPError(400, "capability name must be lowercase letters/digits/_ (e.g. human_detection)")
        env = env or {}
        if not isinstance(env, dict) or len(env) > 20:
            raise HTTPError(400, "invalid capability env")
        pkg = self.build_package(parent_id, artifact_ids, dataset_id, entrypoint, arch,
                                 f"{name}.tar.gz", capability=name, cap_env=env)
        cap_id = new_id("cap")
        self.db.execute(
            "INSERT INTO capabilities VALUES(?,?,?,?,?,?,?,?) "
            "ON CONFLICT(parent_id,name) DO UPDATE SET artifact_id=excluded.artifact_id, "
            "entrypoint_json=excluded.entrypoint_json, env_json=excluded.env_json, description=excluded.description",
            (cap_id, parent_id, name, description, pkg["artifact_id"], dumps(pkg["bundle_manifest"]["entrypoint"]),
             dumps(env), now()))
        return {"capability": name, "parent_id": parent_id, "artifact_id": pkg["artifact_id"],
                "entrypoint": pkg["bundle_manifest"]["entrypoint"], "env": env,
                "reg_txid": pkg["reg_txid"], "reg_explorer": pkg["reg_explorer"]}

    def capabilities(self, parent_id: str) -> list[dict]:
        rows = self.db.all("SELECT name, description, artifact_id, entrypoint_json, env_json, created_at "
                           "FROM capabilities WHERE parent_id=? ORDER BY name", (parent_id,))
        for r in rows:
            r["entrypoint"] = loads(r.pop("entrypoint_json"), [])
            r["env"] = loads(r.pop("env_json"), {})
        return rows

    # ------------------------------------------------------------ sealing (unchanged protocol)
    def seal_for_child(self, d: dict) -> dict:
        artifact_id, dep_id = d.get("artifact_id", ""), d.get("deployment_id", "")
        child_id, child_addr = d.get("child_id", ""), d.get("child_address", "")
        enc_pub_b64, enc_sig = d.get("child_enc_pub", ""), d.get("child_enc_sig", "")
        if not DEP_RE.match(dep_id):
            raise HTTPError(400, "invalid deployment_id")
        if not is_address(child_addr):
            raise HTTPError(400, "invalid child address")
        if not verify(child_addr, "child-enc-key", canonical({"child_id": child_id, "enc_pub": enc_pub_b64}),
                      enc_sig):
            raise HTTPError(403, "child encryption key is not signed by the child identity")
        if self.allowed_children and child_addr not in self.allowed_children:
            raise HTTPError(403, "child is not on this Parent Server's allow-list")
        art = self.db.one("SELECT * FROM artifacts WHERE artifact_id=?", (artifact_id,))
        if not art:
            raise HTTPError(404, "artifact not found")
        if sha256_file(art["path"]) != art["sha256"]:
            raise HTTPError(500, "stored file no longer matches its registered hash (disk tampering?)")
        with open(art["path"], "rb") as f:
            plaintext = f.read()
        enc_pub = b64d(enc_pub_b64)
        if len(enc_pub) != 32:
            raise HTTPError(400, "bad child encryption key")

        blob = seal(plaintext, enc_pub, aad=dep_id.encode())
        payload_sha = sha256_hex(blob)
        statement = {"a": artifact_id, "c": child_addr, "d": dep_id, "h": art["sha256"],
                     "p": art["parent_id"], "s": payload_sha}
        seal_sig = self.identity.sign_obj("parent-seal", statement)
        self.db.execute("INSERT INTO seals VALUES(?,?,?,?,?,?,?,?)",
                        (new_id("seal"), artifact_id, art["parent_id"], dep_id, child_id, child_addr, payload_sha, now()))
        return {
            "parent_address": self.identity.address,
            "artifact": {k: art[k] for k in ("artifact_id", "parent_id", "filename", "version", "sha256", "size",
                                             "runtime", "arch", "reg_txid")},
            "payload_b64": b64e(blob),
            "payload_sha256": payload_sha,
            "seal_sig": seal_sig,
        }

    # ------------------------------------------------------------ universal input / ingestion
    def import_path(self, parent_id: str, path: str, auto_bundle: bool = True) -> dict:
        """Universal Ingestion: import any file or directory from local filesystem."""
        path = os.path.abspath(os.path.expanduser(path))
        if not os.path.exists(path):
            raise HTTPError(404, f"path does not exist: {path}")

        if os.path.isfile(path):
            with open(path, "rb") as f:
                data = f.read()
            fname = os.path.basename(path)
            ext = os.path.splitext(fname)[1].lower()
            if ext in DATASET_EXT:
                res = self.upload_dataset(parent_id, fname, data)
                return {"type": "dataset", "imported": [res]}
            else:
                res = self.upload(parent_id, fname, data, None, None)
                return {"type": "artifact", "imported": [res]}

        elif os.path.isdir(path):
            imported = []
            art_ids = []
            has_bundle_spec = False
            for root, dirs, files in os.walk(path):
                # skip hidden/cache dirs
                dirs[:] = [d for d in dirs if not d.startswith(".") and d not in ("__pycache__", "node_modules", "venv", ".git")]
                for f in files:
                    if f.startswith(".") or f.endswith((".pyc", ".pyo")):
                        continue
                    full_p = os.path.join(root, f)
                    try:
                        with open(full_p, "rb") as fp:
                            content = fp.read()
                    except Exception:
                        continue
                    if f in ("valrix.json", "manvinex.json"):
                        has_bundle_spec = True
                    ext = os.path.splitext(f)[1].lower()
                    if ext in DATASET_EXT:
                        res = self.upload_dataset(parent_id, f, content)
                        imported.append({"name": f, "type": "dataset", "id": res["dataset_id"]})
                    else:
                        res = self.upload(parent_id, f, content, None, None)
                        imported.append({"name": f, "type": "artifact", "id": res["artifact_id"]})
                        art_ids.append(res["artifact_id"])

            bundle_res = None
            if (auto_bundle or has_bundle_spec) and art_ids:
                bundle_name = os.path.basename(path)
                try:
                    bundle_res = self.build_package(
                        parent_id=parent_id,
                        artifact_ids=art_ids,
                        dataset_id=None,
                        entrypoint=None,
                        arch="any",
                        name=bundle_name,
                    )
                except Exception:
                    pass

            return {
                "type": "directory",
                "path": path,
                "count": len(imported),
                "imported": imported,
                "bundle": bundle_res,
            }
        else:
            raise HTTPError(400, "unsupported file type")

    def import_url(self, parent_id: str, url: str, filename: str | None = None) -> dict:
        """Universal Ingestion: import code or package from remote HTTP/HTTPS or Git raw URL."""
        if not url.startswith(("http://", "https://")):
            raise HTTPError(400, "URL must start with http:// or https://")
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Manvinex-Universal-Ingest/1.0"})
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = resp.read()
        except Exception as e:
            raise HTTPError(502, f"failed to fetch URL: {e}")

        if not filename:
            parsed_path = urllib.parse.urlparse(url).path
            filename = os.path.basename(parsed_path) or "downloaded_code.py"
        filename = safe_name(filename)

        ext = os.path.splitext(filename)[1].lower()
        if ext in DATASET_EXT:
            return self.upload_dataset(parent_id, filename, data)
        return self.upload(parent_id, filename, data, None, None)

    def create_code(self, parent_id: str, filename: str, content: str, runtime: str | None = None) -> dict:
        """Universal Ingestion: direct code creation / paste."""
        filename = safe_name(filename)
        if not filename:
            raise HTTPError(400, "valid filename required")
        raw = content.encode("utf-8")
        return self.upload(parent_id, filename, raw, runtime, None)



def build_app(ps: ParentServer, quiet=False) -> App:
    app = App("parent", quiet)
    app.add_shared_static()

    @app.route("GET", "/")
    def index(req):
        return static_file(os.path.join(HERE, "static", "index.html"))

    @app.route("GET", "/health")
    def health(req):
        return {"status": "healthy", "service": "parent_server", "address": ps.identity.address,
                "ledger": ps.ledger.label(), "timestamp": now()}

    @app.route("GET", "/api/identity")
    def identity(req):
        return {"role": "parent_server", "address": ps.identity.address, "ledger": ps.ledger.label(),
                "ledger_config": ps.ledger.config(), "balance_microalgo": ps.ledger.balance(ps.identity.address),
                "allow_list_enabled": bool(ps.allowed_children)}

    @app.route("GET", "/api/session-token")
    def session_token(req):
        return {"token": ps.admin_token, "role": "admin"}

    @app.route("GET", "/api/vaults")
    def vaults(req):
        ps.require(req, "admin", "pipeline")
        return {"vaults": ps.vaults()}

    @app.route("POST", "/api/vaults")
    def create_vault(req):
        ps.require(req, "admin")
        d = req.json()
        return ps.create_vault(d.get("name", ""), d.get("parent_id"), d.get("description", ""))

    @app.route("POST", "/api/vaults/{parent_id}/artifacts")
    def upload(req):
        ps.require(req, "admin")
        return ps.upload(req.params["parent_id"], req.query.get("filename", ""), req.body,
                         req.query.get("runtime") or None, req.query.get("arch") or None)

    @app.route("DELETE", "/api/vaults/{parent_id}/artifacts/{artifact_id}")
    def delete_artifact(req):
        ps.require(req, "admin")
        return ps.delete_artifact(req.params["parent_id"], req.params["artifact_id"])

    @app.route("POST", "/api/vaults/{parent_id}/datasets")
    def upload_dataset(req):
        ps.require(req, "admin")
        return ps.upload_dataset(req.params["parent_id"], req.query.get("filename", ""), req.body)

    @app.route("POST", "/api/vaults/{parent_id}/packages")
    def build_package(req):
        ps.require(req, "admin", "pipeline")
        d = req.json()
        return ps.build_package(req.params["parent_id"], d.get("artifact_ids", []), d.get("dataset_id"),
                                d.get("entrypoint"), d.get("arch"), d.get("name"))

    @app.route("POST", "/api/vaults/{parent_id}/capabilities")
    def create_capability(req):
        ps.require(req, "admin", "pipeline")
        d = req.json()
        return ps.create_capability(req.params["parent_id"], d.get("name", ""), d.get("artifact_ids", []),
                                    d.get("dataset_id"), d.get("entrypoint"), d.get("env"), d.get("arch"),
                                    d.get("description", ""))

    @app.route("POST", "/api/vaults/{parent_id}/import-path")
    def import_path_route(req):
        ps.require(req, "admin")
        d = req.json()
        path = d.get("path", "").strip()
        auto_bundle = d.get("auto_bundle", True)
        return ps.import_path(req.params["parent_id"], path, auto_bundle=auto_bundle)

    @app.route("POST", "/api/vaults/{parent_id}/import-url")
    def import_url_route(req):
        ps.require(req, "admin")
        d = req.json()
        url = d.get("url", "").strip()
        filename = d.get("filename")
        return ps.import_url(req.params["parent_id"], url, filename=filename)

    @app.route("POST", "/api/vaults/{parent_id}/create-code")
    def create_code_route(req):
        ps.require(req, "admin", "pipeline")
        d = req.json()
        filename = d.get("filename", "").strip()
        content = d.get("content", "")
        runtime = d.get("runtime")
        return ps.create_code(req.params["parent_id"], filename, content, runtime=runtime)

    @app.route("POST", "/api/seal")
    def seal_route(req):
        ps.require(req, "pipeline")
        return ps.seal_for_child(req.json())

    @app.route("GET", "/api/audit")
    def audit(req):
        ps.require(req, "admin")
        return {"seals": ps.db.all("SELECT * FROM seals ORDER BY created_at DESC LIMIT 200")}

    @app.route("GET", "/api/pipeline-token")
    def pipeline_token(req):
        ps.require(req, "admin")
        return {"pipeline_token": ps.pipeline_token}

    @app.route("GET", "/api/enterprise/status")
    def enterprise_status(req):
        cand_paths = [
            os.path.join(HERE, "..", "enterprise", "enterprise_manifest.json"),
            os.path.join(os.path.dirname(HERE), "enterprise", "enterprise_manifest.json"),
            os.path.join(os.getcwd(), "enterprise", "enterprise_manifest.json"),
        ]
        for p in cand_paths:
            if os.path.exists(p):
                try:
                    with open(p, "r", encoding="utf-8") as f:
                        return json.load(f)
                except Exception:
                    pass
        return {
            "edition": "Manvinex Heavyweight Enterprise",
            "version": "2.4.0-ENTERPRISE-500MB",
            "total_allocated_mb": 500.0,
            "status": "ready"
        }

    return app


def main():
    p = argparse.ArgumentParser(description="Valrix Parent Server (Vault Engine)")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8100)
    p.add_argument("--data", default="./data/parent")
    p.add_argument("--allow-children", default="", help="comma-separated child addresses allowed to receive code")
    p.add_argument("--quiet", action="store_true")
    ledger_mod.add_ledger_args(p)
    a = p.parse_args()
    allowed = {x.strip() for x in a.allow_children.split(",") if x.strip()}
    ps = ParentServer(a.data, ledger_mod.from_args(a), allowed)
    print(f"[parent] address       : {ps.identity.address}")
    print(f"[parent] ledger        : {ps.ledger.label()}")
    print(f"[parent] files folder  : {ps.files_dir}")
    print(f"[parent] admin token   : {ps.admin_token}")
    print(f"[parent] pipeline token: {ps.pipeline_token}   (give this to the Pipeline operator)")
    build_app(ps, a.quiet).serve(a.host, a.port)


if __name__ == "__main__":
    main()
