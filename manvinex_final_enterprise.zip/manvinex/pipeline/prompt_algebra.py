"""
Prompt Algebra: a compact, user-friendly prompt syntax that sits on top of the plain-language
prompt engine. It stays fully allow-listed - nothing here is ever executed as a shell command;
recognized tokens only toggle plan fields and set environment strings the deployed app can read.

Operators
  + FEATURE     include / turn on a feature or module
  - FEATURE     exclude / turn off a feature or module
  -> TARGET     route to a Child (CHILD_… or CID_…); source PARENT_…/PID_… optional
  * N           scale hint: intended for N child nodes (informational; deploy per child to replicate)

Examples
  + METROLOGY_ENGINE - DEBUG_LOGS -> CHILD_RPI_01
  PARENT_01 + ENFORCE_MASKING * 3 -> CHILD_RPI_01
  run as a service + METROLOGY_ENGINE        (mix with plain language freely)

Known features get a clean effect; anything else is passed through safely as a FEATURES string.
"""
from __future__ import annotations

import re

# A standalone +TOKEN / -TOKEN: operator preceded by start/space, followed by a letter-led word.
# The leading (?<![-\w]) stops "--flag" or "on-chain" from being read as operators.
ADD_RE = re.compile(r"(?<![-\w])\+\s*([A-Za-z][A-Za-z0-9_]{0,40})")
SUB_RE = re.compile(r"(?<![-\w])-\s*([A-Za-z][A-Za-z0-9_]{0,40})")
SCALE_RE = re.compile(r"(?<![\w])\*\s*(\d{1,3})\b")
ROUTE_RE = re.compile(r"->")
PARENT_ID_RE = re.compile(r"\b((?:PARENT|PID)_[A-Za-z0-9_]+)", re.I)
CHILD_ID_RE = re.compile(r"\b((?:CHILD|CID)_[A-Za-z0-9_]+)", re.I)

# feature name (any spelling) -> ("effect", value)
KNOWN = {
    "MASKING": ("masking", True), "ENFORCE_MASKING": ("masking", True), "ENCRYPT": ("masking", True),
    "MASK": ("masking", True),
    "NO_MASKING": ("masking", False), "UNMASKED": ("masking", False), "PLAINTEXT": ("masking", False),
    "DEBUG": ("debug", True), "DEBUG_LOGS": ("debug", True), "VERBOSE": ("debug", True),
    "SERVICE": ("service", True), "DAEMON": ("service", True), "BACKGROUND": ("service", True),
    "METROLOGY_ENGINE": ("service_name", "METROLOGY_ENGINE"), "METROLOGY": ("service_name", "METROLOGY_ENGINE"),
    "KERNEL": ("service_name", "CORE_KERNEL"), "SECURITY": ("service_name", "SECURITY_MODULE"),
}


def has_algebra(text: str) -> bool:
    return bool(ROUTE_RE.search(text) or ADD_RE.search(text) or SUB_RE.search(text) or SCALE_RE.search(text))


def _norm_id(x: str | None) -> str | None:
    return x.upper() if x else None


def parse_algebra(text: str) -> dict | None:
    """Returns a structured directive dict, or None if the text has no algebra operators."""
    if not text or not has_algebra(text):
        return None
    d = {"add": [], "remove": [], "scale": 1, "source": None, "target": None,
         "masking": None, "debug": None, "service_mode": None, "service_name": None}

    for tok in ADD_RE.findall(text):
        f = tok.upper()
        if f in d["add"]:
            continue
        d["add"].append(f)
        eff = KNOWN.get(f)
        if eff == ("masking", True):
            d["masking"] = True
        elif eff and eff[0] == "debug":
            d["debug"] = True
        elif eff and eff[0] == "service":
            d["service_mode"] = True
        elif eff and eff[0] == "service_name":
            d["service_name"] = eff[1]

    for tok in SUB_RE.findall(text):
        f = tok.upper()
        if f in d["remove"]:
            continue
        d["remove"].append(f)
        eff = KNOWN.get(f)
        if eff == ("masking", True):        # "- MASKING" means turn masking off
            d["masking"] = False
        elif eff == ("masking", False):
            d["masking"] = True
        elif eff and eff[0] == "debug":
            d["debug"] = False

    m = SCALE_RE.search(text)
    if m:
        d["scale"] = max(1, min(int(m.group(1)), 100))

    # Route: prefer IDs on the correct side of '->' when present.
    if ROUTE_RE.search(text):
        left, right = text.split("->", 1)
        sp = PARENT_ID_RE.search(left) or PARENT_ID_RE.search(text)
        ct = CHILD_ID_RE.search(right) or CHILD_ID_RE.search(text)
    else:
        sp = PARENT_ID_RE.search(text)
        ct = CHILD_ID_RE.search(text)
    d["source"] = _norm_id(sp.group(1)) if sp else None
    d["target"] = _norm_id(ct.group(1)) if ct else None
    return d


def _canon(cid: str | None) -> str | None:
    """CID_RPI5_A45C and CHILD_RPI_01 both normalize by dropping the prefix for loose comparison."""
    if not cid:
        return None
    return re.sub(r"^(CHILD_|CID_|PARENT_|PID_)", "", cid.upper())


def apply_algebra(d: dict, env: dict, parent_id: str | None, child_id: str | None):
    """
    Fold parsed algebra into an env dict (in place) and return (explain, warnings, force_service).
    Everything here is a plain string the deployed app can read; nothing is executed.
    """
    explain, warnings = [], []
    if d.get("masking") is not None:
        env["MASKING"] = "on" if d["masking"] else "off"
        explain.append(f"Masking flag: {env['MASKING']} (note: transport encryption is always on regardless).")
    if d.get("debug") is not None:
        env["DEBUG"] = "on" if d["debug"] else "off"
        explain.append(f"Debug logs: {env['DEBUG']}.")
    if d.get("service_name"):
        env["SERVICE"] = d["service_name"]
        explain.append(f"Target service: {d['service_name']}.")

    extra_add = [f for f in d["add"] if f not in KNOWN]
    extra_rm = [f for f in d["remove"] if f not in KNOWN]
    if extra_add:
        env["FEATURES"] = ",".join(extra_add)
        explain.append(f"Included features (+): {', '.join(extra_add)} (passed to the app as FEATURES).")
    if extra_rm:
        env["DISABLED_FEATURES"] = ",".join(extra_rm)
        explain.append(f"Excluded features (-): {', '.join(extra_rm)}.")

    if d.get("scale", 1) > 1:
        env["SCALE"] = str(d["scale"])
        explain.append(f"Scale hint: ×{d['scale']} nodes (informational — deploy to each Child to replicate).")

    if d.get("target") and child_id and _canon(d["target"]) != _canon(child_id):
        warnings.append(f"Prompt routes to {d['target']} but the selected Child is {child_id}; using the selected Child.")
    elif d.get("target") and child_id:
        explain.append(f"Route target {d['target']} matches the selected Child.")
    if d.get("source") and parent_id and _canon(d["source"]) != _canon(parent_id):
        warnings.append(f"Prompt sources from {d['source']} but the selected Parent is {parent_id}; using the selected Parent.")

    return explain, warnings, bool(d.get("service_mode"))
