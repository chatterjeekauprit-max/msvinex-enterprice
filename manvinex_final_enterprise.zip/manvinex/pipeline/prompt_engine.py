"""
Prompt Engine: natural-language prompt  ->  a small, structured, allow-listed deployment plan.

The prompt is NEVER executed or pasted into a shell. It can only choose between fixed options:
  mode       install | run | service
  timeout_s  1..3600 (run mode)
  args       argv list passed to the entrypoint (no shell, so no injection)
  env        extra environment variables (dangerous names are blocked)
The prompt text itself travels to the child only as data (VALRIX_PROMPT env var).

Works with English and Hinglish keywords. An LLM can replace `build_plan` later as long as it
returns the same plan shape; the Child Server validates the shape again.
"""
from __future__ import annotations

import re
import shlex

from common.plan import BLOCKED_ENV, validate_plan  # noqa: F401  (re-exported)

from .prompt_algebra import apply_algebra, has_algebra, parse_algebra  # noqa: F401

INSTALL_ONLY = ["deploy only", "install only", "only deploy", "only install", "sirf deploy", "sirf install",
                "just deploy", "just install", "don't run", "dont run", "do not run", "mat chalao", "no run",
                "without running"]
SERVICE = ["service", "daemon", "keep running", "keep it running", "background", "24/7", "continuous",
           "hamesha", "always on", "restart on"]
RUN = ["run", "execute", "start", "launch", "chala", "chalao", "chalu", "test", "चलाओ", "चला", "शुरू"]
MASK = ["mask", "masking", "encrypt", "secure", "obfuscate", "protect"]

TIMEOUT_RE = re.compile(r"(?:timeout|within|limit|max)\s*[:=]?\s*(\d{1,5})\s*(s|sec|secs|seconds|m|min|mins|minutes)?\b",
                        re.I)
ARGS_RE = re.compile(r"\bargs?\s*[:=]\s*(.+?)(?:;|$)", re.I)
ENV_RE = re.compile(r"\b([A-Z][A-Z0-9_]{1,40})=([^\s;]{1,200})")

DEFAULT_TIMEOUT = 300


def _has(text: str, words) -> bool:
    return any(re.search(r"(?<![a-z])" + re.escape(w) + r"(?![a-z])", text) for w in words)


def build_plan(prompt: str, artifact: dict | None = None, parent_id: str | None = None,
               child_id: str | None = None) -> dict:
    text = (prompt or "").strip()
    # Algebra tokens (+/-/->/*N) are parsed separately; strip the args:… clause so a "- FLAG"
    # inside argv is never mistaken for a "remove feature" operator.
    algebra = parse_algebra(ARGS_RE.sub("", text))
    low = text.lower()
    explain, warnings = [], []

    if _has(low, INSTALL_ONLY):
        mode = "install"
        explain.append("Mode: install only (files are verified and placed, nothing is executed).")
    elif _has(low, SERVICE) or (algebra and algebra.get("service_mode")):
        mode = "service"
        explain.append("Mode: service (keeps running in the background; a newer deployment of the same Parent ID replaces it).")
    else:
        mode = "run"
        if not _has(low, RUN) and not algebra and text:
            warnings.append("No explicit 'run/execute' word found; defaulting to run once.")
        explain.append("Mode: run once and report the exit code.")

    timeout = DEFAULT_TIMEOUT
    m = TIMEOUT_RE.search(text)
    if m:
        n = int(m.group(1))
        unit = (m.group(2) or "s").lower()
        timeout = n * 60 if unit.startswith("m") else n
    timeout = max(1, min(timeout, 3600))
    if mode == "run":
        explain.append(f"Timeout: {timeout}s.")

    args: list[str] = []
    m = ARGS_RE.search(text)
    if m:
        try:
            args = shlex.split(m.group(1))[:20]
            args = [a[:200] for a in args]
            explain.append(f"Arguments: {args}")
        except ValueError:
            warnings.append("Could not parse args (unbalanced quotes); ignored.")

    env = {}
    # Algebra features first (MASKING/DEBUG/SERVICE/FEATURES/SCALE…), then explicit KEY=VAL can override.
    if algebra:
        alg_explain, alg_warn, _ = apply_algebra(algebra, env, parent_id, child_id)
        explain = alg_explain + explain
        warnings += alg_warn
    for k, v in ENV_RE.findall(ARGS_RE.sub("", text)):
        if BLOCKED_ENV.match(k):
            warnings.append(f"Blocked environment variable {k}.")
            continue
        if len(env) < 20:
            env[k] = v
    if env:
        explain.append(f"Environment: {', '.join(f'{k}={v}' for k, v in env.items())}")

    masking_on = _has(low, MASK) or (algebra and algebra.get("masking") is True)
    explain.append("Encryption: always on. Payload is sealed for this one Child Server's key"
                   + (" (masking requested)." if masking_on else "."))

    if artifact:
        explain.insert(0, f"Artifact: {artifact.get('filename')} v{artifact.get('version')} "
                          f"({artifact.get('runtime')}, arch {artifact.get('arch')}).")

    plan = {"mode": mode, "timeout_s": timeout, "args": args, "env": env}
    return {"plan": plan, "explain": explain, "warnings": warnings}
