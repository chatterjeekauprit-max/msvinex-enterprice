# Process Monitoring Block (Health Monitoring)

Package install hone ke baad (drone / machine / automation) iska **health** monitor karta hai:

- Kahan kya kharabi ho rahi hai
- Kahan kya dikkat aa rahi hai  
- Severity: healthy / warning / critical / offline

## API
- POST /api/process/{id}/report-health  ← device se health + issues bhejo
- GET  /api/process/health-overview     ← saari kharabiyan ek jagah
- baaki register / list / heartbeat / mark-passive pehle jaisa

Koi hard-coded example device nahi. Real deploy ke baad register hota hai.
