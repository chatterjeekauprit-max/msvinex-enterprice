"""
ProcessMonitor — Health Monitoring focused.
After package install on hardware, tracks: where is the fault, what is wrong.
"""

from __future__ import annotations

import json
import time
import uuid
from pathlib import Path
from typing import Any

from .models import HealthIssue, HealthStatus, ProcessKind, ProcessRecord


class ProcessMonitor:
    def __init__(self, data_dir: str | Path | None = None):
        self.data_dir = Path(data_dir or "./data/process_monitor")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.store_path = self.data_dir / "processes.json"
        self._processes: dict[str, ProcessRecord] = {}
        self._load()

    def _load(self) -> None:
        if self.store_path.is_file():
            try:
                raw = json.loads(self.store_path.read_text(encoding="utf-8"))
                for item in raw:
                    rec = ProcessRecord.from_dict(item)
                    self._processes[rec.process_id] = rec
            except Exception:
                self._processes = {}

    def _save(self) -> None:
        data = [p.to_dict() for p in self._processes.values()]
        self.store_path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    def list_processes(self, kind=None, child_id=None, health=None):
        items = list(self._processes.values())
        if kind is not None:
            if isinstance(kind, str):
                kind = ProcessKind(kind)
            items = [p for p in items if p.kind == kind]
        if child_id:
            items = [p for p in items if p.child_id == child_id]
        if health:
            items = [p for p in items if p.health.value == health]
        items.sort(key=lambda p: p.created_at, reverse=True)
        return [p.to_dict() for p in items]

    def get(self, process_id: str):
        p = self._processes.get(process_id)
        return p.to_dict() if p else None

    def register(self, *, kind, name, child_id, parent_id=None, deployment_id=None,
                 artifact_id=None, use_case="", options=None, status="running", meta=None):
        if isinstance(kind, str):
            kind = ProcessKind(kind)
        process_id = "proc_" + uuid.uuid4().hex[:12]
        rec = ProcessRecord(
            process_id=process_id, kind=kind, name=name or "unnamed", child_id=child_id,
            parent_id=parent_id, deployment_id=deployment_id, artifact_id=artifact_id,
            status=status, health=HealthStatus.UNKNOWN, issues=[], use_case=use_case,
            options=options or {}, created_at=time.time(),
            last_seen=time.time() if kind == ProcessKind.ACTIVE else None, meta=meta or {},
        )
        self._processes[process_id] = rec
        self._save()
        return rec.to_dict()

    def update(self, process_id, *, name=None, use_case=None, options=None,
               status=None, kind=None, meta=None):
        rec = self._processes.get(process_id)
        if not rec:
            return None
        if name is not None: rec.name = name
        if use_case is not None: rec.use_case = use_case
        if options is not None: rec.options = options
        if status is not None: rec.status = status
        if kind is not None:
            if isinstance(kind, str): kind = ProcessKind(kind)
            rec.kind = kind
            if kind == ProcessKind.ACTIVE: rec.last_seen = time.time()
        if meta is not None: rec.meta.update(meta)
        self._save()
        return rec.to_dict()

    def report_health(self, process_id, *, health="healthy", issues=None, status=None):
        """Main entry: device reports where faults are."""
        rec = self._processes.get(process_id)
        if not rec:
            return None
        if isinstance(health, str):
            try:
                health = HealthStatus(health)
            except ValueError:
                health = HealthStatus.UNKNOWN
        rec.health = health
        rec.last_health_at = time.time()
        rec.last_seen = time.time()
        if status is not None:
            rec.status = status
        if issues is not None:
            rec.issues = [HealthIssue.from_dict(i) if isinstance(i, dict) else i for i in issues]
        if any(getattr(i, "severity", "") == "critical" for i in rec.issues):
            rec.health = HealthStatus.CRITICAL
        elif rec.issues and rec.health == HealthStatus.HEALTHY:
            rec.health = HealthStatus.WARNING
        self._save()
        return rec.to_dict()

    def heartbeat(self, process_id, status="running"):
        rec = self._processes.get(process_id)
        if not rec or rec.kind != ProcessKind.ACTIVE:
            return None
        rec.last_seen = time.time()
        rec.status = status
        if rec.health == HealthStatus.OFFLINE:
            rec.health = HealthStatus.UNKNOWN
        self._save()
        return rec.to_dict()

    def mark_passive(self, process_id):
        return self.update(process_id, kind=ProcessKind.PASSIVE, status="installed")

    def remove(self, process_id):
        if process_id in self._processes:
            del self._processes[process_id]
            self._save()
            return True
        return False

    def summary(self):
        active = [p for p in self._processes.values() if p.kind == ProcessKind.ACTIVE]
        passive = [p for p in self._processes.values() if p.kind == ProcessKind.PASSIVE]
        return {
            "total": len(self._processes),
            "active": len(active),
            "passive": len(passive),
            "active_running": sum(1 for p in active if p.status == "running"),
            "healthy": sum(1 for p in self._processes.values() if p.health == HealthStatus.HEALTHY),
            "warning": sum(1 for p in self._processes.values() if p.health == HealthStatus.WARNING),
            "critical": sum(1 for p in self._processes.values() if p.health == HealthStatus.CRITICAL),
            "offline": sum(1 for p in self._processes.values() if p.health == HealthStatus.OFFLINE),
        }

    def health_overview(self):
        """Shows: kahan kya kharabi hai."""
        out = []
        for p in self._processes.values():
            out.append({
                "process_id": p.process_id,
                "name": p.name,
                "child_id": p.child_id,
                "health": p.health.value,
                "status": p.status,
                "issue_count": len(p.issues),
                "issues": [i.to_dict() if hasattr(i, "to_dict") else i for i in p.issues],
                "last_health_at": p.last_health_at,
            })
        return out
