"""
Data models for Process Monitoring Block (Health Monitoring focus).
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any
import time


class ProcessKind(str, Enum):
    ACTIVE = "active"
    PASSIVE = "passive"


class HealthStatus(str, Enum):
    HEALTHY = "healthy"
    WARNING = "warning"
    CRITICAL = "critical"
    UNKNOWN = "unknown"
    OFFLINE = "offline"


@dataclass
class HealthIssue:
    code: str
    message: str
    location: str = ""
    severity: str = "warning"
    ts: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "HealthIssue":
        return cls(
            code=data.get("code", ""),
            message=data.get("message", ""),
            location=data.get("location", ""),
            severity=data.get("severity", "warning"),
            ts=float(data.get("ts") or time.time()),
        )


@dataclass
class ProcessRecord:
    process_id: str
    kind: ProcessKind
    name: str
    child_id: str
    parent_id: str | None = None
    deployment_id: str | None = None
    artifact_id: str | None = None
    status: str = "unknown"
    health: HealthStatus = HealthStatus.UNKNOWN
    issues: list = field(default_factory=list)
    use_case: str = ""
    options: dict = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    last_seen: float | None = None
    last_health_at: float | None = None
    meta: dict = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["kind"] = self.kind.value
        d["health"] = self.health.value
        d["issues"] = [i.to_dict() if hasattr(i, "to_dict") else i for i in self.issues]
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ProcessRecord":
        kind = data.get("kind", "passive")
        if isinstance(kind, str):
            kind = ProcessKind(kind)
        health = data.get("health", "unknown")
        if isinstance(health, str):
            try:
                health = HealthStatus(health)
            except ValueError:
                health = HealthStatus.UNKNOWN
        issues_raw = data.get("issues") or []
        issues = [HealthIssue.from_dict(i) if isinstance(i, dict) else i for i in issues_raw]
        return cls(
            process_id=data["process_id"],
            kind=kind,
            name=data.get("name", ""),
            child_id=data.get("child_id", ""),
            parent_id=data.get("parent_id"),
            deployment_id=data.get("deployment_id"),
            artifact_id=data.get("artifact_id"),
            status=data.get("status", "unknown"),
            health=health,
            issues=issues,
            use_case=data.get("use_case", ""),
            options=data.get("options") or {},
            created_at=float(data.get("created_at") or time.time()),
            last_seen=data.get("last_seen"),
            last_health_at=data.get("last_health_at"),
            meta=data.get("meta") or {},
        )
