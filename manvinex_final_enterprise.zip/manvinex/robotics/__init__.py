"""
Robotics & Automation support layer for Valrix.
Treats robots / PLCs / machines as Child nodes with health monitoring.
"""
from .adapter import RobotAdapter
__all__ = ["RobotAdapter"]
