"""
Robot / Automation adapter.
Maps robot controllers and automation devices into Valrix Child + Health Monitoring.
"""
from __future__ import annotations
from typing import Any

class RobotAdapter:
    """
    Lightweight adapter so any robot / PLC / machine can:
    - Receive packages via Pipeline (as a Child)
    - Report health (motor, sensor, power, joint, etc.)
    - Stay under silicon / identity security checks
    """

    SUPPORTED_CLASSES = [
        "industrial_robot",
        "mobile_robot",
        "drone",
        "plc",
        "cnc",
        "conveyor_controller",
        "generic_automation",
    ]

    def __init__(self, device_class: str = "generic_automation", child_id: str = ""):
        if device_class not in self.SUPPORTED_CLASSES:
            device_class = "generic_automation"
        self.device_class = device_class
        self.child_id = child_id

    def as_child_config(self) -> dict[str, Any]:
        return {
            "child_id": self.child_id,
            "device_class": self.device_class,
            "role": "robotics_automation",
            "supports_health": True,
            "supports_package_install": True,
        }

    def health_template(self) -> list[dict[str, str]]:
        """Suggested fault locations for this device class."""
        templates = {
            "industrial_robot": ["joint-1", "joint-2", "gripper", "controller", "power"],
            "mobile_robot": ["drive-left", "drive-right", "lidar", "battery", "navigation"],
            "drone": ["motor-fl", "motor-fr", "motor-bl", "motor-br", "battery", "gps", "imu"],
            "plc": ["input-bank", "output-bank", "cpu", "power", "network"],
            "cnc": ["spindle", "axis-x", "axis-y", "axis-z", "coolant", "power"],
            "conveyor_controller": ["motor", "encoder", "sensor-line", "power"],
            "generic_automation": ["actuator", "sensor", "controller", "power"],
        }
        locs = templates.get(self.device_class, templates["generic_automation"])
        return [{"location": loc, "severity": "warning", "message": ""} for loc in locs]
