"""
One-command local demo: starts DevNet + Parent Server + Pipeline + one Child Server on this machine,
seeds a vault with sample code, enrolls the child, and prints the dashboard URLs + tokens.

    python3 run_demo.py                 # DevNet (offline)
    python3 run_demo.py --fresh         # wipe ./data/demo first
    python3 run_demo.py --base-port 9000  # if Windows blocks the default ports (WinError 10013)

Ports used: pipeline=<base>, parent=<base+100>, child-status=<base+200>, devnet=<base+700>.
Then open the Pipeline dashboard, paste the admin token, and use the Pipeline tab.
Ctrl+C stops everything.
"""
from __future__ import annotations

import argparse
import os
import shutil
import socket
import subprocess
import sys
import time

for _stream in (sys.stdout, sys.stderr):
    if _stream and hasattr(_stream, "reconfigure"):
        try:
            _stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)
from common.web import ClientError, http, http_json  # noqa: E402

DATA = os.path.join(ROOT, "data", "demo")
# Ports are set from --base-port in main(); these are filled in there.
DEV = PAR = PIPE = ""
STATUS_PORT = 8200


def lan_ip() -> str:
    """Best-effort local LAN IP (so a Raspberry Pi on the same WiFi can reach this laptop)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def wait(url):
    for _ in range(60):
        try:
            http("GET", url, timeout=1)
            return
        except ClientError:
            time.sleep(0.25)
    raise SystemExit(
        f"{url} did not start - see the .log files in {DATA}\n"
        f"If a log shows WinError 10013 (Windows reserved the port), re-run with a different base port, e.g.:\n"
        f"    python run_demo.py --fresh --base-port 9000")


def tok(path):
    with open(os.path.join(DATA, path)) as f:
        return f.read().strip()


def main():
    global DEV, PAR, PIPE, STATUS_PORT
    ap = argparse.ArgumentParser()
    ap.add_argument("--fresh", action="store_true")
    ap.add_argument("--base-port", type=int, default=8000,
                    help="pipeline port; parent=+100, child-status=+200, devnet=+700 (use e.g. 9000 on Windows if you hit WinError 10013)")
    ap.add_argument("--lan", action="store_true",
                    help="expose the servers on your WiFi/LAN so a real Raspberry Pi can connect as a Child")
    opts = ap.parse_args()
    base = opts.base_port
    host = "0.0.0.0" if opts.lan else "127.0.0.1"      # bind address
    ip = lan_ip() if opts.lan else "127.0.0.1"         # address the Pi / browser should use
    PIPE = f"http://{ip}:{base}"
    PAR = f"http://{ip}:{base + 100}"
    DEV = f"http://{ip}:{base + 700}"
    STATUS_PORT = base + 200
    if opts.fresh and os.path.exists(DATA):
        shutil.rmtree(DATA)
    os.makedirs(DATA, exist_ok=True)
    procs = []

    def start(name, *args):
        log = open(os.path.join(DATA, f"{name}.log"), "a")
        procs.append(subprocess.Popen([sys.executable, "-m", *args], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT))

    ledger = ["--ledger", "devnet", "--devnet-url", DEV]
    try:
        start("devnet", "blockchain.devnet", "--host", host, "--port", str(base + 700), "--data", f"{DATA}/devnet")
        wait(DEV + "/health")
        start("parent", "parent_server.server", "--host", host, "--port", str(base + 100),
              "--data", f"{DATA}/parent", *ledger)
        start("pipeline", "pipeline.server", "--host", host, "--port", str(base), "--public-url", PIPE,
              "--data", f"{DATA}/pipeline", *ledger)
        wait(PAR + "/api/identity")
        wait(PIPE + "/api/identity")
        par_admin, par_pipe, pipe_admin = tok("parent/admin.token"), tok("parent/pipeline.token"), tok("pipeline/admin.token")
        H = lambda t: {"Authorization": f"Bearer {t}"}  # noqa: E731

        vaults = http_json("GET", PAR + "/api/vaults", headers=H(par_admin))["vaults"]
        if not vaults:
            print("seeding demo data…")

            def new_parent(name):
                return http_json("POST", PAR + "/api/vaults", json_body={"name": name}, headers=H(par_admin))["parent_id"]

            def put(pid, fname, data):
                return http_json("POST", f"{PAR}/api/vaults/{pid}/artifacts?filename={fname}",
                                 data=data, headers={**H(par_admin), "Content-Type": "application/octet-stream"})

            def make_cap(pid, cap_name, artifact_ids, entry, cenv):
                http_json("POST", f"{PAR}/api/vaults/{pid}/capabilities",
                          json_body={"name": cap_name, "artifact_ids": artifact_ids, "entrypoint": entry, "env": cenv},
                          headers=H(par_admin))

            # ---- Computer Vision Parent Server (3 prompt-selectable capabilities) ----
            cv = new_parent("Computer Vision Parent Server")
            cvdir = os.path.join(ROOT, "examples", "cv_algos")
            cvcam = put(cv, "cvcam.py", open(os.path.join(cvdir, "cvcam.py"), "rb").read())
            for cap_name, script, cenv in [
                    ("motion_detection", "motion_detection.py", {"SOURCE": "mock", "MAX_FRAMES": "20"}),
                    ("face_detection", "face_detection.py", {"SOURCE": "mock", "MAX_FRAMES": "10"}),
                    ("human_detection", "human_detection.py", {"SOURCE": "mock", "MAX_FRAMES": "10", "CONF": "0.5"})]:
                a = put(cv, script, open(os.path.join(cvdir, script), "rb").read())
                make_cap(cv, cap_name, [cvcam["artifact_id"], a["artifact_id"]], ["python3", script], cenv)

            # ---- Semiconductor Parent Server (metrology sample) ----
            semi = new_parent("Semiconductor Parent Server")
            m = put(semi, "main.py",
                    b"import json\nd=json.load(open('data/wafer.json'))\nfrom calib import mean\n"
                    b"print('Wafer metrology mean:', mean(d['readings']))\n")
            c = put(semi, "calib.py", b"def mean(xs): return round(sum(xs)/len(xs), 4)\n")
            http_json("POST", f"{PAR}/api/vaults/{semi}/datasets?filename=wafer.json",
                      data=b'{"readings": [10.02, 9.98, 10.01, 10.0]}',
                      headers={**H(par_admin), "Content-Type": "application/octet-stream"})
            make_cap(semi, "wafer_metrology", [m["artifact_id"], c["artifact_id"]], ["python3", "main.py"], {})

            # ---- Robotics & Drone Inspection Parent Server ----
            rob = new_parent("Robotics & Automation Parent Server")
            rob_dir = os.path.join(ROOT, "examples", "drone_robotics_patrol")
            if os.path.exists(rob_dir):
                p_script = put(rob, "drone_patrol.py", open(os.path.join(rob_dir, "drone_patrol.py"), "rb").read())
                s_script = put(rob, "safety_verifier.py", open(os.path.join(rob_dir, "safety_verifier.py"), "rb").read())
                wp_data = open(os.path.join(rob_dir, "flight_waypoints.json"), "rb").read()
                http_json("POST", f"{PAR}/api/vaults/{rob}/datasets?filename=flight_waypoints.json",
                          data=wp_data, headers={**H(par_admin), "Content-Type": "application/octet-stream"})
                make_cap(rob, "autonomous_patrol", [p_script["artifact_id"], s_script["artifact_id"]],
                         ["python3", "drone_patrol.py"], {"MODE": "patrol", "SPEED": "high"})

            # ---- Drone Parent Server (telemetry sample) ----
            drone = new_parent("Drone Parent Server")
            t = put(drone, "telemetry.py",
                    b"import os\nprint('Drone telemetry online for', os.environ.get('VALRIX_CHILD_ID'))\n"
                    b"print('altitude=120m battery=87% gps_lock=yes')\n")
            make_cap(drone, "flight_telemetry", [t["artifact_id"]], ["python3", "telemetry.py"], {})

            http_json("POST", PIPE + "/api/parent-servers", json_body={"url": PAR, "token": par_pipe,
                                                                      "label": "Local Parent Server"}, headers=H(pipe_admin))
            enr = http_json("POST", PIPE + "/api/children", json_body={"child_id": "CHILD_RPI_01", "label": "Demo Pi"},
                            headers=H(pipe_admin))
            subprocess.run([sys.executable, "-m", "child_server", "--data", f"{DATA}/child", "enroll", "--pipeline", PIPE,
                            "--child-id", "CHILD_RPI_01", "--token", enr["enroll_token"], "--trust-parent", PAR],
                           cwd=ROOT, check=True)
            # Pre-register robotics child node
            try:
                enr_rob = http_json("POST", PIPE + "/api/children", json_body={"child_id": "CHILD_ROBOT_01", "label": "Autonomous Robot Node"},
                                    headers=H(pipe_admin))
            except Exception:
                pass
        start("child", "child_server", "--data", f"{DATA}/child", "run", "--status-port", str(STATUS_PORT))

        # --lan: prepare a Raspberry Pi child and print a ready-to-paste enrollment command.
        pi_block = ""
        if opts.lan:
            try:
                r = http_json("POST", PIPE + "/api/children",
                              json_body={"child_id": "CHILD_RPI", "label": "Raspberry Pi (real)"}, headers=H(pipe_admin))
                cmds = r["commands"]
            except ClientError:
                try:
                    cmds = http_json("POST", PIPE + "/api/children/CHILD_RPI/token", headers=H(pipe_admin))["commands"]
                except ClientError:
                    cmds = None
            if cmds:
                pi_block = ("\n----------------------------------------------------------------\n"
                            " CONNECT A REAL RASPBERRY PI (same WiFi):\n"
                            " 1) Copy the whole 'valrix' folder to the Pi.\n"
                            " 2) On the Pi:  pip install cryptography   (and: bash deploy/setup_pi.sh  for the camera)\n"
                            " 3) On the Pi, run these two commands:\n"
                            f"      {cmds[0]}\n"
                            f"      {cmds[1]}\n"
                            " 4) Back here: Pipeline -> 'Computer Vision Parent Server' + CHILD_RPI -> Connect\n"
                            "      -> prompt:  + HUMAN_DETECTION -> CHILD_RPI SOURCE=camera MAX_FRAMES=0\n")

        print(f"""
================================================================
 VALRIX DEMO RUNNING  (DevNet ledger, dev-only){'   [LAN mode]' if opts.lan else ''}
----------------------------------------------------------------
 Pipeline dashboard : {PIPE}/        admin token: {pipe_admin}
 Parent Server UI   : {PAR}/        admin token: {par_admin}
 Child Server status: http://127.0.0.1:{STATUS_PORT}/status
 DevNet ledger      : {DEV}/v2/chain
----------------------------------------------------------------
 Pipeline tab -> "Computer Vision Parent Server" + CHILD_RPI_01 -> Connect & Continue
            -> prompt "+ MOTION_DETECTION -> CHILD_RPI_01" -> Deploy -> watch it run
 (also try + FACE_DETECTION / + HUMAN_DETECTION; only that algo is sent to the device)
 Parent Servers seeded: Computer Vision, Semiconductor, Drone{pi_block}
 Logs: {DATA}/*.log      Ctrl+C to stop
================================================================""", flush=True)
        if opts.lan:
            print(" NOTE: Windows may ask to allow Python through the firewall — click ALLOW,\n"
                  "       else the Pi can't reach these servers.", flush=True)
        while all(p.poll() is None for p in procs):
            time.sleep(1)
        print("a service exited - check the logs")
    except KeyboardInterrupt:
        pass
    finally:
        for p in procs:
            try:
                p.terminate()
                p.wait(timeout=2)
            except Exception:
                try:
                    p.kill()
                except Exception:
                    pass


if __name__ == "__main__":
    main()
