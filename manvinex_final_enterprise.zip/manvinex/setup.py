#!/usr/bin/env python3
"""
Setup script for Valrix: Zero-Trust Blockchain-Verified Hardware & Software Deployment Fabric.
"""
from setuptools import setup, find_packages

setup(
    name="valrix",
    version="1.0.0",
    description="Zero-Trust Blockchain-Verified Hardware & Software Deployment Fabric",
    author="Valrix Team",
    packages=find_packages(include=[
        "valrix*",
        "common*",
        "blockchain*",
        "parent_server*",
        "pipeline*",
        "child_server*",
        "hardware_engine*",
        "process_monitor*",
        "robotics*",
    ]),
    include_package_data=True,
    package_data={
        "common": ["static/*"],
        "parent_server": ["static/*"],
        "pipeline": ["static/*"],
    },
    python_requires=">=3.9",
    install_requires=[
        "cryptography>=41.0.0",
    ],
    extras_require={
        "cv": ["opencv-python-headless>=4.8.0", "numpy>=1.24.0"],
        "hardware": ["platformio>=6.1.0", "esptool>=4.6.0"],
        "all": [
            "cryptography>=41.0.0",
            "opencv-python-headless>=4.8.0",
            "numpy>=1.24.0",
            "platformio>=6.1.0",
            "esptool>=4.6.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "valrix = valrix.cli:main",
            "manvinex = valrix.cli:main",
        ],
    },
)
