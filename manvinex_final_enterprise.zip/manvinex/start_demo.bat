@echo off
title Valrix Zero-Trust Demo
chcp 65001 >nul
set PYTHONUTF8=1
cd /d "%~dp0"

echo ================================================================
echo  VALRIX: ZERO-TRUST BLOCKCHAIN-VERIFIED DEPLOYMENT FABRIC
echo ================================================================
echo.

call "%~dp0valrix.bat" doctor
if %errorlevel% neq 0 (
    echo.
    echo System doctor reported issues.
    pause
    exit /b 1
)

echo Starting demo environment...
echo Pipeline UI: http://127.0.0.1:8000/
echo.
call "%~dp0valrix.bat" demo --fresh
pause
