#!/usr/bin/env bash
# Valrix 1-Click Demo Launcher for Linux & Raspberry Pi
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "================================================================"
echo " VALRIX: ZERO-TRUST BLOCKCHAIN-VERIFIED DEPLOYMENT FABRIC"
echo "================================================================"
echo ""

bash "$SCRIPT_DIR/valrix.sh" doctor
echo ""
echo "Starting Valrix Demo (Pipeline UI: http://127.0.0.1:8000/)..."
exec bash "$SCRIPT_DIR/valrix.sh" demo --fresh "$@"
