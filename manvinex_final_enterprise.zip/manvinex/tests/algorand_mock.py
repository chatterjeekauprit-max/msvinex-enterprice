"""
Algorand client test against a local MOCK algod + indexer (no network needed).

Checks that AlgorandLedger: fetches params, posts a msgpack signed transaction whose Ed25519
signature over b"TX"+msgpack(txn) verifies for the sender, waits for confirmation, and that
lookup() parses the indexer JSON format. (Byte-exact acceptance by a real node still needs a
live TestNet run: see README "Algorand TestNet".)

Run:  python3 tests/algorand_mock.py
"""
from __future__ import annotations

import base64
import os
import struct
import sys
import threading

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey  # noqa: E402

from blockchain.algorand_codec import _pack  # noqa: E402
from blockchain.ledger import AlgorandLedger  # noqa: E402
from common.crypto import Identity, pub_to_address, sha512_256  # noqa: E402
from common.web import App, HTTPError  # noqa: E402


def unpack(b: bytes, i: int = 0):
    t = b[i]
    if t < 0x80:
        return t, i + 1
    if 0x80 <= t <= 0x8F:
        return _map(b, i + 1, t & 0x0F)
    if 0xA0 <= t <= 0xBF:
        n = t & 0x1F
        return b[i + 1:i + 1 + n].decode(), i + 1 + n
    fixed = {0xCC: ">B", 0xCD: ">H", 0xCE: ">I", 0xCF: ">Q"}
    if t in fixed:
        size = struct.calcsize(fixed[t])
        return struct.unpack(fixed[t], b[i + 1:i + 1 + size])[0], i + 1 + size
    if t in (0xC4, 0xC5, 0xC6, 0xD9, 0xDA, 0xDB):
        fmt = {0xC4: ">B", 0xC5: ">H", 0xC6: ">I", 0xD9: ">B", 0xDA: ">H", 0xDB: ">I"}[t]
        size = struct.calcsize(fmt)
        n = struct.unpack(fmt, b[i + 1:i + 1 + size])[0]
        raw = b[i + 1 + size:i + 1 + size + n]
        return (raw.decode() if t >= 0xD9 else raw), i + 1 + size + n
    if t == 0xDE:
        return _map(b, i + 3, struct.unpack(">H", b[i + 1:i + 3])[0])
    raise ValueError(hex(t))


def _map(b, i, n):
    d, keys = {}, []
    for _ in range(n):
        k, i = unpack(b, i)
        v, i = unpack(b, i)
        d[k] = v
        keys.append(k)
    assert keys == sorted(keys), "keys must be sorted (canonical msgpack)"
    return d, i


TXS = {}
GH = base64.b64encode(os.urandom(32)).decode()


def mock_app():
    app = App("mock-algod", quiet=True)

    @app.route("GET", "/v2/transactions/params")
    def params(req):
        return {"last-round": 1234, "min-fee": 1000, "fee": 0, "genesis-id": "testnet-v1.0", "genesis-hash": GH,
                "consensus-version": "x"}

    @app.route("POST", "/v2/transactions")
    def submit(req):
        stx, end = unpack(req.body)
        assert end == len(req.body)
        txn = stx["txn"]
        assert _pack(txn) == _pack(unpack(_pack(txn))[0]), "re-encoding must be stable"
        msg = b"TX" + _pack(txn)
        Ed25519PublicKey.from_public_bytes(txn["snd"]).verify(stx["sig"], msg)  # raises if bad
        assert txn["type"] == "pay" and "amt" not in txn and txn["fee"] >= 1000 and txn["gh"] == base64.b64decode(GH)
        tid = base64.b32encode(sha512_256(msg)).decode().rstrip("=")
        TXS[tid] = txn
        return {"txId": tid}

    @app.route("GET", "/v2/transactions/pending/{tid}")
    def pending(req):
        if req.params["tid"] not in TXS:
            raise HTTPError(404, "nope")
        return {"confirmed-round": 1235, "pool-error": ""}

    @app.route("GET", "/v2/transactions/{tid}")
    def indexer(req):
        t = TXS.get(req.params["tid"])
        if not t:
            raise HTTPError(404, "no tx")
        return {"current-round": 1300, "transaction": {"id": req.params["tid"], "confirmed-round": 1235,
                "sender": pub_to_address(t["snd"]), "note": base64.b64encode(t["note"]).decode(), "tx-type": "pay"}}

    @app.route("GET", "/v2/accounts/{addr}")
    def acct(req):
        return {"amount": 5_000_000}
    return app


if __name__ == "__main__":
    threading.Thread(target=mock_app().serve, args=("127.0.0.1", 18900), daemon=True).start()
    import time
    time.sleep(0.5)
    L = AlgorandLedger("testnet", "http://127.0.0.1:18900", "http://127.0.0.1:18900")
    who = Identity(os.urandom(32))
    r = L.anchor(who, {"k": "reg", "p": "PARENT_01", "a": "art_x", "h": "ab" * 32, "v": 1})
    got = L.lookup(r["txid"])
    ok = got["sender"] == who.address and got["record"]["h"] == "ab" * 32 and got["round"] == 1235
    print("anchor:", r)
    print("lookup:", got)
    print("explorer:", L.explorer_url(r["txid"]))
    print("balance:", L.balance(who.address))
    print("PASS" if ok else "FAIL")
    sys.exit(0 if ok else 1)
