"""
End-to-end test: starts DevNet + Parent Server + Pipeline + Child Server as real processes,
runs a full deployment, then tries to break it with 10 attack scenarios.

Run from the project root:   python3 tests/e2e.py
"""
from __future__ import annotations

import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time

for _stream in (sys.stdout, sys.stderr):
    if _stream and hasattr(_stream, "reconfigure"):
        try:
            _stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from blockchain.devnet import Chain  # noqa: E402
from blockchain.ledger import DevNetLedger  # noqa: E402
from common.crypto import Identity, b64d, canonical, seal, sha256_hex  # noqa: E402
from common.web import ClientError, http, http_json  # noqa: E402

P_DEV, P_PAR, P_PAR2, P_PIPE = 18700, 18100, 18101, 18000
DEV, PAR, PAR2, PIPE = (f"http://127.0.0.1:{p}" for p in (P_DEV, P_PAR, P_PAR2, P_PIPE))
TMP = tempfile.mkdtemp(prefix="valrix-e2e-")
PROCS: list[subprocess.Popen] = []
RESULTS: list[tuple[str, bool, str]] = []


def start(name, *args):
    log = open(os.path.join(TMP, f"{name}.log"), "w")
    p = subprocess.Popen([sys.executable, "-m", *args], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    PROCS.append(p)
    return p


def wait_http(url, timeout=10):
    end = time.time() + timeout
    while time.time() < end:
        try:
            http("GET", url, timeout=1)
            return
        except ClientError:
            time.sleep(0.2)
    raise RuntimeError(f"{url} did not start")


def token(path):
    with open(path) as f:
        return f.read().strip()


def api(base, method, path, tok, body=None, raw=None):
    if raw is not None:
        return http_json(method, base + path, data=raw, headers={"Authorization": f"Bearer {tok}",
                                                                   "Content-Type": "application/octet-stream"})
    return http_json(method, base + path, json_body=body, headers={"Authorization": f"Bearer {tok}"})


def child_cmd(*args, data=None):
    return subprocess.run([sys.executable, "-m", "child_server", "--data", data or CHILD_DATA, *args], cwd=ROOT,
                          capture_output=True, text=True, timeout=60)


def wait_dep(dep_id, done=("completed", "failed", "rejected", "expired"), timeout=30):
    end = time.time() + timeout
    while time.time() < end:
        d = api(PIPE, "GET", f"/api/deployments/{dep_id}", PIPE_TOK)
        if d["status"] in done and (d["status"] != "completed" or d.get("receipt_txid")):
            return d
        time.sleep(0.4)
    raise RuntimeError(f"{dep_id} stuck in {d['status']}")


def check(name, cond, detail=""):
    RESULTS.append((name, bool(cond), detail))
    print(("  PASS  " if cond else "  FAIL  ") + name + (f"  ({detail})" if detail else ""), flush=True)


def last_event(d):
    return d["events"][-1]["detail"] if d["events"] else ""


def pipe_db():
    return sqlite3.connect(os.path.join(TMP, "pipeline", "pipeline.db"))


def deploy(prompt, artifact_id, binding_id):
    return api(PIPE, "POST", "/api/deploy", PIPE_TOK, {"binding_id": binding_id, "artifact_id": artifact_id,
                                                        "prompt": prompt})


def deploy_cap(prompt, binding_id):
    return api(PIPE, "POST", "/api/deploy", PIPE_TOK, {"binding_id": binding_id, "prompt": prompt})["deployment_id"]


try:
    print(f"workdir {TMP}")
    ledger_args = ["--ledger", "devnet", "--devnet-url", DEV, "--quiet"]
    start("devnet", "blockchain.devnet", "--port", str(P_DEV), "--data", f"{TMP}/devnet", "--quiet")
    wait_http(DEV + "/health")
    start("parent", "parent_server.server", "--port", str(P_PAR), "--data", f"{TMP}/parent", *ledger_args)
    start("parent2", "parent_server.server", "--port", str(P_PAR2), "--data", f"{TMP}/parent2", *ledger_args)
    start("pipeline", "pipeline.server", "--port", str(P_PIPE), "--data", f"{TMP}/pipeline", *ledger_args)
    for u in (PAR, PAR2, PIPE):
        wait_http(u + "/api/identity")
    PAR_ADMIN, PAR_PIPE = token(f"{TMP}/parent/admin.token"), token(f"{TMP}/parent/pipeline.token")
    PIPE_TOK = token(f"{TMP}/pipeline/admin.token")
    CHILD_DATA = f"{TMP}/child"

    print("\n== Happy path ==")
    api(PAR, "POST", "/api/vaults", PAR_ADMIN, {"parent_id": "PARENT_01", "name": "Core Kernel & Models"})
    with open(os.path.join(ROOT, "examples", "valrix_engine.py"), "rb") as f:
        art = api(PAR, "POST", "/api/vaults/PARENT_01/artifacts?filename=valrix_engine.py", PAR_ADMIN, raw=f.read())
    check("Parent registers artifact on-chain", art["reg_txid"], f"tx {art['reg_txid'][:12]}…")
    with open(os.path.join(ROOT, "examples", "metrology_bundle.tar.gz"), "rb") as f:
        bundle = api(PAR, "POST", "/api/vaults/PARENT_01/artifacts?filename=metrology_bundle.tar.gz", PAR_ADMIN,
                     raw=f.read())

    ps = api(PIPE, "POST", "/api/parent-servers", PIPE_TOK, {"url": PAR, "token": PAR_PIPE, "label": "Friend 1 Vault"})
    check("Pipeline pins Parent Server address", ps["address"] == http_json("GET", PAR + "/api/identity")["address"])

    enr = api(PIPE, "POST", "/api/children", PIPE_TOK, {"child_id": "CHILD_RPI_01", "label": "Pi 5"})
    r = child_cmd("enroll", "--pipeline", PIPE, "--child-id", "CHILD_RPI_01", "--token", enr["enroll_token"],
                  "--trust-parent", PAR)
    check("Child enrolls with one-time token", r.returncode == 0, r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr)
    r2 = child_cmd("enroll", "--pipeline", PIPE, "--child-id", "CHILD_RPI_01", "--token", enr["enroll_token"],
                   data=f"{TMP}/child_clone")
    check("Enrollment token cannot be reused", r2.returncode != 0)

    child_proc = start("child", "child_server", "--data", CHILD_DATA, "run")
    time.sleep(1.5)
    con = api(PIPE, "POST", "/api/connect", PIPE_TOK, {"parent_id": "PARENT_01", "child_id": "CHILD_RPI_01"})
    check("Connect & Continue passes checks", con["ok"], ", ".join(c["name"] for c in con["checks"]))
    BIND = con["binding"]["binding_id"]

    d = deploy("Execute Valrix Metrology Engine with dynamic masking; touch /tmp/valrix_pwned $(id)",
               art["artifact_id"], BIND)
    d = wait_dep(d["deployment_id"])
    check("Deployment completes on Child", d["status"] == "completed", last_event(d))
    check("Child ran the real code", "Valrix Core System Running" in (d["output_tail"] or ""))
    verified = next((e for e in d["events"] if e["stage"] == "verified"), {})
    check("Child passed all 12 verification checks", "12/12" in verified.get("detail", ""))
    check("Deployment + receipt anchored on-chain", d["dep_txid"] and d["receipt_txid"])
    check("Prompt injection text not executed", not os.path.exists("/tmp/valrix_pwned"))
    lg = DevNetLedger(DEV)
    rec = lg.lookup(d["receipt_txid"])["record"]
    check("Receipt hash on-chain matches signed receipt", rec["r"] == sha256_hex(canonical(d["receipt"])))
    seals = api(PAR, "GET", "/api/audit", PAR_ADMIN)["seals"]
    check("Parent audit log records the seal", any(s["deployment_id"] == d["deployment_id"] for s in seals))
    pl_payload = open(os.path.join(TMP, "pipeline", "payloads", d["deployment_id"] + ".bin"), "rb").read()
    check("Pipeline only stores ciphertext (no plaintext)", b"Valrix Core System Running" not in pl_payload)

    d = wait_dep(deploy("run it timeout 30s args: --fast; MODE=calibrate", bundle["artifact_id"], BIND)["deployment_id"])
    check("Bundle (.tar.gz) deploy with args/env", d["status"] == "completed" and "bundle ok" in (d["output_tail"] or "")
          and "MODE: calibrate" in d["output_tail"], (d["output_tail"] or "").strip()[:80])

    d = wait_dep(deploy("sirf deploy karo", art["artifact_id"], BIND)["deployment_id"])
    check("Install-only plan does not execute", d["status"] == "completed" and d["receipt"]["status"] == "installed")

    print("\n== Prompt algebra ==")
    pre = api(PIPE, "POST", "/api/plan", PIPE_TOK, {"binding_id": BIND, "artifact_id": art["artifact_id"],
              "prompt": "+ METROLOGY_ENGINE - DEBUG_LOGS -> CHILD_RPI_01"})
    check("Algebra maps to allow-listed env (no shell)",
          pre["plan"]["env"].get("SERVICE") == "METROLOGY_ENGINE" and pre["plan"]["env"].get("DEBUG") == "off"
          and pre["plan"]["args"] == [])
    pre2 = api(PIPE, "POST", "/api/plan", PIPE_TOK, {"binding_id": BIND, "artifact_id": art["artifact_id"],
               "prompt": "+ METROLOGY -> CHILD_WRONG_99"})
    check("Algebra route mismatch warns, keeps selected Child",
          any("CHILD_WRONG_99" in w for w in pre2["warnings"]))
    d = wait_dep(deploy("+ FAST_MODE - TELEMETRY -> CHILD_RPI_01", art["artifact_id"], BIND)["deployment_id"])
    check("Algebra deployment runs on the Child",
          d["status"] == "completed" and d["plan"]["env"].get("FEATURES") == "FAST_MODE", d["plan"]["env"])

    print("\n== Block-vault, dataset & package builder ==")
    main_py = (b"import json, os\n"
               b"d = json.load(open('data/readings.json'))\n"
               b"from calib import mean\n"
               b"print('BUNDLE MEAN', mean(d['xs']), 'parent', os.environ['VALRIX_PARENT_ID'])\n")
    a_main = api(PAR, "POST", "/api/vaults/PARENT_01/artifacts?filename=main.py", PAR_ADMIN, raw=main_py)
    a_cal = api(PAR, "POST", "/api/vaults/PARENT_01/artifacts?filename=calib.py", PAR_ADMIN,
                raw=b"def mean(xs): return round(sum(xs)/len(xs), 3)\n")
    check("Files register into the vault", a_main["reg_txid"] and a_cal["reg_txid"])
    ds = api(PAR, "POST", "/api/vaults/PARENT_01/datasets?filename=readings.json", PAR_ADMIN,
             raw=b'{"xs": [10.0, 10.2, 9.8, 10.4]}')
    check("Dataset upload is checksummed + on-chain", ds["reg_txid"] and ds["sha256"], f"sha {ds['sha256'][:10]}…")
    try:
        api(PAR, "POST", "/api/vaults/PARENT_01/datasets?filename=bad.txt", PAR_ADMIN, raw=b"x")
        check("Non CSV/JSON dataset rejected", False)
    except ClientError as e:
        check("Non CSV/JSON dataset rejected", e.status == 400, e.message[:50])
    pkg = api(PAR, "POST", "/api/vaults/PARENT_01/packages", PAR_ADMIN,
              {"artifact_ids": [a_main["artifact_id"], a_cal["artifact_id"]], "dataset_id": ds["dataset_id"]})
    check("Package builder makes a deployable bundle on-chain", pkg["kind"] == "bundle" and pkg["reg_txid"]
          and pkg["bundle_manifest"]["entrypoint"] == ["python3", "main.py"])
    d = wait_dep(deploy("Run the packaged metrology bundle", pkg["artifact_id"], BIND)["deployment_id"])
    check("Packaged bundle deploys, unpacks and runs on the Child",
          d["status"] == "completed" and "BUNDLE MEAN 10.1" in (d["output_tail"] or ""), (d["output_tail"] or "").strip()[:80])

    print("\n== Computer-vision capabilities (prompt → scoped algo) ==")
    api(PAR, "POST", "/api/vaults", PAR_ADMIN, {"name": "Computer Vision", "parent_id": "PARENT_CV"})
    cvdir = os.path.join(ROOT, "examples", "cv_algos")

    def put_cv(fname):
        with open(os.path.join(cvdir, fname), "rb") as f:
            return api(PAR, "POST", f"/api/vaults/PARENT_CV/artifacts?filename={fname}", PAR_ADMIN, raw=f.read())
    cvcam = put_cv("cvcam.py")
    motion = put_cv("motion_detection.py")
    face = put_cv("face_detection.py")
    cap = api(PAR, "POST", "/api/vaults/PARENT_CV/capabilities", PAR_ADMIN,
              {"name": "motion_detection", "artifact_ids": [cvcam["artifact_id"], motion["artifact_id"]],
               "entrypoint": ["python3", "motion_detection.py"], "env": {"SOURCE": "mock", "MAX_FRAMES": "12"}})
    api(PAR, "POST", "/api/vaults/PARENT_CV/capabilities", PAR_ADMIN,
        {"name": "face_detection", "artifact_ids": [cvcam["artifact_id"], face["artifact_id"]],
         "entrypoint": ["python3", "face_detection.py"], "env": {"SOURCE": "mock", "MAX_FRAMES": "8"}})
    check("Capability builds a scoped bundle on-chain", cap["reg_txid"] and cap["capability"] == "motion_detection")

    api(PIPE, "GET", "/api/parent-servers", PIPE_TOK)  # refresh the Pipeline's view of new vaults
    conc = api(PIPE, "POST", "/api/connect", PIPE_TOK, {"parent_id": "PARENT_CV", "child_id": "CHILD_RPI_01"})
    CVBIND = conc["binding"]["binding_id"]
    pre = api(PIPE, "POST", "/api/plan", PIPE_TOK, {"binding_id": CVBIND,
              "prompt": "+ MOTION_DETECTION -> CHILD_RPI_01"})
    check("Prompt '+ MOTION_DETECTION' auto-resolves to its capability",
          pre.get("capability") == "motion_detection" and pre["plan"]["env"].get("SOURCE") == "mock")
    d = wait_dep(deploy_cap("+ MOTION_DETECTION -> CHILD_RPI_01", CVBIND), timeout=40)
    ok_run = d["status"] == "completed" and "motion_detection" in (d["output_tail"] or "")
    check("CV algo runs on the Child and detects motion (mock)", ok_run, (d["output_tail"] or "").strip().splitlines()[-1][:90] if d["output_tail"] else "")
    # only the scoped bundle went to the child - not the face script
    check("Only the requested capability's files are sent (scoped)",
          "face_detection" not in (d["output_tail"] or ""))

    svc_code = b"import time, os\nprint('service up', os.environ['VALRIX_DEPLOYMENT_ID'], flush=True)\nwhile True: time.sleep(1)\n"
    svc = api(PAR, "POST", "/api/vaults/PARENT_01/artifacts?filename=sensor_service.py", PAR_ADMIN, raw=svc_code)
    s1 = wait_dep(deploy("run as a service, keep running", svc["artifact_id"], BIND)["deployment_id"], done=("running",))
    check("Service mode starts and anchors a 'started' receipt", s1["receipt"] and s1["receipt"]["status"] == "started"
          and s1["receipt_txid"])
    s2 = wait_dep(deploy("run as a service", svc["artifact_id"], BIND)["deployment_id"], done=("running",))
    time.sleep(4)
    s1 = api(PIPE, "GET", f"/api/deployments/{s1['deployment_id']}", PIPE_TOK)
    stop_ev = next((e["detail"] for e in s1["events"] if e["stage"] == "completed"), "")
    check("New service version replaces the old one", s1["status"] == "completed" and "replaced by" in stop_ev
          and s1["receipt"]["status"] == "stopped" and s2["status"] == "running", stop_ev)

    # ------------------------------------------------------------------ attacks
    print("\n== Attacks (child is paused, then processes each one) ==")
    child_proc.terminate()
    child_proc.wait(5)

    def attack(name, mutate, expect_in):
        dep = deploy("Execute the module", art["artifact_id"], BIND)
        mutate(dep["deployment_id"])
        child_cmd("run", "--once")
        res = wait_dep(dep["deployment_id"], timeout=15)
        msg = last_event(res)
        check(name, res["status"] == "rejected" and expect_in in msg, msg)

    def tamper_payload(dep_id):
        p = os.path.join(TMP, "pipeline", "payloads", dep_id + ".bin")
        b = bytearray(open(p, "rb").read())
        b[60] ^= 0xFF
        open(p, "wb").write(bytes(b))
    attack("A1 payload tampered in Pipeline storage", tamper_payload, "payload does not match")

    def tamper_manifest(dep_id):
        with pipe_db() as c:
            m = json.loads(c.execute("SELECT manifest_json FROM deployments WHERE deployment_id=?", (dep_id,)).fetchone()[0])
            m["plan"]["timeout_s"] = 3600
            c.execute("UPDATE deployments SET manifest_json=? WHERE deployment_id=?", (canonical(m).decode(), dep_id))
    attack("A2 manifest edited after signing", tamper_manifest, "manifest signature")

    pipe_id = Identity.load_or_create(os.path.join(TMP, "pipeline", "identity.json"))
    with pipe_db() as c:
        enc_pub = b64d(c.execute("SELECT enc_pub FROM children WHERE child_id='CHILD_RPI_01'").fetchone()[0])
    EVIL = b"import os; print('EVIL CODE: stealing data')"

    def compromised_pipeline(reanchor):
        def mutate(dep_id):
            with pipe_db() as c:
                m = json.loads(c.execute("SELECT manifest_json FROM deployments WHERE deployment_id=?",
                                         (dep_id,)).fetchone()[0])
                blob = seal(EVIL, enc_pub, dep_id.encode())      # attacker encrypts their own code for the child
                open(os.path.join(TMP, "pipeline", "payloads", dep_id + ".bin"), "wb").write(blob)
                m["payload"] = {**m["payload"], "sha256": sha256_hex(blob), "size": len(blob)}
                mb = canonical(m)
                sig = pipe_id.sign("manifest", mb)               # ...re-signs with the stolen Pipeline key
                txid = c.execute("SELECT dep_txid FROM deployments WHERE deployment_id=?", (dep_id,)).fetchone()[0]
                if reanchor:                                     # ...and even re-anchors on-chain
                    txid = lg.anchor(pipe_id, {"k": "dep", "d": dep_id, "m": sha256_hex(mb), "p": "PARENT_01",
                                               "c": "CHILD_RPI_01"})["txid"]
                c.execute("UPDATE deployments SET manifest_json=?, manifest_sig=?, dep_txid=? WHERE deployment_id=?",
                          (mb.decode(), sig, txid, dep_id))
        return mutate
    attack("A3 stolen Pipeline key swaps code (no re-anchor)", compromised_pipeline(False), "not anchored on-chain")
    attack("A4 stolen Pipeline key swaps code AND re-anchors", compromised_pipeline(True), "Parent seal signature invalid")

    def replay(dep_id):
        with pipe_db() as c:
            old = c.execute("SELECT manifest_json, manifest_sig, dep_txid, payload_path FROM deployments WHERE "
                            "status='completed' ORDER BY created_at LIMIT 1").fetchone()
            c.execute("UPDATE deployments SET manifest_json=?, manifest_sig=?, dep_txid=?, payload_path=? "
                      "WHERE deployment_id=?", (*old, dep_id))
    dep = deploy("Execute the module", art["artifact_id"], BIND)
    replay(dep["deployment_id"])
    child_cmd("run", "--once")
    res = wait_dep(dep["deployment_id"], timeout=15)
    check("A5 old signed manifest re-used under a new ID", res["status"] == "rejected", last_event(res))

    with pipe_db() as c:  # re-queue an already executed deployment exactly as it was
        old_id = c.execute("SELECT deployment_id FROM deployments WHERE status='completed' ORDER BY created_at "
                           "LIMIT 1").fetchone()[0]
        c.execute("UPDATE deployments SET status='queued' WHERE deployment_id=?", (old_id,))
    child_cmd("run", "--once")
    res = wait_dep(old_id, timeout=15)
    check("A5b exact replay of an executed deployment", res["status"] == "rejected" and "replay" in last_event(res),
          last_event(res))

    # A6: a second Parent Server the child never pinned
    PAR2_ADMIN, PAR2_PIPE = token(f"{TMP}/parent2/admin.token"), token(f"{TMP}/parent2/pipeline.token")
    api(PAR2, "POST", "/api/vaults", PAR2_ADMIN, {"parent_id": "PARENT_ROGUE", "name": "unknown"})
    api(PAR2, "POST", "/api/vaults/PARENT_ROGUE/artifacts?filename=x.py", PAR2_ADMIN, raw=EVIL)
    api(PIPE, "POST", "/api/parent-servers", PIPE_TOK, {"url": PAR2, "token": PAR2_PIPE, "label": "rogue"})
    con2 = api(PIPE, "POST", "/api/connect", PIPE_TOK, {"parent_id": "PARENT_ROGUE", "child_id": "CHILD_RPI_01"})
    check("A6 Parent Server not pinned by child is blocked", not con2["ok"],
          next(c["detail"] for c in con2["checks"] if not c["ok"]))

    # A7: the Parent's stored file is modified on disk after registration
    art_row = sqlite3.connect(os.path.join(TMP, "parent", "parent.db")).execute(
        "SELECT path FROM artifacts WHERE artifact_id=?", (art["artifact_id"],)).fetchone()
    original = open(art_row[0], "rb").read()
    open(art_row[0], "wb").write(EVIL)
    try:
        deploy("Execute", art["artifact_id"], BIND)
        check("A7 Parent file swapped on disk after registration", False)
    except ClientError as e:
        check("A7 Parent file swapped on disk after registration", "registered hash" in e.message, e.message[:90])
    open(art_row[0], "wb").write(original)

    # A8: forged ledger entry claiming to be from the Parent
    attacker = Identity(os.urandom(32))
    try:
        http_json("POST", DEV + "/v2/tx", json_body={"sender": ps["address"], "note": "dmFscml4MTp7fQ==",
                                                     "ts": int(time.time()), "sig": attacker.sign_obj("devnet-tx", {})})
        check("A8 forged on-chain record in Parent's name", False)
    except ClientError as e:
        check("A8 forged on-chain record in Parent's name", e.status == 401, e.message)

    # A9: ledger history rewrite is detected
    chain_copy = os.path.join(TMP, "devnet_copy")
    shutil.copytree(os.path.join(TMP, "devnet"), chain_copy)
    lines = open(os.path.join(chain_copy, "chain.jsonl")).read().splitlines()
    b = json.loads(lines[0])
    b["note"] = "dmFscml4MTp7Imsi OiJldmlsIn0="
    lines[0] = json.dumps(b)
    open(os.path.join(chain_copy, "chain.jsonl"), "w").write("\n".join(lines) + "\n")
    check("A9 rewriting ledger history is detected", not Chain(chain_copy).verify()["ok"],
          json.dumps(Chain(chain_copy).verify()))

    # A10: revoked device is cut off
    queued = deploy("Execute", art["artifact_id"], BIND)
    api(PIPE, "POST", "/api/children/CHILD_RPI_01/revoke", PIPE_TOK)
    r = child_cmd("run", "--once")
    res = api(PIPE, "GET", f"/api/deployments/{queued['deployment_id']}", PIPE_TOK)
    check("A10 revoked child gets nothing, queued work cancelled",
          "revoked" in r.stdout and res["status"] == "rejected", res["status"])

    integrity = http_json("GET", DEV + "/v2/verify")
    check("Ledger integrity after all tests", integrity["ok"], f"{integrity.get('rounds')} rounds")

finally:
    for p in PROCS:
        if p.poll() is None:
            p.terminate()
    for p in PROCS:
        try:
            p.wait(5)
        except subprocess.TimeoutExpired:
            p.kill()

passed = sum(1 for _, ok, _ in RESULTS if ok)
print(f"\n{passed}/{len(RESULTS)} checks passed   (logs in {TMP})")
sys.exit(0 if passed == len(RESULTS) and RESULTS else 1)
