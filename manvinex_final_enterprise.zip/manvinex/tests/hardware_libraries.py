"""
Tests for hardware_engine.libraries: read-only checks + guarded installs.
Run: python3 tests/hardware_libraries.py
"""
from __future__ import annotations

import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from hardware_engine.manager import HardwareEngine  # noqa: E402

PASS = 0
FAIL = 0


def check(name: str, cond: bool, detail: str = ""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  PASS  {name}" + (f"  ({detail})" if detail else ""))
    else:
        FAIL += 1
        print(f"  FAIL  {name}" + (f"  ({detail})" if detail else ""))


def main():
    d = tempfile.mkdtemp(prefix="valrix-hw-lib-")
    engine = HardwareEngine(data_dir=os.path.join(d, "hw"))

    print("\n== Board readiness (read-only, no host tools required) ==")
    r = engine.check_readiness("esp32")
    check("Readiness report includes board info", r["board"]["id"] == "esp32")
    check("Readiness never raises when tools are absent", isinstance(r["pio_installed"], bool))

    r_bad = engine.check_readiness("not-a-real-board")
    check("Unknown board id reported, not crashed", r_bad.get("ok") is False)

    print("\n== PlatformIO project check ==")
    proj = os.path.join(d, "pio_proj")
    os.makedirs(proj)
    with open(os.path.join(proj, "platformio.ini"), "w") as f:
        f.write(
            "[env:esp32dev]\n"
            "platform = espressif32\n"
            "board = esp32dev\n"
            "framework = arduino\n"
            "lib_deps =\n"
            "    bblanchon/ArduinoJson@^7.0.0\n"
            "    knolleary/PubSubClient@^2.8\n"
        )
    pio_result = engine.check_libraries(proj)
    check("Detects PlatformIO project kind", pio_result["kind"] == "platformio")
    check("Parses declared environment", "esp32dev" in pio_result.get("environments", {}))
    check(
        "Parses both lib_deps entries",
        len(pio_result["environments"].get("esp32dev", {}).get("lib_deps", [])) == 2,
    )

    print("\n== Guarded installs refuse without confirm ==")
    no_confirm = engine.install_libraries(project_dir=proj, confirm=False)
    check("PlatformIO install refused without confirm=True", no_confirm["ok"] is False)

    no_confirm_arduino = engine.install_libraries(arduino_library="ArduinoJson", confirm=False)
    check("Arduino install refused without confirm=True", no_confirm_arduino["ok"] is False)

    print("\n== Arduino sketch check ==")
    sk = os.path.join(d, "sketch")
    os.makedirs(sk)
    with open(os.path.join(sk, "sketch.ino"), "w") as f:
        f.write(
            "#include <ArduinoJson.h>\n"
            "#include <SomeRandomLib.h>\n"
            "void setup(){}\nvoid loop(){}\n"
        )
    ard_result = engine.check_libraries(sk)
    check("Detects Arduino sketch kind", ard_result["kind"] == "arduino")
    check("Finds known header include", "ArduinoJson.h" in ard_result["includes"])
    check(
        "Unrecognized header reported, not guessed",
        "SomeRandomLib.h" in ard_result["unrecognized_includes"],
    )

    print("\n== Neither PlatformIO nor Arduino project ==")
    empty = os.path.join(d, "empty")
    os.makedirs(empty)
    unknown_result = engine.check_libraries(empty)
    check("Empty dir reported as unknown, not crashed", unknown_result["kind"] == "unknown")

    print(f"\n{PASS}/{PASS + FAIL} checks passed   (workdir {d})")
    if FAIL:
        sys.exit(1)


if __name__ == "__main__":
    main()
