"""
Test Antigravity Autonomous Ingestion & Plugin Engine
Verifies that when a user prompts for an un-packaged library/driver/capability:
  1. Pipeline autonomously detects intent (e.g. MQTT bridge, OpenCV vision, Modbus reader)
  2. Generates production Python code with environment bindings
  3. Registers the code and capability into the Parent Vault on-chain
  4. Returns plan with auto_synthesized=True and rich auto_plugin preview
  5. Child Server deploys and executes it upon user 'ALLOW' confirmation
"""
import json
import os
import sys
import tempfile
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from blockchain.ledger import DevNetLedger
from blockchain.devnet import Chain
from parent_server.server import ParentServer
from pipeline.server import Pipeline
from child_server.child import ChildServer
from common.web import http_json

class MockLedger:
    def __init__(self):
        self.records = {}
        self.round = 0
    def config(self):
        return {"mode": "mock", "url": "mock://devnet"}
    def label(self):
        return "Mock DevNet Ledger"
    def anchor(self, identity, record):
        self.round += 1
        txid = f"tx_mock_{self.round}_{int(time.time())}"
        self.records[txid] = {"record": record, "round": self.round, "sender": identity.address}
        return {"txid": txid, "round": self.round, "chain": "mock", "explorer": f"/explorer/{txid}"}
    def lookup(self, txid):
        return self.records.get(txid)
    def balance(self, address):
        return 1000000
    def explorer_url(self, txid):
        return f"/explorer/{txid}"

def test_antigravity_auto_plugin_flow():
    tmp = tempfile.mkdtemp(prefix="valrix-autoplugin-")
    print(f"Testing Antigravity Auto-Plugin in {tmp}...")

    # 1. DevNet Ledger Mock
    ledger = MockLedger()

    # 2. Parent Server
    par_dir = os.path.join(tmp, "parent")
    ps = ParentServer(par_dir, ledger)
    v = ps.create_vault("Industrial Edge Core", "PARENT_01", "Core Edge Vault")
    print(f"  [+] Parent Vault created: {v['parent_id']}")

    # 3. Pipeline Server
    pipe_dir = os.path.join(tmp, "pipeline")
    pl = Pipeline(pipe_dir, ledger, "http://127.0.0.1:8000")

    # Connect Pipeline directly to Parent in memory
    pl.db.execute("INSERT INTO parent_servers(label,url,token,address,added_at) VALUES(?,?,?,?,?)",
                  ("Local Parent", "http://local-parent", ps.pipeline_token, ps.identity.address, int(time.time())))
    ps_row = pl.db.one("SELECT * FROM parent_servers WHERE url=?", ("http://local-parent",))
    pl.db.execute("INSERT INTO parents VALUES(?,?,?,?)", ("PARENT_01", ps_row["ps_id"], "Industrial Edge Core", int(time.time())))

    # Hook internal _ps_get and mock Parent HTTP calls for unit testing
    pl._ps_get = lambda ps_r, path: {"vaults": ps.vaults()}

    import pipeline.server as p_mod
    orig_http_json = p_mod.http_json
    def mock_http_json(method, url, json_body=None, headers=None, **kwargs):
        if "create-code" in url:
            return ps.create_code("PARENT_01", json_body["filename"], json_body["content"], json_body.get("runtime"))
        if "capabilities" in url:
            return ps.create_capability("PARENT_01", json_body["name"], json_body["artifact_ids"],
                                        json_body.get("dataset_id"), json_body.get("entrypoint"),
                                        json_body.get("env"), json_body.get("arch"), json_body.get("description", ""))
        return orig_http_json(method, url, json_body=json_body, headers=headers, **kwargs)
    p_mod.http_json = mock_http_json

    # 4. Enroll Child Device directly into Pipeline DB
    child_dir = os.path.join(tmp, "child")
    cs = ChildServer(child_dir)
    info_json = json.dumps({"arch": "all", "os": "windows", "has_python3": True, "trusted_parents": [ps.identity.address]})
    pl.db.execute("INSERT OR REPLACE INTO children VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                  ("CHILD_EDGE_01", "Edge Jetson Node", "hash", int(time.time()) + 3600,
                   cs.identity.address, getattr(cs.identity, "enc_pub", "enc_pub"), getattr(cs.identity, "enc_sig", "enc_sig"), info_json, "active",
                   int(time.time()), int(time.time()), int(time.time())))

    # Connect Binding
    conn = pl.connect("PARENT_01", "CHILD_EDGE_01")
    assert conn["ok"], f"Binding checks must pass: {conn.get('checks')}"
    bind_id = conn["binding"]["binding_id"]
    print(f"  [+] Connected & Bound: {bind_id}")

    # 5. TEST: Autonomous Plugin Ingestion on prompt: 'Deploy MQTT industrial telemetry bridge with sensor polling'
    prompt = "Deploy MQTT industrial telemetry bridge with sensor polling"
    print(f"  [+] Prompting: '{prompt}'")

    plan_res = pl.auto_synthesize_plugin("PARENT_01", prompt)
    art_id, env, cap_name = plan_res
    auto_meta = plan_res.auto_meta

    assert auto_meta is not None, "Auto-synthesized metadata must be present"
    assert auto_meta["name"] == "mqtt_telemetry_bridge", f"Expected mqtt_telemetry_bridge, got {auto_meta['name']}"
    assert "paho-mqtt" in auto_meta["dependencies"], "Expected paho-mqtt in dependencies"
    assert "MQTT_BROKER" in env, "Expected MQTT_BROKER in env"
    print(f"  [+] Antigravity Auto-Plugin successfully resolved & registered: {auto_meta['name']} (files: {auto_meta['filename']})")
    print(f"      Dependencies: {auto_meta['dependencies']}")
    print(f"      On-Chain Reg TxID: {auto_meta['reg_txid']}")

    # 6. TEST: Plan endpoint returns auto_synthesized=True and preview
    plan_out = pl.plan(bind_id, artifact_id="auto", prompt=prompt)
    assert plan_out.get("auto_synthesized") is True, "Plan output must flag auto_synthesized=True"
    assert plan_out.get("auto_plugin")["name"] == "mqtt_telemetry_bridge"
    assert "✨ Antigravity Auto-Plugin" in plan_out["explain"][0]
    print("  [+] Plan successfully prepared with '✨ Antigravity Auto-Plugin' badge and ALLOW review!")

    # 7. TEST: OpenCV camera prompt
    prompt_cv = "Deploy OpenCV camera object tracking with 30fps stream"
    res_cv = pl.auto_synthesize_plugin("PARENT_01", prompt_cv)
    assert res_cv.auto_meta["name"] == "opencv_camera_tracker"
    assert "opencv-python-headless" in res_cv.auto_meta["dependencies"]
    print("  [+] OpenCV Auto-Plugin successfully synthesized & registered!")

    # 8. TEST: Modbus RS485 prompt
    prompt_mb = "Deploy Modbus RTU RS485 industrial reader on COM3"
    res_mb = pl.auto_synthesize_plugin("PARENT_01", prompt_mb)
    assert res_mb.auto_meta["name"] == "modbus_industrial_reader"
    assert "pymodbus" in res_mb.auto_meta["dependencies"]
    print("  [+] Modbus RS485 Auto-Plugin successfully synthesized & registered!")

    print("\nALL ANTIGRAVITY AUTO-PLUGIN TESTS PASSED SUCCESSFULLY!")

if __name__ == "__main__":
    test_antigravity_auto_plugin_flow()
