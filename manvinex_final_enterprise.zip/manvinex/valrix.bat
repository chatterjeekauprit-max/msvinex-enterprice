@echo off
setlocal
chcp 65001 >nul
set PYTHONUTF8=1

rem 1. Check if py -3.13 has cryptography
py -3.13 -c "import cryptography" >nul 2>nul
if %errorlevel% equ 0 (
    set PY_CMD=py -3.13
    goto :run
)

rem 2. Check if default py -3 has cryptography
py -3 -c "import cryptography" >nul 2>nul
if %errorlevel% equ 0 (
    set PY_CMD=py -3
    goto :run
)

rem 3. Check if python in PATH has cryptography
python -c "import cryptography" >nul 2>nul
if %errorlevel% equ 0 (
    set PY_CMD=python
    goto :run
)

rem 4. Fallback to py or python in PATH
where py >nul 2>nul
if %errorlevel% equ 0 (
    set PY_CMD=py -3.13
    goto :run
)
where python >nul 2>nul
if %errorlevel% equ 0 (
    set PY_CMD=python
    goto :run
)
where python3 >nul 2>nul
if %errorlevel% equ 0 (
    set PY_CMD=python3
    goto :run
)

echo [ERROR] Python was not found in PATH!
echo Please install Python 3.9 or higher from https://python.org
exit /b 1

:run
%PY_CMD% "%~dp0valrix.py" %*
exit /b %errorlevel%
