#!/usr/bin/env python3
"""
Valrix Unified CLI Entry Point.
Run directly without installing:
    python valrix.py doctor
    python valrix.py demo --fresh
    python valrix.py status
    python valrix.py test
"""
import os
import sys

# Ensure UTF-8 console output on Windows CP1252 / standard consoles
for _stream in (sys.stdout, sys.stderr):
    if _stream and hasattr(_stream, "reconfigure"):
        try:
            _stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

ROOT = os.path.dirname(os.path.abspath(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from valrix.cli import main

if __name__ == "__main__":
    sys.exit(main())
