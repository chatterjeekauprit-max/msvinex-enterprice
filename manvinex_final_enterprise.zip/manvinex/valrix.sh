#!/usr/bin/env bash
# Valrix CLI Launcher for Linux, macOS, and Raspberry Pi.
set -e

export PYTHONUTF8=1
export PYTHONUNBUFFERED=1

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Find python3 executable
if command -v python3 >/dev/null 2>&1; then
    PY_CMD="python3"
elif command -v python >/dev/null 2>&1; then
    PY_CMD="python"
else
    echo "[ERROR] Python 3 was not found in PATH." >&2
    echo "Install Python 3.9+ (e.g., sudo apt install python3 python3-pip)" >&2
    exit 1
fi

exec "$PY_CMD" "$SCRIPT_DIR/valrix.py" "$@"
