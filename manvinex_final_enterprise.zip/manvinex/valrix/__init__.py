"""
Valrix: Zero-Trust Blockchain-Verified Hardware & Software Deployment Fabric.
"""
from __future__ import annotations

import sys

# Ensure UTF-8 console output on Windows CP1252 / standard consoles
for _stream in (sys.stdout, sys.stderr):
    if _stream and hasattr(_stream, "reconfigure"):
        try:
            _stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

__version__ = "1.0.0"
__author__ = "Valrix Team"
