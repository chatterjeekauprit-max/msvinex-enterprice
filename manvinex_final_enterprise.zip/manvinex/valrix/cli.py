"""
Valrix Unified Command-Line Interface (CLI).
Manage, start, stop, probe, test, and deploy Valrix services.
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import signal
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
import webbrowser

# Add root directory to sys.path
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

# Ensure console UTF-8 on Windows
for _stream in (sys.stdout, sys.stderr):
    if _stream and hasattr(_stream, "reconfigure"):
        try:
            _stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

PID_DIR = os.path.join(ROOT, "data", "pids")


def _get_lan_ip() -> str:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def _is_port_in_use(port: int, host: str = "127.0.0.1") -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        return s.connect_ex((host, port)) == 0


def _query_json(url: str, timeout: float = 1.5) -> dict | None:
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Valrix-CLI"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8", errors="replace"))
    except Exception:
        return None


def _save_pid(name: str, pid: int):
    os.makedirs(PID_DIR, exist_ok=True)
    with open(os.path.join(PID_DIR, f"{name}.pid"), "w") as f:
        f.write(str(pid))


def _read_pid(name: str) -> int | None:
    path = os.path.join(PID_DIR, f"{name}.pid")
    if os.path.exists(path):
        try:
            with open(path) as f:
                return int(f.read().strip())
        except Exception:
            return None
    return None


def _remove_pid(name: str):
    path = os.path.join(PID_DIR, f"{name}.pid")
    if os.path.exists(path):
        try:
            os.remove(path)
        except Exception:
            pass


def _is_pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    if platform.system() == "Windows":
        try:
            out = subprocess.check_output(["tasklist", "/FI", f"PID eq {pid}", "/NH"], text=True)
            return str(pid) in out
        except Exception:
            return False
    else:
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False


def _kill_pid(pid: int):
    if platform.system() == "Windows":
        subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
    else:
        try:
            os.kill(pid, signal.SIGTERM)
            time.sleep(0.5)
            os.kill(pid, signal.SIGKILL)
        except OSError:
            pass


# ---------------------------------------------------------------- commands

def cmd_doctor(args):
    """Run comprehensive system diagnostics for deployment readiness."""
    print("================================================================")
    print(" VALRIX SYSTEM DOCTOR  —  Deployment Readiness Diagnostics")
    print("================================================================\n")
    issues = 0
    warnings = 0

    # 1. Python environment
    py_ver = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    if sys.version_info >= (3, 9):
        print(f" [OK] Python runtime : v{py_ver} ({platform.system()} {platform.machine()})")
    else:
        print(f" [FAIL] Python runtime : v{py_ver} (Valrix requires Python >= 3.9)")
        issues += 1

    # 2. Cryptography library
    try:
        import cryptography
        print(f" [OK] Cryptography   : v{cryptography.__version__} (hardware/software signing ready)")
    except ImportError:
        print(" [FAIL] Cryptography   : NOT INSTALLED. Run: pip install cryptography")
        issues += 1

    # 3. Ports check
    base = getattr(args, "base_port", 8000) or 8000
    ports = {
        "Pipeline (Web UI)": base,
        "Parent Server": base + 100,
        "Child Status": base + 200,
        "DevNet Ledger": base + 700,
    }
    print("\n Network & Ports:")
    for name, port in ports.items():
        used = _is_port_in_use(port)
        if used:
            # Check if it's an existing Valrix service
            health = _query_json(f"http://127.0.0.1:{port}/health") or _query_json(f"http://127.0.0.1:{port}/status")
            if health:
                srv = health.get("service") or health.get("role") or "Valrix Service"
                print(f"   * Port {port:5d} : ACTIVE ({srv})")
            else:
                print(f"   ! Port {port:5d} : BUSY (occupied by another process)")
                warnings += 1
        else:
            print(f"   * Port {port:5d} : AVAILABLE for {name}")

    # 4. Network Interfaces
    lan = _get_lan_ip()
    print(f"\n Network Interfaces:")
    print(f"   * Loopback IP : 127.0.0.1")
    print(f"   * Local LAN IP: {lan}")
    if lan != "127.0.0.1":
        print(f"   * Multi-Node  : Raspberry Pi / edge devices on your WiFi can reach {lan}")

    # 5. Hardware & Flash tools
    print("\n Hardware Engine Tools:")
    hw_tools = {
        "PlatformIO": "platformio",
        "PicoTool (RP2040)": "picotool",
        "ESPTool (ESP32/ESP8266)": "esptool.py",
        "OpenOCD (STM32/ARM)": "openocd",
    }
    for tool_name, exe in hw_tools.items():
        found = shutil.which(exe) is not None
        if found:
            print(f"   [OK]   {tool_name:24s} : available ({shutil.which(exe)})")
        else:
            print(f"   [INFO] {tool_name:24s} : optional (not in PATH)")

    # 6. Computer Vision & Edge Camera
    print("\n Edge Computer Vision Stack:")
    try:
        import cv2
        print(f"   [OK]   OpenCV                   : v{cv2.__version__}")
    except ImportError:
        print("   [INFO] OpenCV                   : not installed (only required for CV demo)")

    try:
        import picamera2  # noqa: F401
        print("   [OK]   PiCamera2                : available")
    except ImportError:
        pass

    # 7. Containerization / Docker
    print("\n Containerization:")
    docker = shutil.which("docker")
    compose = shutil.which("docker-compose") or (subprocess.run(["docker", "compose", "version"],
                                                               capture_output=True).returncode == 0 if docker else False)
    if docker:
        print(f"   [OK]   Docker CLI               : installed")
        if compose:
            print(f"   [OK]   Docker Compose           : available (ready for 1-click compose up)")
    else:
        print(f"   [INFO] Docker                   : optional (run natively with python)")

    # 8. Data storage check
    data_test = os.path.join(ROOT, "data", ".write_test")
    try:
        os.makedirs(os.path.dirname(data_test), exist_ok=True)
        with open(data_test, "w") as f:
            f.write("test")
        os.remove(data_test)
        print("\n [OK] Storage permissions   : write access verified in ./data")
    except Exception as e:
        print(f"\n [FAIL] Storage permissions : cannot write to ./data ({e})")
        issues += 1

    print("\n----------------------------------------------------------------")
    if issues == 0:
        print(" STATUS: DEPLOY READY! All core requirements satisfied.")
    else:
        print(f" STATUS: {issues} critical issue(s) detected. Fix them before deploying.")
    print("================================================================\n")
    return 0 if issues == 0 else 1


def cmd_status(args):
    """Check health and live status of all Valrix services."""
    base = getattr(args, "base_port", 8000) or 8000
    host = getattr(args, "host", "127.0.0.1") or "127.0.0.1"

    services = [
        ("Pipeline", base, f"http://{host}:{base}/health", f"http://{host}:{base}/api/identity"),
        ("Parent Server", base + 100, f"http://{host}:{base + 100}/health", f"http://{host}:{base + 100}/api/identity"),
        ("Child Server", base + 200, f"http://{host}:{base + 200}/health", f"http://{host}:{base + 200}/status"),
        ("DevNet Ledger", base + 700, f"http://{host}:{base + 700}/health", f"http://{host}:{base + 700}/v2/chain"),
    ]

    print("================================================================")
    print(" VALRIX SYSTEM STATUS")
    print("================================================================\n")
    print(f" {'Service':<16} {'Port':<6} {'State':<10} {'Details'}")
    print(f" {'-'*16} {'-'*6} {'-'*10} {'-'*28}")

    all_online = True
    for name, port, h_url, ident_url in services:
        pid = _read_pid(name.lower().replace(" ", "_"))
        pid_str = f"[PID {pid}]" if (pid and _is_pid_alive(pid)) else ""
        health = _query_json(h_url)
        if health:
            ident = _query_json(ident_url) or {}
            addr = ident.get("address", health.get("address", ""))
            short_addr = (addr[:8] + "…" + addr[-4:]) if len(addr) > 14 else addr
            role = health.get("service") or health.get("role") or ""
            ledger = ident.get("ledger") or health.get("ledger") or ""
            extra = []
            if short_addr:
                extra.append(f"addr: {short_addr}")
            if ledger:
                extra.append(f"ledger: {ledger}")
            if pid_str:
                extra.append(pid_str)
            print(f" {name:<16} {port:<6} {'ONLINE':<10} {' | '.join(extra) or 'Healthy'}")
        else:
            all_online = False
            state = "OFFLINE"
            if _is_port_in_use(port, host):
                state = "PORT_BUSY"
            print(f" {name:<16} {port:<6} {state:<10} (not responding on {h_url})")

    print("\n----------------------------------------------------------------")
    lan = _get_lan_ip()
    print(f" Web Dashboard : http://127.0.0.1:{base}/")
    if lan != "127.0.0.1":
        print(f" LAN Access    : http://{lan}:{base}/")
    print("================================================================\n")
    return 0 if all_online else 1


def cmd_demo(args):
    """Run the 1-command local demo environment."""
    import run_demo
    sys.argv = [sys.argv[0]]
    if getattr(args, "fresh", False):
        sys.argv.append("--fresh")
    if getattr(args, "lan", False):
        sys.argv.append("--lan")
    if getattr(args, "base_port", None):
        sys.argv.extend(["--base-port", str(args.base_port)])
    run_demo.main()


def cmd_start(args):
    """Start specific Valrix service or all services."""
    service = args.service.lower()
    if service == "all":
        cmd_demo(args)
        return

    base = args.base_port or 8000
    host = args.host or "127.0.0.1"
    data = args.data or os.path.join(ROOT, "data", service)
    os.makedirs(data, exist_ok=True)

    cmd_args = [sys.executable, "-m"]
    name = service
    port = base

    if service == "devnet":
        port = base + 700
        cmd_args.extend(["blockchain.devnet", "--host", host, "--port", str(port), "--data", data])
    elif service == "parent":
        port = base + 100
        cmd_args.extend(["parent_server.server", "--host", host, "--port", str(port), "--data", data,
                         "--ledger", args.ledger])
        if args.devnet_url:
            cmd_args.extend(["--devnet-url", args.devnet_url])
    elif service == "pipeline":
        port = base
        public_url = args.public_url or f"http://{host}:{port}"
        cmd_args.extend(["pipeline.server", "--host", host, "--port", str(port), "--data", data,
                         "--public-url", public_url, "--ledger", args.ledger])
        if args.devnet_url:
            cmd_args.extend(["--devnet-url", args.devnet_url])
    elif service == "child":
        port = base + 200
        cmd_args.extend(["child_server", "--data", data, "run", "--status-port", str(port)])
    else:
        print(f"Unknown service: {service}. Choices: all, devnet, parent, pipeline, child")
        return 1

    if args.daemon:
        log_file = open(os.path.join(data, f"{service}.log"), "a")
        proc = subprocess.Popen(cmd_args, cwd=ROOT, stdout=log_file, stderr=subprocess.STDOUT)
        _save_pid(service, proc.pid)
        print(f"Started {service} as background daemon (PID: {proc.pid}) on port {port}")
        print(f"Logs: {data}/{service}.log")
        return 0
    else:
        print(f"Starting {service} on port {port} (Ctrl+C to stop)...")
        try:
            return subprocess.run(cmd_args, cwd=ROOT).returncode
        except KeyboardInterrupt:
            print("\nStopped.")
            return 0


def cmd_stop(args):
    """Stop one or all Valrix daemon services."""
    service = args.service.lower()
    targets = ["devnet", "parent", "pipeline", "child"] if service == "all" else [service]

    stopped_any = False
    for s in targets:
        pid = _read_pid(s)
        if pid:
            if _is_pid_alive(pid):
                print(f"Stopping {s} (PID {pid})...")
                _kill_pid(pid)
                stopped_any = True
            _remove_pid(s)
        else:
            print(f"No running PID found for {s}.")

    if not stopped_any and service == "all":
        print("No active Valrix daemon services were found.")


def cmd_enroll(args):
    """Enroll a Child Server edge device with a Pipeline."""
    cmd_args = [
        sys.executable, "-m", "child_server", "--data", args.data,
        "enroll", "--pipeline", args.pipeline, "--child-id", args.child_id, "--token", args.token
    ]
    if args.trust_parent:
        for p in args.trust_parent:
            cmd_args.extend(["--trust-parent", p])
    if args.ledger_override:
        cmd_args.extend(["--ledger-override", args.ledger_override])
    if args.devnet_url:
        cmd_args.extend(["--devnet-url", args.devnet_url])
    return subprocess.run(cmd_args, cwd=ROOT).returncode


def cmd_test(args):
    """Run Valrix test suite."""
    print("================================================================")
    print(" RUNNING VALRIX TEST SUITE")
    print("================================================================\n")
    failed = False

    # 1. E2E tests
    if not args.mock_only and not args.hw_only:
        print(">>> 1/3: Running End-to-End & 10 Attack Tests (tests/e2e.py)...")
        rc = subprocess.run([sys.executable, "tests/e2e.py"], cwd=ROOT).returncode
        if rc != 0:
            failed = True
            print("FAILED: tests/e2e.py")

    # 2. Algorand Mock tests
    if not args.e2e_only and not args.hw_only:
        print("\n>>> 2/3: Running Algorand Mock Node Tests (tests/algorand_mock.py)...")
        rc = subprocess.run([sys.executable, "tests/algorand_mock.py"], cwd=ROOT).returncode
        if rc != 0:
            failed = True
            print("FAILED: tests/algorand_mock.py")

    # 3. Hardware Engine tests
    if not args.e2e_only and not args.mock_only:
        print("\n>>> 3/3: Running Hardware Engine Tests (tests/hardware_libraries.py)...")
        rc = subprocess.run([sys.executable, "tests/hardware_libraries.py"], cwd=ROOT).returncode
        if rc != 0:
            failed = True
            print("FAILED: tests/hardware_libraries.py")

    print("\n----------------------------------------------------------------")
    if not failed:
        print(" ALL VALRIX TESTS PASSED SUCCESSFULLY!")
    else:
        print(" SOME TESTS FAILED. See output above.")
    print("================================================================\n")
    return 1 if failed else 0


def cmd_gui(args):
    """Open the Valrix Pipeline dashboard in default web browser."""
    port = getattr(args, "base_port", 8000) or 8000
    host = getattr(args, "host", "127.0.0.1") or "127.0.0.1"
    url = f"http://{host}:{port}/"
    print(f"Opening Valrix Control Center: {url}")
    webbrowser.open(url)
    return 0


def cmd_host(args):
    """Host the server on 0.0.0.0 and print direct 1-click shareable login URLs."""
    import host_server
    sys.argv = [sys.argv[0]]
    if getattr(args, "fresh", False):
        sys.argv.append("--fresh")
    if getattr(args, "base_port", None):
        sys.argv.extend(["--base-port", str(args.base_port)])
    if getattr(args, "no_browser", False):
        sys.argv.append("--no-browser")
    host_server.main()



def _find_admin_token(service: str) -> str | None:
    candidates = [
        os.path.join(ROOT, "data", "demo", service, "admin.token"),
        os.path.join(ROOT, "data", service, "admin.token"),
    ]
    for c in candidates:
        if os.path.exists(c):
            try:
                with open(c) as f:
                    return f.read().strip()
            except Exception:
                pass
    return None


def _api_call(method: str, url: str, body: dict | None = None, token: str | None = None, timeout: float = 10.0) -> dict:
    headers = {"User-Agent": "Valrix-CLI"}
    data = None
    if body is not None:
        headers["Content-Type"] = "application/json"
        data = json.dumps(body).encode("utf-8")
    if token:
        headers["Authorization"] = f"Bearer {token}"
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8", errors="replace"))
    except urllib.error.HTTPError as e:
        err_msg = e.read().decode("utf-8", errors="replace")
        try:
            parsed = json.loads(err_msg)
            raise RuntimeError(parsed.get("error", err_msg))
        except Exception:
            raise RuntimeError(f"HTTP {e.code}: {err_msg}")


def cmd_mdu(args):
    """Inspect Manvinex Deployment Unit (MDU) commercial metering and gross margin metrics."""
    base = getattr(args, "base_port", 8000) or 8000
    host = getattr(args, "host", "127.0.0.1") or "127.0.0.1"
    token = _find_admin_token("pipeline")
    url = f"http://{host}:{base}/api/mdu/summary"
    try:
        data = _api_call("GET", url, token=token, timeout=3.0)
    except Exception as e:
        print(f"Error querying MDU metrics from {url}: {e}")
        print("Ensure Pipeline server is running (e.g. 'valrix demo' or 'valrix start pipeline').")
        return 1

    print("================================================================")
    print(" MANVINEX DEPLOYMENT UNIT (MDU) COMMERCIAL ACCOUNTING")
    print("================================================================\n")
    print(f"  * Unit Name            : Manvinex Deployment Unit (MDU)")
    print(f"  * Total MDUs Consumed  : {data.get('total_mdu', 0)}")
    print(f"  * Commercial Rate      : INR {data.get('rate_per_unit_inr', 3.50):.2f} / MDU")
    print(f"  * Execution COGS       : INR {data.get('cogs_per_unit_inr', 0.60):.2f} / MDU")
    print(f"  * Total Billed Value   : INR {data.get('total_revenue_inr', 0):.2f}")
    print(f"  * Total Compute COGS   : INR {data.get('total_cogs_inr', 0):.2f}")
    print(f"  * Gross Margin         : {data.get('gross_margin_percent', 82.8):.1f}%\n")

    archs = data.get("arch_breakdown", {})
    if archs:
        print("  Architecture Breakdown:")
        for arch, count in archs.items():
            print(f"    - {arch:<18} : {count} MDU")
        print()

    children = data.get("child_breakdown", {})
    if children:
        print("  Target Edge Nodes:")
        for cid, count in children.items():
            print(f"    - {cid:<18} : {count} MDU")
        print()

    l_url = f"http://{host}:{base}/api/mdu/ledger"
    try:
        l_data = _api_call("GET", l_url, token=token, timeout=3.0)
        ledger = l_data.get("ledger", [])
        if ledger:
            print("  Recent Settled Deployments:")
            print(f"    {'MDU ID':<14} {'Workload':<20} {'Node':<16} {'INR':<8} {'TXID'}")
            print(f"    {'-'*14} {'-'*20} {'-'*16} {'-'*8} {'-'*20}")
            for entry in ledger[:6]:
                tx = entry.get('txid', '')
                short_tx = (tx[:10] + '…') if len(tx) > 12 else tx
                print(f"    {entry.get('mdu_id', ''):<14} {entry.get('workload_name', '')[:19]:<20} "
                      f"{entry.get('child_id', ''):<16} INR {entry.get('cost_inr', 3.5):<4.2f} {short_tx}")
    except Exception:
        pass

    print("\n================================================================\n")
    return 0


def cmd_ingest(args):
    """Ingest any local folder or file into a Parent Server vault."""
    base = getattr(args, "base_port", 8000) or 8000
    host = getattr(args, "host", "127.0.0.1") or "127.0.0.1"
    target_path = os.path.abspath(args.path)
    if not os.path.exists(target_path):
        print(f"Error: path does not exist: {target_path}")
        return 1

    p_token = _find_admin_token("parent")
    p_port = base + 100
    parent_id = args.parent or "DRONE"

    print(f"Ingesting {target_path} into Parent Server '{parent_id}'...")
    url = f"http://{host}:{p_port}/api/vaults/{parent_id}/import-path"
    try:
        res = _api_call("POST", url, body={"path": target_path, "auto_bundle": True}, token=p_token)
        print("✓ Ingestion successful!")
        if res.get("bundle"):
            b = res["bundle"]
            print(f"  * Generated Bundle : {b.get('filename')} (ID: {b.get('artifact_id')})")
            print(f"  * On-Chain TX      : {b.get('reg_txid')}")
        elif res.get("imported"):
            print(f"  * Imported items   : {len(res['imported'])}")
            for item in res["imported"][:5]:
                print(f"    - {item.get('filename') or item.get('name')} -> SHA-256: {item.get('sha256', '')[:12]}…")
        return 0
    except Exception as e:
        print(f"Ingestion failed: {e}")
        return 1


def cmd_quick_deploy(args):
    """Turnkey 1-command deployment: takes any input (file/folder) and deploys it end-to-end to an edge child."""
    base = getattr(args, "base_port", 8000) or 8000
    host = getattr(args, "host", "127.0.0.1") or "127.0.0.1"
    target_path = os.path.abspath(args.path)
    if not os.path.exists(target_path):
        print(f"Error: target path does not exist: {target_path}")
        return 1

    pipe_health = _query_json(f"http://{host}:{base}/health")
    if not pipe_health:
        print(f"Pipeline is not running on http://{host}:{base}/.")
        print("Please start the platform first with:")
        print("    valrix demo   (or manvinex demo)")
        return 1

    pipe_token = _find_admin_token("pipeline")
    parent_token = _find_admin_token("parent")
    p_port = base + 100

    print("================================================================")
    print(" MANVINEX / VALRIX QUICK-DEPLOY ENGINE")
    print("================================================================\n")
    print(f"  * Source Target : {target_path}")

    # 1. Ingest into Parent Server
    parent_id = args.parent or "DRONE"
    print(f"  [1/5] Ingesting & Anchoring to Parent Server '{parent_id}'...")
    ingest_url = f"http://{host}:{p_port}/api/vaults/{parent_id}/import-path"
    try:
        ingest_res = _api_call("POST", ingest_url, body={"path": target_path, "auto_bundle": True}, token=parent_token)
    except Exception as e:
        print(f"  [FAIL] Ingestion failed: {e}")
        return 1

    artifact_id = None
    if ingest_res.get("bundle"):
        artifact_id = ingest_res["bundle"]["artifact_id"]
        print(f"        -> Created Bundle: {ingest_res['bundle']['filename']} (ID: {artifact_id})")
        print(f"        -> Blockchain Anchor TX: {ingest_res['bundle']['reg_txid']}")
    elif ingest_res.get("imported"):
        first = ingest_res["imported"][0]
        artifact_id = first.get("artifact_id") or first.get("id")
        print(f"        -> Vaulted {first.get('filename') or first.get('name')} (ID: {artifact_id})")
    else:
        print("  [FAIL] Could not find vaulted artifact ID.")
        return 1

    # 2. Resolve Child Node
    print("  [2/5] Resolving Target Child Node...")
    children_res = _api_call("GET", f"http://{host}:{base}/api/children", token=pipe_token)
    active_children = [c for c in children_res.get("children", []) if c.get("status") == "active"]
    if not active_children:
        print("  [FAIL] No active Child Server nodes enrolled.")
        return 1

    child_id = args.child
    if not child_id:
        online = [c for c in active_children if c.get("online")]
        child_id = online[0]["child_id"] if online else active_children[0]["child_id"]
    print(f"        -> Target Node: {child_id}")

    # 3. Ensure Binding
    print("  [3/5] Verifying Parent <-> Child Binding & Trust...")
    bind_res = _api_call("POST", f"http://{host}:{base}/api/connect", body={"parent_id": parent_id, "child_id": child_id}, token=pipe_token)
    binding_id = bind_res.get("binding_id", f"bnd_{parent_id}_{child_id}")
    print(f"        -> Binding Active: {binding_id}")

    # 4. Trigger ALLOW Deployment
    prompt_text = args.prompt or "Deploy and execute immediately"
    print(f"  [4/5] Authorizing ALLOW Deployment (Prompt: '{prompt_text}')...")
    dep_payload = {
        "binding_id": binding_id,
        "artifact_id": artifact_id,
        "prompt": prompt_text,
    }
    dep_res = _api_call("POST", f"http://{host}:{base}/api/deploy", body=dep_payload, token=pipe_token)
    dep_id = dep_res.get("deployment_id")
    print(f"        -> Deployment Dispatched: {dep_id}")
    print(f"        -> Manifest SHA-256: {dep_res.get('manifest_sha256', '')[:16]}…")
    if dep_res.get("dep_txid"):
        print(f"        -> On-Chain Deployment TX: {dep_res.get('dep_txid')}")

    # 5. Monitor Execution & Verification
    print("  [5/5] Monitoring Execution, 12-Step Verification & Signed Receipt...")
    start_t = time.time()
    seen_events = set()
    completed_dep = None

    while time.time() - start_t < 40:
        time.sleep(0.6)
        try:
            d = _api_call("GET", f"http://{host}:{base}/api/deployments/{dep_id}", token=pipe_token)
            for ev in d.get("events", []):
                k = (ev.get("stage"), ev.get("detail"))
                if k not in seen_events:
                    seen_events.add(k)
                    print(f"        [{ev.get('stage', '').upper()}] {ev.get('detail', '')}")
            if d.get("status") in ("completed", "failed", "rejected"):
                completed_dep = d
                break
        except Exception:
            pass

    print("\n----------------------------------------------------------------")
    if completed_dep and completed_dep.get("status") == "completed":
        print(" DEPLOYMENT STATUS: SUCCESS (100% Verified & Completed)")
        if completed_dep.get("receipt_txid"):
            print(f"  * Signed Receipt On-Chain TX: {completed_dep.get('receipt_txid')}")
        output = completed_dep.get("output_tail", "").strip()
        if output:
            print("\n Execution Output from Edge Node:")
            for line in output.splitlines()[-15:]:
                print(f"    | {line}")
        print("\n  * 1 MDU metered and settled to commercial billing.")
        print("================================================================\n")
        return 0
    else:
        st = completed_dep.get("status") if completed_dep else "TIMED_OUT"
        print(f" DEPLOYMENT STATUS: {st.upper()}")
        if completed_dep and completed_dep.get("output_tail"):
            print(f" Output: {completed_dep.get('output_tail')}")
        print("================================================================\n")
        return 1


# ---------------------------------------------------------------- main parser

def main():
    parser = argparse.ArgumentParser(
        prog="valrix",
        description="Valrix: Zero-Trust Blockchain-Verified Hardware & Software Deployment Fabric",
    )
    sub = parser.add_subparsers(dest="command", help="Valrix commands")

    # demo
    d_p = sub.add_parser("demo", help="Launch 1-command full local demo environment")
    d_p.add_argument("--fresh", action="store_true", help="Wipe demo database and start completely fresh")
    d_p.add_argument("--base-port", type=int, default=8000, help="Pipeline port (default 8000)")
    d_p.add_argument("--lan", action="store_true", help="Expose on local WiFi/LAN for real Raspberry Pi / edge nodes")

    # doctor
    doc_p = sub.add_parser("doctor", help="Run deployment readiness and environment diagnostics")
    doc_p.add_argument("--base-port", type=int, default=8000, help="Base port to check")

    # status
    st_p = sub.add_parser("status", help="Probe health and status of Valrix services")
    st_p.add_argument("--host", default="127.0.0.1", help="Target host (default 127.0.0.1)")
    st_p.add_argument("--base-port", type=int, default=8000, help="Base port (default 8000)")

    # start
    s_p = sub.add_parser("start", help="Start a Valrix service")
    s_p.add_argument("service", choices=["all", "pipeline", "parent", "child", "devnet"], help="Service to run")
    s_p.add_argument("--host", default="127.0.0.1", help="Bind address")
    s_p.add_argument("--base-port", type=int, default=8000, help="Base port")
    s_p.add_argument("--data", help="Custom data directory")
    s_p.add_argument("--ledger", default="devnet", choices=["devnet", "algorand"], help="Blockchain mode")
    s_p.add_argument("--devnet-url", help="DevNet ledger URL")
    s_p.add_argument("--public-url", help="Pipeline public URL")
    s_p.add_argument("--daemon", action="store_true", help="Run as background process")

    # stop
    k_p = sub.add_parser("stop", help="Stop daemon services")
    k_p.add_argument("service", nargs="?", default="all", choices=["all", "pipeline", "parent", "child", "devnet"])

    # enroll
    e_p = sub.add_parser("enroll", help="Enroll an edge child server with a Pipeline")
    e_p.add_argument("--pipeline", required=True, help="Pipeline URL")
    e_p.add_argument("--child-id", required=True, help="Unique child identifier")
    e_p.add_argument("--token", required=True, help="One-time enrollment token")
    e_p.add_argument("--trust-parent", action="append", help="Parent Server URL to pin (repeatable)")
    e_p.add_argument("--data", default="./data/child", help="Child data directory")
    e_p.add_argument("--ledger-override", choices=["devnet", "algorand"])
    e_p.add_argument("--devnet-url")

    # test
    t_p = sub.add_parser("test", help="Run Valrix automated test suite")
    t_p.add_argument("--e2e-only", action="store_true", help="Run only e2e attack tests")
    t_p.add_argument("--mock-only", action="store_true", help="Run only Algorand mock tests")
    t_p.add_argument("--hw-only", action="store_true", help="Run only Hardware Engine tests")

    # gui
    g_p = sub.add_parser("gui", help="Open Web UI in browser")
    g_p.add_argument("--host", default="127.0.0.1")
    g_p.add_argument("--base-port", type=int, default=8000)

    # mdu (commercial accounting)
    mdu_p = sub.add_parser("mdu", help="Inspect Manvinex Deployment Unit (MDU) commercial metering and margins")
    mdu_p.add_argument("--host", default="127.0.0.1")
    mdu_p.add_argument("--base-port", type=int, default=8000)

    # ingest (universal input)
    ing_p = sub.add_parser("ingest", help="Ingest local file or directory into Parent Server vault")
    ing_p.add_argument("path", help="Local file or folder path")
    ing_p.add_argument("--parent", default="DRONE", help="Parent Server ID (default DRONE)")
    ing_p.add_argument("--host", default="127.0.0.1")
    ing_p.add_argument("--base-port", type=int, default=8000)

    # quick-deploy (turnkey 1-command deployment)
    qd_p = sub.add_parser("quick-deploy", help="1-command turnkey deploy from any input file/folder to edge child")
    qd_p.add_argument("path", help="Path to code file or project directory to deploy")
    qd_p.add_argument("--child", help="Target child ID (default auto-detect online child)")
    qd_p.add_argument("--parent", default="DRONE", help="Parent ID (default DRONE)")
    qd_p.add_argument("--prompt", help="Deployment intent prompt")
    qd_p.add_argument("--host", default="127.0.0.1")
    qd_p.add_argument("--base-port", type=int, default=8000)

    # deploy alias
    dep_p = sub.add_parser("deploy", help="Alias for quick-deploy")
    dep_p.add_argument("path", help="Path to code file or project directory to deploy")
    dep_p.add_argument("--child", help="Target child ID (default auto-detect online child)")
    dep_p.add_argument("--parent", default="DRONE", help="Parent ID (default DRONE)")
    dep_p.add_argument("--prompt", help="Deployment intent prompt")
    dep_p.add_argument("--host", default="127.0.0.1")
    dep_p.add_argument("--base-port", type=int, default=8000)

    # host (network sharing)
    h_p = sub.add_parser("host", help="Host server on 0.0.0.0 and generate direct shareable links for others")
    h_p.add_argument("--base-port", type=int, default=8000, help="Pipeline port (default 8000)")
    h_p.add_argument("--fresh", action="store_true", help="Start with fresh database")
    h_p.add_argument("--no-browser", action="store_true", help="Do not open browser automatically")

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        return 0

    dispatch = {
        "demo": cmd_demo,
        "doctor": cmd_doctor,
        "status": cmd_status,
        "start": cmd_start,
        "stop": cmd_stop,
        "enroll": cmd_enroll,
        "test": cmd_test,
        "gui": cmd_gui,
        "mdu": cmd_mdu,
        "ingest": cmd_ingest,
        "quick-deploy": cmd_quick_deploy,
        "deploy": cmd_quick_deploy,
        "host": cmd_host,
    }
    return dispatch[args.command](args) or 0


if __name__ == "__main__":
    sys.exit(main())
